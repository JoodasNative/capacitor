# Joodas Native

A premium crypto personal finance platform designed for digital asset enthusiasts, offering a seamless and gamified financial ecosystem powered by Solana blockchain technology, with expanding multi-chain support and interactive social features.

## Key Features

- **Non-custodial Solana wallet** with automatic creation upon authentication
- **Premium, clean design** with white backgrounds, gold accents (#dcb454), and black elements
- **Firebase authentication** with comprehensive error handling
- **Cross-platform support** using Capacitor (Android, iOS, and Web)
- **Jupiter (JUP) integration** for Solana token swaps
- **Financial metrics** including HODL streaks and financial karma

## Tech Stack

- **Frontend**: React with TypeScript
- **Mobile Framework**: Capacitor 7
- **Authentication**: Firebase Auth
- **Database**: Firestore + PostgreSQL
- **Blockchain**: Solana integration with @solana/web3.js
- **Styling**: TailwindCSS with custom theme
- **Backend**: Express.js

## Getting Started

### Prerequisites

- Node.js (v16+)
- For Android: Android Studio, JDK, Android SDK
- For iOS: macOS with Xcode installed

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/JoodasNative/joodas-native.git
   cd joodas-native
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create platform projects (if it's your first time):
   ```bash
   npx cap add android    # For Android
   npx cap add ios        # For iOS (if you're on macOS)
   ```

4. Build the web app and sync to native platforms:
   ```bash
   npm run build
   npx cap sync
   ```

5. Open in native IDEs:
   ```bash
   npx cap open android    # Opens in Android Studio
   npx cap open ios        # Opens in Xcode (macOS only)
   ```

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_PROJECT_ID=your_firebase_project_id
VITE_FIREBASE_APP_ID=your_firebase_app_id
HELIUS_API_KEY=your_helius_api_key
```

## Development

For detailed development instructions, refer to the [capacitor-commands.md](./capacitor-commands.md) file.

## Firebase Setup

1. Create a Firebase project at [firebase.google.com](https://console.firebase.google.com/)
2. Enable Authentication (Email/Password, Google Sign-In)
3. Enable Firestore Database
4. Add your app to Firebase (Web, Android, iOS)
5. Download the config files:
   - Android: `google-services.json` (place in `android/app/`)
   - iOS: `GoogleService-Info.plist` (place in `ios/App/App/`)

## License

MIT# capacitor
