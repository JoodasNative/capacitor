import { Keypair, Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL, sendAndConfirmTransaction } from '@solana/web3.js';
import bs58 from 'bs58';
import * as nacl from 'tweetnacl';
import { storage } from '../storage';
import { InsertWallet, InsertTransaction } from '@shared/schema';

// Solana RPC URL using Helius API
const SOLANA_RPC_URL = `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}`;

// We'll use devnet for demo/development
const SOLANA_DEVNET_URL = `https://devnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}`;

// Use devnet for development, mainnet for production
const connection = new Connection(
  process.env.NODE_ENV === 'production' ? SOLANA_RPC_URL : SOLANA_DEVNET_URL,
  'confirmed'
);

/**
 * Generate a new Solana wallet for a user
 * @param userId The user ID to associate with the wallet
 * @returns The created wallet with address and keypair
 */
export async function generateWallet(userId: string): Promise<{ address: string, secretKey: Uint8Array }> {
  try {
    // Generate a new Solana keypair
    const keypair = Keypair.generate();
    
    // Get the public key (wallet address) as a string
    const walletAddress = keypair.publicKey.toString();
    
    // Store the wallet in the database
    const newWallet: InsertWallet = {
      userId,
      type: 'solana',
      address: walletAddress,
      balance: 0,
      isConnected: true,
    };
    
    await storage.createWallet(newWallet);
    
    // Log wallet creation (but never log private keys in production)
    console.log(`Created wallet ${walletAddress} for user ${userId}`);
    
    // Return the wallet information
    return {
      address: walletAddress,
      secretKey: keypair.secretKey
    };
  } catch (error) {
    console.error('Error generating wallet:', error);
    throw new Error('Failed to generate wallet');
  }
}

/**
 * Get the balance of a Solana wallet
 * @param address The wallet address
 * @returns The balance in SOL
 */
export async function getWalletBalance(address: string): Promise<number> {
  try {
    const publicKey = new PublicKey(address);
    const balanceInLamports = await connection.getBalance(publicKey);
    const balanceInSol = balanceInLamports / LAMPORTS_PER_SOL;
    return balanceInSol;
  } catch (error) {
    console.error('Error fetching wallet balance:', error);
    throw new Error('Failed to fetch wallet balance');
  }
}

/**
 * Update the balance of a wallet in the database
 * @param walletId The wallet ID
 * @param address The wallet address
 * @returns The updated wallet
 */
export async function updateWalletBalance(walletId: number, address: string): Promise<any> {
  try {
    // Get current balance from Solana
    const balance = await getWalletBalance(address);
    
    // Update in database
    const updatedWallet = await storage.updateWallet(walletId, {
      balance,
      lastUpdated: new Date()
    });
    
    return updatedWallet;
  } catch (error) {
    console.error('Error updating wallet balance:', error);
    throw new Error('Failed to update wallet balance');
  }
}

/**
 * Sign a transaction with a private key
 * @param transaction The transaction to sign
 * @param secretKey The wallet's secret key
 * @returns The signed transaction
 */
export function signTransaction(transaction: Transaction, secretKey: Uint8Array): Transaction {
  const keypair = Keypair.fromSecretKey(secretKey);
  transaction.sign(keypair);
  return transaction;
}

/**
 * Send SOL from one wallet to another
 * @param fromAddress The sender wallet address
 * @param secretKey The sender wallet's secret key
 * @param toAddress The recipient wallet address
 * @param amount The amount in SOL to send
 * @returns The transaction signature
 */
export async function sendSol(
  fromAddress: string,
  secretKey: Uint8Array,
  toAddress: string,
  amount: number
): Promise<string> {
  try {
    const fromPublicKey = new PublicKey(fromAddress);
    const toPublicKey = new PublicKey(toAddress);
    
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: fromPublicKey,
        toPubkey: toPublicKey,
        lamports: amount * LAMPORTS_PER_SOL
      })
    );
    
    // Get recent blockhash
    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = fromPublicKey;
    
    // Sign the transaction
    const keypair = Keypair.fromSecretKey(secretKey);
    const signature = await sendAndConfirmTransaction(connection, transaction, [keypair]);
    
    return signature;
  } catch (error) {
    console.error('Error sending SOL:', error);
    throw new Error('Failed to send SOL');
  }
}

/**
 * Record a transaction in the database
 * @param userId The user ID
 * @param walletId The wallet ID
 * @param txType The transaction type (send, receive, etc.)
 * @param amount The transaction amount
 * @param token The token symbol (e.g., SOL)
 * @param status The transaction status
 * @param note Optional note about the transaction
 * @returns The created transaction record
 */
export async function recordTransaction(
  userId: string,
  walletId: number,
  txType: string,
  amount: number,
  token: string = 'SOL',
  status: string = 'completed',
  note?: string
): Promise<any> {
  try {
    const newTransaction: InsertTransaction = {
      userId,
      walletId,
      type: txType,
      amount,
      token,
      status,
      note
    };
    
    const transaction = await storage.createTransaction(newTransaction);
    return transaction;
  } catch (error) {
    console.error('Error recording transaction:', error);
    throw new Error('Failed to record transaction');
  }
}

/**
 * Get transactions for a wallet from Helius
 * @param address The wallet address
 * @returns Array of transactions
 */
export async function getWalletTransactions(address: string): Promise<any[]> {
  try {
    const endpoint = 'https://api.helius.xyz/v0/addresses/' + address + '/transactions';
    const query = `?api-key=${process.env.HELIUS_API_KEY}&limit=10`;
    
    const response = await fetch(endpoint + query);
    if (!response.ok) {
      throw new Error(`Error fetching transactions: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching wallet transactions:', error);
    throw new Error('Failed to fetch wallet transactions');
  }
}

/**
 * Decode a base58 encoded private key
 * @param encodedKey The base58 encoded private key
 * @returns Uint8Array representing the private key
 */
export function decodePrivateKey(encodedKey: string): Uint8Array {
  return bs58.decode(encodedKey);
}

/**
 * Encode a private key to base58
 * @param secretKey The private key as Uint8Array
 * @returns The base58 encoded private key
 */
export function encodePrivateKey(secretKey: Uint8Array): string {
  return bs58.encode(secretKey);
}

/**
 * Validates whether a string is a valid Solana address
 * @param address The address to validate
 * @returns True if valid, false otherwise
 */
export function isValidSolanaAddress(address: string): boolean {
  try {
    new PublicKey(address);
    return true;
  } catch {
    return false;
  }
}