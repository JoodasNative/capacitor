import {
  QuoteGetRequest,
  QuoteResponse,
  SwapPostRequest,
  SwapResponse
} from '@jup-ag/api';
import axios from 'axios';

// Jupiter API configuration
const API_VERSION = 'v6';
const JUPITER_BASE_URL = 'https://quote-api.jup.ag';

/**
 * Get a quote for a swap between two tokens
 * @param params The quote parameters 
 * @returns The quote response
 */
export async function getQuote(params: QuoteGetRequest): Promise<QuoteResponse> {
  try {
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('inputMint', params.inputMint);
    queryParams.append('outputMint', params.outputMint);
    queryParams.append('amount', params.amount);
    
    if (params.slippageBps) {
      queryParams.append('slippageBps', params.slippageBps.toString());
    }
    
    if (params.platformFeeBps) {
      queryParams.append('platformFeeBps', params.platformFeeBps.toString());
    }
    
    // Call the Jupiter API to get a quote
    const response = await axios.get<QuoteResponse>(
      `${JUPITER_BASE_URL}/${API_VERSION}/quote?${queryParams.toString()}`
    );
    
    return response.data;
  } catch (error) {
    console.error('Error getting Jupiter quote:', error);
    throw error;
  }
}

/**
 * Execute a swap transaction
 * @param params The swap parameters
 * @returns The swap response
 */
export async function executeSwap(params: any): Promise<SwapResponse> {
  try {
    // Call the Jupiter API to execute the swap
    const response = await axios.post<SwapResponse>(
      `${JUPITER_BASE_URL}/${API_VERSION}/swap`,
      params
    );
    
    return response.data;
  } catch (error) {
    console.error('Error executing Jupiter swap:', error);
    throw error;
  }
}

/**
 * Calculate slippage for a transaction
 * @param quote The quote response from Jupiter
 * @returns The slippage percentage
 */
export function calculateSlippage(quote: QuoteResponse): number {
  if (!quote || !quote.otherAmountThreshold) {
    return 0;
  }
  
  const inputAmount = parseInt(quote.inAmount);
  const outputAmount = parseInt(quote.outAmount);
  const otherAmountThreshold = parseInt(quote.otherAmountThreshold);
  
  // Calculate potential slippage
  const slippageAmount = outputAmount - otherAmountThreshold;
  
  if (outputAmount === 0) {
    return 0;
  }
  
  const slippagePercentage = (slippageAmount * 10000 / outputAmount) / 100;
  
  return slippagePercentage;
}

/**
 * Check if a token has sufficient liquidity
 * @param quote The quote response from Jupiter
 * @returns Whether the token has sufficient liquidity
 */
export function hasLiquidityRisk(quote: QuoteResponse): boolean {
  // Check if the price impact is significant (> 1%)
  return parseFloat(String(quote.priceImpactPct)) > 1.0;
}

/**
 * Evaluate and return warnings for a potential swap
 * @param quote The quote response from Jupiter
 * @returns Array of warnings if any
 */
export function getSwapWarnings(quote: QuoteResponse): string[] {
  const warnings: string[] = [];
  
  // Check for price impact
  const priceImpact = parseFloat(String(quote.priceImpactPct));
  if (priceImpact > 3.0) {
    warnings.push(`High price impact: ${priceImpact.toFixed(2)}%`);
  }
  
  // Check for routing complexity (multiple hops)
  if (quote.routePlan && quote.routePlan.length > 2) {
    warnings.push(`Complex route with ${quote.routePlan.length} steps`);
  }
  
  // Check for slippage
  const slippage = calculateSlippage(quote);
  if (slippage > 1.0) {
    warnings.push(`High slippage risk: ${slippage.toFixed(2)}%`);
  }
  
  return warnings;
}