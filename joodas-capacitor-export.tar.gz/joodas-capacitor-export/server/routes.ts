import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWalletSchema,
  insertTransactionSchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import jupiterRoutes from "./routes/jupiterRoutes";
import walletRoutes from "./routes/walletRoutes";
import { setupAuth, isAuthenticated } from "./authService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up Seamless Degen Onboarding authentication
  await setupAuth(app);
  
  const apiRouter = express.Router();

  // Error handling middleware for Zod validation
  const validateRequest = (schema: z.ZodType<any, any>) => {
    return (req: express.Request, res: express.Response, next: express.NextFunction) => {
      try {
        req.body = schema.parse(req.body);
        next();
      } catch (error) {
        if (error instanceof z.ZodError) {
          const validationError = fromZodError(error);
          res.status(400).json({ message: validationError.message });
        } else {
          res.status(400).json({ message: "Invalid request data" });
        }
      }
    };
  };

  // Auth related routes - already handled by setupAuth
  
  // User and profile routes
  apiRouter.get("/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Wallet routes - protected by auth
  apiRouter.get("/user/wallets", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    
    const wallets = await storage.getWallets(userId);
    res.json(wallets);
  });

  // For wallet creation, we generate most details on the server
  // Skip validation since we're not using the request body except for optional fields
  apiRouter.post("/wallets", isAuthenticated, async (req: any, res) => {
    try {
      // Get the authenticated user ID
      const userId = req.user.claims.sub;
      
      // Check if user already has a wallet
      const existingWallets = await storage.getWallets(userId);
      if (existingWallets && existingWallets.length > 0) {
        return res.status(400).json({ 
          message: 'You already have a wallet. Joodas supports one wallet per user.',
          wallet: existingWallets[0]
        });
      }
      
      // Generate a new wallet using our Solana service
      // This will handle creating the wallet in the database
      const { address, secretKey } = await import('./services/solanaService').then(
        module => module.generateWallet(userId)
      );
      
      // Return the new wallet to the client
      const wallets = await storage.getWallets(userId);
      
      res.status(201).json({
        message: 'Wallet created successfully',
        wallet: wallets[0]
      });
    } catch (error) {
      console.error('Error creating wallet:', error);
      res.status(500).json({ message: 'Failed to create wallet' });
    }
  });

  apiRouter.put("/wallets/:id", isAuthenticated, async (req, res) => {
    const walletId = parseInt(req.params.id);
    if (isNaN(walletId)) {
      return res.status(400).json({ message: "Invalid wallet ID" });
    }

    const wallet = await storage.getWallet(walletId);
    if (!wallet) {
      return res.status(404).json({ message: "Wallet not found" });
    }

    // Ensure user only updates their own wallet
    if ((req as any).user.claims.sub !== wallet.userId) {
      return res.status(403).json({ message: "Not authorized to update this wallet" });
    }

    const updatedWallet = await storage.updateWallet(walletId, req.body);
    if (!updatedWallet) {
      return res.status(500).json({ message: "Failed to update wallet" });
    }

    res.json(updatedWallet);
  });

  // Transaction routes - protected by auth
  apiRouter.get("/user/transactions", isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    const transactions = await storage.getTransactions(userId, limit);
    res.json(transactions);
  });

  apiRouter.post("/transactions", isAuthenticated, validateRequest(insertTransactionSchema), async (req: any, res) => {
    req.body.userId = req.user.claims.sub; // Ensure transaction is created for authenticated user
    const transaction = await storage.createTransaction(req.body);
    res.status(201).json(transaction);
  });

  // Mount the main API router
  app.use("/api", apiRouter);
  
  // Mount Jupiter routes for trading
  app.use("/api/jupiter", jupiterRoutes);
  
  // Mount Solana wallet routes
  app.use("/api/wallets", walletRoutes);

  const httpServer = createServer(app);
  return httpServer;
}