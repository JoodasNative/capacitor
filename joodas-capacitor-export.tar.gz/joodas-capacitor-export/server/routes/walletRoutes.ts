import { Router, Request, Response } from 'express';
import { isAuthenticated } from '../authService';
import { storage } from '../storage';
import { 
  generateWallet,
  getWalletBalance,
  updateWalletBalance,
  getWalletTransactions,
  isValidSolanaAddress
} from '../services/solanaService';

const router = Router();

/**
 * Get all wallets for the authenticated user or by query param
 */
router.get('/', async (req: any, res: Response) => {
  try {
    let userId: string;
    
    // Handle both authenticated requests and test requests
    if (req.user?.claims?.sub) {
      // Normal authenticated request
      userId = req.user.claims.sub;
    } else {
      // For testing - user ID can be passed as a query parameter or from localStorage 
      userId = req.query.userId || 
        req.headers['x-user-id'] || 
        '42696730'; // Default test ID if none provided
    }
    
    console.log(`Fetching wallets for user ID: ${userId}`);
    const wallets = await storage.getWallets(userId);
    
    res.json(wallets);
  } catch (error) {
    console.error('Error fetching wallets:', error);
    res.status(500).json({ message: 'Failed to fetch wallets' });
  }
});

/**
 * Get a specific wallet by ID
 * Supports both authenticated users and test wallets
 */
router.get('/:id', async (req: any, res: Response) => {
  try {
    const walletId = parseInt(req.params.id);
    if (isNaN(walletId)) {
      return res.status(400).json({ message: 'Invalid wallet ID' });
    }
    
    const wallet = await storage.getWallet(walletId);
    if (!wallet) {
      return res.status(404).json({ message: 'Wallet not found' });
    }
    
    let isAuthorized = false;
    
    // Check if this is a test request (using x-user-id header)
    if (req.headers['x-user-id']) {
      const testUserId = req.headers['x-user-id'];
      console.log(`Test wallet fetch request from user ID: ${testUserId}`);
      
      // Verify the test user ID matches the wallet's user ID
      if (wallet.userId === testUserId) {
        isAuthorized = true;
      }
    } 
    // Otherwise check authentication
    else if (req.user?.claims?.sub && wallet.userId === req.user.claims.sub) {
      isAuthorized = true;
    }
    
    // Return error if not authorized
    if (!isAuthorized) {
      return res.status(403).json({ message: 'Not authorized to access this wallet' });
    }
    
    res.json(wallet);
  } catch (error) {
    console.error('Error fetching wallet:', error);
    res.status(500).json({ message: 'Failed to fetch wallet' });
  }
});

/**
 * Create a new wallet for the authenticated user
 */
router.post('/', isAuthenticated, async (req: any, res: Response) => {
  try {
    const userId = req.user.claims.sub;
    
    // Check if user already has a wallet (we're enforcing one wallet per user)
    const existingWallets = await storage.getWallets(userId);
    if (existingWallets && existingWallets.length > 0) {
      return res.status(400).json({ 
        message: 'You already have a wallet. Joodas supports one wallet per user.',
        wallet: existingWallets[0]
      });
    }
    
    // Generate a new wallet
    const { address } = await generateWallet(userId);
    
    // Retrieve the wallet from storage to get the complete object
    const wallets = await storage.getWallets(userId);
    const newWallet = wallets[0];
    
    res.status(201).json({
      message: 'Wallet created successfully',
      wallet: newWallet
    });
  } catch (error) {
    console.error('Error creating wallet:', error);
    res.status(500).json({ message: 'Failed to create wallet' });
  }
});

/**
 * Create a test wallet without authentication for development
 */
router.post('/test-create', async (req: Request, res: Response) => {
  try {
    // Use a fixed test user ID for development
    const testUserId = req.body.userId || '42696730'; // Default to a test user ID
    
    // Check if user already has a wallet
    const existingWallets = await storage.getWallets(testUserId);
    if (existingWallets && existingWallets.length > 0) {
      // Return existing wallet instead of an error
      console.log('Test user already has a wallet, returning existing wallet:', existingWallets[0]);
      return res.status(200).json({ 
        message: 'Retrieved existing wallet',
        wallet: existingWallets[0],
        isExisting: true
      });
    }
    
    console.log('Creating test wallet for user ID:', testUserId);
    
    // Generate a new wallet
    const { address } = await generateWallet(testUserId);
    
    // Retrieve the wallet from storage to get the complete object
    const wallets = await storage.getWallets(testUserId);
    const newWallet = wallets[0];
    
    // Set a flag in localStorage to show creation message
    res.setHeader('Set-Cookie', 'walletJustCreated=true; Path=/; Max-Age=60');
    
    res.status(201).json({
      message: 'Test wallet created successfully',
      wallet: newWallet
    });
  } catch (error) {
    console.error('Error creating test wallet:', error);
    res.status(500).json({ message: 'Failed to create test wallet' });
  }
});

/**
 * Update wallet balance
 * Supports both authenticated users and test wallets
 */
router.post('/:id/refresh-balance', async (req: any, res: Response) => {
  try {
    const walletId = parseInt(req.params.id);
    if (isNaN(walletId)) {
      return res.status(400).json({ message: 'Invalid wallet ID' });
    }
    
    const wallet = await storage.getWallet(walletId);
    if (!wallet) {
      return res.status(404).json({ message: 'Wallet not found' });
    }
    
    let isAuthorized = false;
    
    // Check if this is a test request (using x-user-id header)
    if (req.headers['x-user-id']) {
      const testUserId = req.headers['x-user-id'];
      console.log(`Test wallet balance update request from user ID: ${testUserId}`);
      
      // Verify the test user ID matches the wallet's user ID
      if (wallet.userId === testUserId) {
        isAuthorized = true;
      }
    } 
    // Otherwise check authentication
    else if (req.user?.claims?.sub && wallet.userId === req.user.claims.sub) {
      isAuthorized = true;
    }
    
    // Return error if not authorized
    if (!isAuthorized) {
      return res.status(403).json({ message: 'Not authorized to update this wallet' });
    }
    
    console.log(`Updating wallet balance for wallet ID: ${walletId}, address: ${wallet.address}`);
    // Update the wallet balance
    const updatedWallet = await updateWalletBalance(walletId, wallet.address);
    
    res.json({
      message: 'Wallet balance updated',
      wallet: updatedWallet
    });
  } catch (error) {
    console.error('Error updating wallet balance:', error);
    res.status(500).json({ message: 'Failed to update wallet balance' });
  }
});

/**
 * Get transactions for a wallet
 * Supports both authenticated users and test wallets
 */
router.get('/:id/transactions', async (req: any, res: Response) => {
  try {
    const walletId = parseInt(req.params.id);
    if (isNaN(walletId)) {
      return res.status(400).json({ message: 'Invalid wallet ID' });
    }
    
    const wallet = await storage.getWallet(walletId);
    if (!wallet) {
      return res.status(404).json({ message: 'Wallet not found' });
    }
    
    let isAuthorized = false;
    
    // Check if this is a test request (using x-user-id header)
    if (req.headers['x-user-id']) {
      const testUserId = req.headers['x-user-id'];
      console.log(`Test wallet transactions request from user ID: ${testUserId}`);
      
      // Verify the test user ID matches the wallet's user ID
      if (wallet.userId === testUserId) {
        isAuthorized = true;
      }
    } 
    // Otherwise check authentication
    else if (req.user?.claims?.sub && wallet.userId === req.user.claims.sub) {
      isAuthorized = true;
    }
    
    // Return error if not authorized
    if (!isAuthorized) {
      return res.status(403).json({ message: 'Not authorized to access this wallet' });
    }
    
    // Get transactions from database
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const dbTransactions = await storage.getTransactions(wallet.userId, limit);
    
    // Get on-chain transactions from Helius
    let onChainTransactions = [];
    try {
      onChainTransactions = await getWalletTransactions(wallet.address);
    } catch (err) {
      console.error('Error fetching on-chain transactions, proceeding with db transactions only:', err);
    }
    
    res.json({
      dbTransactions,
      onChainTransactions
    });
  } catch (error) {
    console.error('Error fetching wallet transactions:', error);
    res.status(500).json({ message: 'Failed to fetch wallet transactions' });
  }
});

/**
 * Validate a Solana address
 */
router.post('/validate-address', async (req: Request, res: Response) => {
  try {
    const { address } = req.body;
    
    if (!address) {
      return res.status(400).json({ message: 'Address is required' });
    }
    
    const isValid = isValidSolanaAddress(address);
    
    res.json({
      address,
      isValid
    });
  } catch (error) {
    console.error('Error validating address:', error);
    res.status(500).json({ message: 'Failed to validate address' });
  }
});

export default router;