import { Router, Request, Response } from 'express';
import { getQuote, executeSwap, hasLiquidityRisk, getSwapWarnings } from '../services/jupiterService';
import { QuoteGetRequest, SwapPostRequest } from '@jup-ag/api';

const router = Router();

/**
 * Route to get a quote for swapping tokens via Jupiter
 */
router.post('/quote', async (req: Request, res: Response) => {
  try {
    const quoteParams: QuoteGetRequest = req.body;
    
    if (!quoteParams.inputMint || !quoteParams.outputMint || !quoteParams.amount) {
      return res.status(400).json({ 
        error: 'Missing required parameters. Please provide inputMint, outputMint, and amount.' 
      });
    }
    
    const quote = await getQuote(quoteParams);
    
    // Add additional information for the client
    const response = {
      ...quote,
      hasLiquidityRisk: hasLiquidityRisk(quote),
      warnings: getSwapWarnings(quote)
    };
    
    res.json(response);
  } catch (error: any) {
    console.error('Error in /quote endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to get quote from Jupiter', 
      details: error?.message || 'Unknown error' 
    });
  }
});

/**
 * Route to execute a swap transaction via Jupiter
 */
router.post('/swap', async (req: Request, res: Response) => {
  try {
    const swapParams: SwapPostRequest = req.body;
    
    // Basic validation for swap parameters
    if (!swapParams) {
      return res.status(400).json({ 
        error: 'Missing swap parameters. Please provide valid swap data.' 
      });
    }
    
    const swap = await executeSwap(swapParams);
    
    res.json(swap);
  } catch (error: any) {
    console.error('Error in /swap endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to execute swap via Jupiter', 
      details: error?.message || 'Unknown error' 
    });
  }
});

/**
 * Route to get token prices in USD
 */
router.get('/token-price/:mintAddress', async (req: Request, res: Response) => {
  try {
    // In a real implementation, this would use a price API
    // For now, we'll return mock data
    const mintAddress = req.params.mintAddress;
    
    // Mock prices for demo purposes
    const mockPrices: Record<string, number> = {
      'So11111111111111111111111111111111111111112': 143.78, // SOL
      'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v': 1.00, // USDC
      'mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So': 150.12, // mSOL
      // Add more tokens as needed
    };
    
    const price = mockPrices[mintAddress] || 0;
    
    res.json({ 
      mint: mintAddress,
      price,
      timestamp: Date.now()
    });
  } catch (error: any) {
    console.error('Error in /token-price endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to get token price', 
      details: error?.message || 'Unknown error' 
    });
  }
});

export default router;