# Capacitor Commands for Joodas Native App

Use these commands to build and run the Joodas native app.

## Setup Commands

```bash
# Sync web code to native projects
npx cap sync

# Add native platforms
npx cap add android
npx cap add ios

# Build web code and sync to native projects
npm run build && npx cap sync
```

## Development Commands

```bash
# Open native projects in their respective IDEs
npx cap open android
npx cap open ios

# Run on devices/emulators
npx cap run android
npx cap run ios

# Run with live reload (development)
npx cap run android -l --external
npx cap run ios -l --external
```

## Build Commands

```bash
# Build Android app
cd android && ./gradlew assembleDebug

# Build iOS app (must be run on macOS)
cd ios && xcodebuild -workspace App/App.xcworkspace -scheme App build
```

## Adding Capacitor Plugins

```bash
# Install a Capacitor plugin
npm install @capacitor/plugin-name
npx cap sync
```

## Firebase Integration

Make sure the Firebase configuration in client/src/context/CapacitorAuthContext.tsx has valid values:

```typescript
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  messagingSenderId: "",
  measurementId: ""
};
```

## Notes

- Native app development requires native SDKs installed:
  - Android: Android Studio, JDK, Gradle
  - iOS: Xcode (macOS only)
- For iOS development, you must use a Mac with Xcode installed
- Firebase integration requires adding Google services files to native projects
  - Android: google-services.json in android/app/
  - iOS: GoogleService-Info.plist in ios/App/App/