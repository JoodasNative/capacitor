import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Analytics from "@/pages/Analytics";
import Settings from "@/pages/Settings";
import BuySol from "@/pages/BuySol";
import SwapSol from "@/pages/SwapSol";
import Wallet from "@/pages/Wallet";
import TradingInsights from "@/pages/TradingInsights";
import FinancialKarma from "@/pages/FinancialKarma";
import Transactions from "@/pages/Transactions";
import SeamlessOnboarding from "@/pages/SeamlessOnboarding";
import WalletSetup from "@/pages/WalletSetup";
import AuthPage from "@/pages/AuthPage";
import { FirebaseAuthProvider } from "@/context/FirebaseAuthContext";
import { WalletInitProvider } from "@/context/WalletInitContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { WalletGenerator } from "@/components/wallet/WalletGenerator";
import { WalletInitializationBlocker } from "@/components/wallet/WalletInitializationBlocker";
import { ReactNode, useEffect, useState } from "react";

// Protected layout that includes the WalletGenerator only once
// This ensures we're not creating multiple wallet generation instances
const ProtectedLayout = ({ children }: { children: ReactNode }) => (
  <ProtectedRoute>
    {/* Wallet generation is handled by this single component */}
    <WalletGenerator />
    {children}
  </ProtectedRoute>
);

function App() {
  const [emergencyMode, setEmergencyMode] = useState(true);
  
  // Detect if we have so many wallet requests we need to block
  useEffect(() => {
    const detectEmergencyMode = () => {
      // If we have a wallet, enable emergency mode
      const hasWallet = localStorage.getItem('wallet_initialization_complete') === 'true';
      
      if (hasWallet) {
        console.log('EMERGENCY MODE: User has a wallet, enabling emergency blocker');
        setEmergencyMode(true);
      } else {
        // Check URL parameters - ?emergency=true will force emergency mode
        const urlParams = new URLSearchParams(window.location.search);
        const forceEmergency = urlParams.get('emergency') === 'true';
        
        if (forceEmergency) {
          console.log('EMERGENCY MODE: Forced via URL parameter');
          setEmergencyMode(true);
        }
      }
    };
    
    detectEmergencyMode();
  }, []);

  return (
    <FirebaseAuthProvider>
      <WalletInitProvider>
        {/* Emergency blocker to immediately stop wallet creation attempts */}
        {emergencyMode && <WalletInitializationBlocker />}
        
        <TooltipProvider>
          <Toaster />
          <Switch>
          {/* Public Routes - Always accessible, NO wallet initialization */}
          <Route path="/auth" component={AuthPage} />
          <Route path="/onboarding" component={SeamlessOnboarding} />
          <Route path="/wallet-setup" component={WalletSetup} />
          <Route path="/wallet-preview" component={Wallet} />
          
          {/* Protected Routes - Require Authentication & Include Wallet Generator */}
          <Route path="/">
            <ProtectedLayout>
              <Dashboard />
            </ProtectedLayout>
          </Route>
          
          <Route path="/buy-sol">
            <ProtectedLayout>
              <BuySol />
            </ProtectedLayout>
          </Route>
          
          <Route path="/swap-sol">
            <ProtectedLayout>
              <SwapSol />
            </ProtectedLayout>
          </Route>
          
          <Route path="/analytics">
            <ProtectedLayout>
              <Analytics />
            </ProtectedLayout>
          </Route>
          
          <Route path="/settings">
            <ProtectedLayout>
              <Settings />
            </ProtectedLayout>
          </Route>
          
          <Route path="/wallet">
            <ProtectedLayout>
              <Wallet />
            </ProtectedLayout>
          </Route>
          
          <Route path="/insights">
            <ProtectedLayout>
              <TradingInsights />
            </ProtectedLayout>
          </Route>
          
          <Route path="/karma">
            <ProtectedLayout>
              <FinancialKarma />
            </ProtectedLayout>
          </Route>
          
          <Route path="/transactions">
            <ProtectedLayout>
              <Transactions />
            </ProtectedLayout>
          </Route>
          
          <Route component={NotFound} />
        </Switch>
        </TooltipProvider>
      </WalletInitProvider>
    </FirebaseAuthProvider>
  );
}

export default App;