import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

// Import AuthContext's User type
interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  walletAddress?: string;
}

interface ApiResponse<T> {
  message?: string;
  wallet?: SolanaWallet;
  [key: string]: any;
}

export interface SolanaWallet {
  id: number;
  userId: string;
  type: string;
  address: string;
  balance: number;
  isConnected: boolean;
  lastUpdated: Date;
}

/**
 * Get the user's Solana wallet
 * Works with both authenticated users and test wallets
 */
export function useUserWallet() {
  return useQuery({
    queryKey: ['/api/wallets'],
    queryFn: async () => {
      // Try to get user ID from localStorage to support test mode
      const storedUserId = localStorage.getItem('userId');
      
      // Headers setup
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      // If we have a user ID in localStorage, add it to headers
      if (storedUserId) {
        headers['x-user-id'] = storedUserId;
      }
      
      // Make request with headers
      const response = await fetch('/api/wallets', {
        headers
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch wallet data');
      }
      
      return response.json();
    },
    retry: false,
  });
}

/**
 * Get a specific wallet by ID
 */
export function useWalletById(id: number | null) {
  return useQuery({
    queryKey: ['/api/wallets', id],
    enabled: !!id,
    retry: false,
  });
}

/**
 * Create a new Solana wallet for the user
 */
export function useCreateWallet() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (params?: { userId?: string; type?: string }) => {
      // Explicitly make body empty if no params to avoid validation errors
      // This is acceptable since the API uses the authenticated user's ID 
      // from the session rather than requiring it in the body
      const body = params && Object.keys(params).length > 0 
        ? JSON.stringify(params) 
        : undefined;
        
      return apiRequest<ApiResponse<SolanaWallet>>('/api/wallets', {
        method: 'POST',
        body,
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });
      toast({
        title: 'Wallet Created',
        description: data.message || 'Your Solana wallet has been created successfully.',
      });
      
      // Also store in localStorage for quick access
      if (data.wallet?.address) {
        localStorage.setItem('userWalletAddress', data.wallet.address);
      }
    },
    onError: (error: any) => {
      toast({
        title: 'Error Creating Wallet',
        description: error.message || 'Failed to create wallet. Please try again.',
        variant: 'destructive',
      });
    },
  });
}

/**
 * Update wallet balance from the blockchain
 * Works with both authenticated users and test wallets
 */
export function useRefreshWalletBalance() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (walletId: number) => {
      // Get user ID from localStorage for test mode
      const storedUserId = localStorage.getItem('userId');
      
      // Set up headers if we have a stored user ID
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      if (storedUserId) {
        headers['x-user-id'] = storedUserId;
      }
      
      // Make the request with proper headers
      const response = await fetch(`/api/wallets/${walletId}/refresh-balance`, {
        method: 'POST',
        headers,
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to update wallet balance');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });
      toast({
        title: 'Balance Updated',
        description: `Your wallet balance is now ${data.wallet?.balance || 0} SOL`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error Updating Balance',
        description: error.message || 'Failed to update wallet balance. Please try again.',
        variant: 'destructive',
      });
    },
  });
}

/**
 * Get wallet transactions
 * Works with both authenticated users and test wallets
 */
export function useWalletTransactions(walletId: number | null, limit: number = 10) {
  return useQuery({
    queryKey: ['/api/wallets', walletId, 'transactions', { limit }],
    enabled: !!walletId,
    queryFn: async ({ queryKey }) => {
      // Get user ID from localStorage for test mode
      const storedUserId = localStorage.getItem('userId');
      
      // Headers setup
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      // If we have a user ID in localStorage, add it to headers
      if (storedUserId) {
        headers['x-user-id'] = storedUserId;
      }
      
      // Make request with headers
      const response = await fetch(`/api/wallets/${walletId}/transactions?limit=${limit}`, {
        headers
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch transaction data');
      }
      
      return response.json();
    },
    retry: false,
  });
}

/**
 * Validate a Solana address
 */
export function useValidateSolanaAddress() {
  return useMutation({
    mutationFn: async (address: string) => {
      return apiRequest<{ address: string; isValid: boolean }>('/api/wallets/validate-address', {
        method: 'POST',
        body: JSON.stringify({ address }),
      });
    },
  });
}

/**
 * Generate a wallet on first login if one doesn't exist
 */
export function useGenerateWalletOnFirstLogin() {
  const { data: wallets, isLoading: isLoadingWallets, isError, error } = useUserWallet();
  const createWallet = useCreateWallet();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [attemptedWalletGeneration, setAttemptedWalletGeneration] = useState(() => {
    return localStorage.getItem('wallet_generation_attempted') === 'true';
  });
  
  // Function to check and create wallet if needed
  const generateWalletIfNeeded = async (user: User | null | undefined) => {
    // Check if we've already attempted wallet generation in this session
    if (attemptedWalletGeneration) {
      console.log('Already attempted wallet generation this session, skipping');
      return;
    }
    
    // Mark that we've attempted wallet generation in state and localStorage
    setAttemptedWalletGeneration(true);
    localStorage.setItem('wallet_generation_attempted', 'true');
    
    // SECURITY CHECK: Only create wallets for properly authenticated users with ID
    if (!user || !user.id) {
      console.log('No authenticated user with ID found, cannot generate wallet');
      return;
    }
    
    // Wait for wallet data to load before proceeding
    if (isLoadingWallets) {
      console.log('Still loading wallets, waiting...');
      return;
    }
    
    // Check for unauthorized errors (user may need to login)
    if (isError) {
      console.error('Error fetching wallets:', error);
      // Don't attempt wallet creation on auth errors
      if ((error as any)?.status === 401) {
        console.log('User needs to login first');
        return;
      }
    }
    
    // Check if user already has a wallet
    if (Array.isArray(wallets) && wallets.length > 0) {
      console.log('User already has a wallet:', wallets[0]);
      
      // Store the wallet address in localStorage for easier access
      if (wallets[0]?.address) {
        localStorage.setItem('userWalletAddress', wallets[0].address);
      }
      return;
    }
    
    // ONLY create a wallet if user has NO wallets
    if (Array.isArray(wallets) && wallets.length === 0) {
      console.log('No wallets found, creating one for authenticated user:', user.id);
      try {
        // Normal authenticated user wallet creation - DO NOT include userId in the payload
        // Let the server get it from the authenticated session
        const result = await createWallet.mutateAsync({});
        console.log('Wallet created successfully:', result);
        
        // Refresh wallet data in UI
        queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });
        
        toast({
          title: 'Welcome to Joodas!',
          description: 'Your personal Solana wallet has been created automatically.',
        });
      } catch (error) {
        // Check if error is just "You already have a wallet"
        const errorMessage = (error as any)?.message || '';
        if (errorMessage.includes('already have a wallet')) {
          console.log('User already has a wallet (from error message)');
          // Refresh wallet data to get the existing wallet
          queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });
        } else {
          console.error('Error generating wallet on first login:', error);
          toast({
            title: 'Wallet Creation Failed',
            description: 'There was an error creating your wallet. Please try again later.',
            variant: 'destructive',
          });
        }
      }
    }
  };
  
  return {
    generateWalletIfNeeded,
    isCreatingWallet: createWallet.isPending,
    wallets,
    isLoadingWallets,
    hasAttemptedGeneration: attemptedWalletGeneration
  };
}

/**
 * Format a wallet address for display (truncate middle)
 */
export function formatWalletAddress(address: string): string {
  if (!address) return '';
  if (address.length <= 12) return address;
  
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}