import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Guild } from "@shared/schema";

export function useGuilds(userId: number = 1) {
  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [userGuilds, setUserGuilds] = useState<Guild[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchGuilds = async () => {
      try {
        setIsLoading(true);
        
        // Fetch all guilds
        const allGuilds = await queryClient.fetchQuery({
          queryKey: ['/api/guilds'],
        });
        
        // Fetch user's guilds
        const userGuildsResult = await queryClient.fetchQuery({
          queryKey: [`/api/users/${userId}/guilds`],
        });
        
        setGuilds(allGuilds || []);
        setUserGuilds(userGuildsResult || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching guilds:", err);
        setError(err instanceof Error ? err : new Error("Failed to fetch guilds"));
        toast({
          title: "Error",
          description: "Failed to load guild data",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchGuilds();
  }, [userId]);

  const createGuild = async (guildData: { name: string; description?: string }) => {
    try {
      await queryClient.fetchQuery({
        queryKey: ['/api/guilds'],
        queryFn: async () => {
          const response = await fetch('/api/guilds', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              ...guildData,
              creatorId: userId,
            }),
          });
          
          if (!response.ok) {
            throw new Error('Failed to create guild');
          }
          
          return response.json();
        },
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/guilds`] });
      
      toast({
        title: "Success",
        description: "Guild created successfully",
      });
    } catch (err) {
      console.error("Error creating guild:", err);
      toast({
        title: "Error",
        description: "Failed to create guild",
        variant: "destructive",
      });
      throw err;
    }
  };

  const joinGuild = async (guildId: number) => {
    try {
      await queryClient.fetchQuery({
        queryKey: ['/api/guild-members'],
        queryFn: async () => {
          const response = await fetch('/api/guild-members', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              guildId,
              userId,
              role: 'member',
            }),
          });
          
          if (!response.ok) {
            throw new Error('Failed to join guild');
          }
          
          return response.json();
        },
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/guilds`] });
      
      toast({
        title: "Success",
        description: "Successfully joined guild",
      });
    } catch (err) {
      console.error("Error joining guild:", err);
      toast({
        title: "Error",
        description: "Failed to join guild",
        variant: "destructive",
      });
      throw err;
    }
  };

  const leaveGuild = async (guildId: number) => {
    try {
      await queryClient.fetchQuery({
        queryKey: [`/api/guilds/${guildId}/members/${userId}`],
        queryFn: async () => {
          const response = await fetch(`/api/guilds/${guildId}/members/${userId}`, {
            method: 'DELETE',
          });
          
          if (!response.ok) {
            throw new Error('Failed to leave guild');
          }
          
          return null;
        },
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/guilds`] });
      
      toast({
        title: "Success",
        description: "Left guild successfully",
      });
    } catch (err) {
      console.error("Error leaving guild:", err);
      toast({
        title: "Error",
        description: "Failed to leave guild",
        variant: "destructive",
      });
      throw err;
    }
  };

  return { 
    guilds, 
    userGuilds, 
    isLoading, 
    error, 
    createGuild,
    joinGuild,
    leaveGuild
  };
}
