import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/context/WalletContext";

interface Transaction {
  id: number;
  userId: number;
  walletId: number;
  type: string;
  amount: number;
  token: string;
  date: Date;
  status: string;
  note?: string;
}

export function useTransactions(userId: number = 1, limit: number = 10) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { isConnected } = useWallet();
  const { toast } = useToast();

  useEffect(() => {
    const fetchTransactions = async () => {
      if (!isConnected) {
        setTransactions([]);
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        const result = await queryClient.fetchQuery({
          queryKey: [`/api/users/${userId}/transactions?limit=${limit}`],
        });
        
        // Format dates
        const formattedTransactions = result.map((tx: any) => ({
          ...tx,
          date: new Date(tx.date)
        }));
        
        setTransactions(formattedTransactions || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching transactions:", err);
        setError(err instanceof Error ? err : new Error("Failed to fetch transactions"));
        toast({
          title: "Error",
          description: "Failed to load transaction data",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchTransactions();
  }, [userId, limit, isConnected]);

  const addTransaction = async (transaction: Omit<Transaction, 'id' | 'date'>) => {
    try {
      await queryClient.fetchQuery({
        queryKey: ['/api/transactions'],
        queryFn: async () => {
          const response = await fetch('/api/transactions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(transaction),
          });
          
          if (!response.ok) {
            throw new Error('Failed to add transaction');
          }
          
          return response.json();
        },
      });
      
      // Invalidate transactions query to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/transactions`] });
      
      toast({
        title: "Success",
        description: "Transaction added successfully",
      });
    } catch (err) {
      console.error("Error adding transaction:", err);
      toast({
        title: "Error",
        description: "Failed to add transaction",
        variant: "destructive",
      });
      throw err;
    }
  };

  return { transactions, isLoading, error, addTransaction };
}

export function useTransactionsByPeriod(userId: number = 1, period: 'today' | 'week' | 'month' = 'today') {
  const { transactions, isLoading, error } = useTransactions(userId, 50);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    if (!isLoading && transactions.length > 0) {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - today.getDay());
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      const filtered = transactions.filter(tx => {
        const txDate = new Date(tx.date);
        
        if (period === 'today') {
          return txDate >= today;
        } else if (period === 'week') {
          return txDate >= startOfWeek;
        } else if (period === 'month') {
          return txDate >= startOfMonth;
        }
        
        return true;
      });
      
      setFilteredTransactions(filtered);
    } else {
      setFilteredTransactions([]);
    }
  }, [transactions, isLoading, period]);

  return { transactions: filteredTransactions, isLoading, error };
}
