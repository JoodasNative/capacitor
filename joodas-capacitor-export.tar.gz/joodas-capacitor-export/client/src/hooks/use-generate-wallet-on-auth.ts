import { useEffect, useState } from 'react';
import { useFirebaseAuth } from '@/context/FirebaseAuthContext';
import { useWalletInit } from '@/context/WalletInitContext';
import { useCreateWallet, useUserWallet } from './use-solana-wallet';

/**
 * Hook to generate a wallet when a user logs in with Firebase auth
 * This ensures every authenticated user has a wallet
 */
export function useGenerateWalletOnAuth() {
  const { currentUser } = useFirebaseAuth();
  const createWalletMutation = useCreateWallet();
  const { data: wallets, isLoading: isLoadingWallets } = useUserWallet();
  const { hasInitializedWallet, markWalletInitialized } = useWalletInit();
  
  // Global one-time check based on our app-wide context
  useEffect(() => {
    // ABSOLUTE GUARD: If global initialization flag is true, we do nothing ever
    if (hasInitializedWallet) {
      console.log("GLOBAL WALLET INIT STATE: Already initialized wallet in this session, skipping completely");
      return;
    }
    
    const checkAndCreateWallet = async () => {
      // Only proceed if we have a fully authenticated user with a valid UID
      // AND wallet data loading is complete
      // AND global initialization hasn't happened
      if (currentUser && 
          currentUser.uid && 
          currentUser.email && 
          !isLoadingWallets &&
          !hasInitializedWallet) {
        try {
          // Log that we're checking for a wallet only for verified users
          console.log("ONE-TIME WALLET CHECK: Authenticated user detected, checking for wallet:", currentUser.uid);
          
          // Store user ID for convenience
          if (localStorage.getItem('userId') !== currentUser.uid) {
            localStorage.setItem('userId', currentUser.uid);
          }
          
          // CRITICAL: Only create a wallet if the user doesn't already have one
          if (Array.isArray(wallets) && wallets.length === 0) {
            console.log("ONE-TIME WALLET CREATION: User has no wallet, creating one for:", currentUser.uid);
            
            // Only attempt wallet creation for authenticated users who don't have a wallet
            try {
              const result = await createWalletMutation.mutateAsync({
                userId: currentUser.uid,
                type: 'solana'
              });
              console.log('ONE-TIME WALLET CREATION: Success:', result);
            } catch (err) {
              console.error('ONE-TIME WALLET CREATION: Failed with error:', err);
              const errorMessage = (err as any)?.message || '';
              
              // If the error is that wallet already exists, we can proceed
              if (errorMessage.includes('already have a wallet')) {
                console.log('ONE-TIME WALLET CREATION: User already has a wallet (from error message)');
              } else {
                throw err; // Re-throw if it's a different error
              }
            }
          } else {
            console.log('WALLET CHECK: User already has a wallet, skipping creation');
          }
          
          // Mark wallet as initialized in global context - THIS STOPS ALL FUTURE ATTEMPTS
          markWalletInitialized();
        } catch (error) {
          console.error('CRITICAL ERROR during wallet initialization:', error);
          // Still mark as initialized to prevent repeated error attempts
          markWalletInitialized();
        }
      }
    };
    
    // Only attempt once if we have the right conditions
    if (currentUser && 
        currentUser.uid && 
        currentUser.email && 
        !isLoadingWallets &&
        !hasInitializedWallet) {
      checkAndCreateWallet();
    }
  }, [currentUser, createWalletMutation, wallets, isLoadingWallets, hasInitializedWallet, markWalletInitialized]);
}