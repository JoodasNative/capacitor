import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  username: string;
  walletAddress?: string;
  degenScore: number;
  level: number;
  xp: number;
  badges: string[];
}

export function useDegenScore(userId: number = 1) {
  const [userData, setUserData] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setIsLoading(true);
        const result = await queryClient.fetchQuery({
          queryKey: [`/api/users/${userId}`],
        });
        setUserData(result || null);
        setError(null);
      } catch (err) {
        console.error("Error fetching user data:", err);
        setError(err instanceof Error ? err : new Error("Failed to fetch user data"));
        toast({
          title: "Error",
          description: "Failed to load degen score data",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  const updateDegenScore = async (scoreChange: number) => {
    if (!userData) return;
    
    try {
      const newScore = userData.degenScore + scoreChange;
      
      await queryClient.fetchQuery({
        queryKey: [`/api/users/${userId}`],
        queryFn: async () => {
          const response = await fetch(`/api/users/${userId}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ degenScore: newScore }),
          });
          
          if (!response.ok) {
            throw new Error('Failed to update degen score');
          }
          
          return response.json();
        },
      });
      
      // Invalidate user query to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      
      toast({
        title: "Score Updated",
        description: scoreChange > 0 
          ? `Gained ${scoreChange} degen points!` 
          : `Lost ${Math.abs(scoreChange)} degen points!`,
      });
    } catch (err) {
      console.error("Error updating degen score:", err);
      toast({
        title: "Error",
        description: "Failed to update degen score",
        variant: "destructive",
      });
    }
  };

  const calculateLevelProgress = () => {
    if (!userData) return 0;
    
    // Simple level progress calculation
    const nextLevelXP = userData.level * 1000;
    const currentLevelXP = (userData.level - 1) * 1000;
    const userXP = userData.xp;
    
    const progress = ((userXP - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
    return Math.min(Math.max(progress, 0), 100); // Clamp between 0 and 100
  };

  return { 
    userData, 
    isLoading, 
    error, 
    updateDegenScore,
    levelProgress: calculateLevelProgress(),
    nextLevel: userData ? userData.level + 1 : 1
  };
}

export function useNextBadge(userId: number = 1) {
  const { userData, isLoading } = useDegenScore(userId);
  
  // Calculate next badge based on degen score
  const getNextBadge = () => {
    if (!userData) return { name: "Novice Trader", threshold: 100, progress: 0 };
    
    const degenScore = userData.degenScore;
    const badges = [
      { name: "Novice Trader", threshold: 100 },
      { name: "Paper Hands", threshold: 300 },
      { name: "Dip Buyer", threshold: 500 },
      { name: "Rug Survivor", threshold: 800 },
      { name: "Diamond Hander", threshold: 1000 },
      { name: "Degen Disciple", threshold: 1500 },
      { name: "Crypto Whale", threshold: 2000 }
    ];
    
    // Find the next badge to achieve
    const currentBadgeIndex = badges.findIndex(badge => badge.threshold > degenScore);
    const nextBadge = currentBadgeIndex !== -1 ? badges[currentBadgeIndex] : badges[badges.length - 1];
    
    // Calculate progress towards next badge
    const prevThreshold = currentBadgeIndex > 0 ? badges[currentBadgeIndex - 1].threshold : 0;
    const progress = ((degenScore - prevThreshold) / (nextBadge.threshold - prevThreshold)) * 100;
    
    return {
      name: nextBadge.name,
      threshold: nextBadge.threshold,
      progress: Math.min(Math.max(progress, 0), 100) // Clamp between 0 and 100
    };
  };
  
  return { nextBadge: getNextBadge(), isLoading };
}
