import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';

/**
 * Custom hook for quick wallet setup operations
 * This allows wallet creation without requiring full authentication
 */
export function useTestWallet(userId: string = '') {
  // Get wallets for a test user
  const { data: wallets, isLoading, refetch } = useQuery<any[]>({
    queryKey: ['/api/wallets', userId],
    enabled: !!userId,
  });

  // Create a new test wallet
  const createTestWallet = useMutation({
    mutationFn: async (testUserId: string) => {
      console.log('Creating test wallet for user ID:', testUserId);
      const response = await fetch('/api/wallets/test-create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: testUserId }),
      });
      
      const responseData = await response.json();
      console.log('Wallet creation response:', responseData);
      
      if (!response.ok) {
        throw new Error(responseData.message || 'Failed to create test wallet');
      }
      
      return responseData;
    },
    onSuccess: (data) => {
      console.log('Wallet created successfully:', data);
      
      // Invalidate wallets query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/wallets'] });
      
      // Store wallet address in localStorage for quick access
      if (data.wallet?.address) {
        localStorage.setItem('userWalletAddress', data.wallet.address);
        localStorage.setItem('userWalletId', String(data.wallet.id));
        localStorage.setItem('walletJustCreated', 'true');
        console.log('Wallet data saved to localStorage');
      }
      
      toast({
        title: 'Success!',
        description: data.wallet?.address 
          ? `Wallet created: ${data.wallet.address.substring(0, 8)}...${data.wallet.address.substring(data.wallet.address.length - 8)}`
          : 'Test wallet created successfully',
      });
      
      // Force refetch to update UI immediately
      setTimeout(() => {
        refetch();
      }, 500);
    },
    onError: (error: Error) => {
      console.error('Error creating test wallet:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create test wallet',
        variant: 'destructive',
      });
    },
  });

  return {
    wallets,
    isLoading,
    refetch,
    createTestWallet: createTestWallet.mutate,
    isCreating: createTestWallet.isPending,
    creationError: createTestWallet.error,
  };
}