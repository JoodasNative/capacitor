import { useQuery } from "@tanstack/react-query";

// We'll use a general User type here
export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  walletAddress?: string;
  degenScore?: number;
  level?: number;
  xp?: number;
}

// This hook is used directly in the AuthContext
export function useAuthQuery() {
  return useQuery({
    queryKey: ["/api/auth/user"],
    staleTime: Infinity,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

// This function can be used to redirect to login
export function redirectToLogin() {
  window.location.href = '/api/login';
}

// This function can be used to redirect to logout
export function redirectToLogout() {
  window.location.href = '/api/logout';
}