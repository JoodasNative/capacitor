import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { LeaderboardEntry } from "@shared/schema";

export function useLeaderboard(category: 'trading' | 'savings' | 'overall' = 'trading', limit: number = 10) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        setIsLoading(true);
        const result = await queryClient.fetchQuery({
          queryKey: [`/api/leaderboard/${category}?limit=${limit}`],
        });
        setEntries(result || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching leaderboard:", err);
        setError(err instanceof Error ? err : new Error("Failed to fetch leaderboard"));
        
        // Generate mock entries for demo purposes if API fails
        // In a real application, we would show a proper error state
        const mockEntries = [];
        for (let i = 1; i <= 5; i++) {
          mockEntries.push({
            id: i,
            userId: i,
            guildId: i % 3 === 0 ? 1 : null,
            score: 1000 - (i * 100) + Math.floor(Math.random() * 50),
            rank: i,
            category,
            week: new Date()
          });
        }
        setEntries(mockEntries);
        
        toast({
          title: "Error",
          description: "Failed to load leaderboard data",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchLeaderboard();
  }, [category, limit]);

  const getUserRank = (userId: number) => {
    const entry = entries.find(e => e.userId === userId);
    return entry ? entry.rank : null;
  };

  const getTopEntries = (count: number = 3) => {
    return entries.slice(0, count);
  };

  return { 
    entries, 
    isLoading, 
    error,
    getUserRank,
    getTopEntries
  };
}
