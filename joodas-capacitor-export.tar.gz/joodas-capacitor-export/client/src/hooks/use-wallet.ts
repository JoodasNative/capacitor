import { useState, useEffect } from "react";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Wallet {
  id: number;
  userId: number;
  type: string;
  address: string;
  balance: number;
  isConnected: boolean;
  lastUpdated: Date;
}

export function useUserWallets(userId: number = 1) {
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Mock data for development
  useEffect(() => {
    // Simulate loading
    setIsLoading(true);
    
    // Mock wallet data
    const mockWallets: Wallet[] = [
      {
        id: 1,
        userId: 1,
        type: "ethereum",
        address: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
        balance: 2.45,
        isConnected: true,
        lastUpdated: new Date()
      },
      {
        id: 2,
        userId: 1,
        type: "solana",
        address: "SoL1iDhand3rXdeGen5uRV1v3rBaDg3",
        balance: 45.12,
        isConnected: true,
        lastUpdated: new Date()
      }
    ];
    
    // Set wallets after a small delay to simulate API call
    setTimeout(() => {
      setWallets(mockWallets);
      setIsLoading(false);
    }, 500);
  }, [userId]);

  return { wallets, isLoading, error };
}

export function useTotalBalance() {
  const { wallets, isLoading } = useUserWallets();
  const [totalBalance, setTotalBalance] = useState(0);

  useEffect(() => {
    if (!isLoading && wallets.length > 0) {
      const total = wallets.reduce((sum, wallet) => sum + wallet.balance, 0);
      setTotalBalance(total);
    }
  }, [wallets, isLoading]);

  return { totalBalance, isLoading };
}
