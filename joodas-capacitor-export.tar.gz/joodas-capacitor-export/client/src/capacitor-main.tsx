import React from 'react';
import ReactDOM from 'react-dom/client';
import CapacitorAppComponent from './CapacitorApp';
import './index.css';
import { Capacitor } from '@capacitor/core';

// Wait for the device to be ready before mounting the app
const mountApp = () => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <CapacitorAppComponent />
    </React.StrictMode>
  );
};

// Check if we're running in a Capacitor environment
if (Capacitor.isNativePlatform()) {
  // Listen for deviceready event in native environments
  document.addEventListener('deviceready', mountApp, false);
} else {
  // In web environments, just mount the app
  mountApp();
}

// Add handling for hardware back button (Android)
document.addEventListener('backbutton', () => {
  console.log('Back button pressed');
}, false);