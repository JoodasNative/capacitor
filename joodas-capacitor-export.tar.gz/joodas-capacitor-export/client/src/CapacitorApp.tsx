import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Analytics from "@/pages/Analytics";
import Settings from "@/pages/Settings";
import BuySol from "@/pages/BuySol";
import SwapSol from "@/pages/SwapSol";
import Wallet from "@/pages/Wallet";
import TradingInsights from "@/pages/TradingInsights";
import FinancialKarma from "@/pages/FinancialKarma";
import Transactions from "@/pages/Transactions";
import SeamlessOnboarding from "@/pages/SeamlessOnboarding";
import WalletSetup from "@/pages/WalletSetup";
import AuthPage from "@/pages/AuthPage";

import { CapacitorAuthProvider, useAuth } from "@/context/CapacitorAuthContext";
import { CapacitorWalletProvider } from "@/context/CapacitorWalletContext";
import { WalletInitProvider } from "@/context/WalletInitContext";
import { ReactNode, useEffect } from "react";
import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

// Protected route component for Capacitor
const CapacitorProtectedRoute = ({ children }: { children: ReactNode }) => {
  const { currentUser, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-gold border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!isAuthenticated || !currentUser) {
    // Redirect to auth page for non-authenticated users
    window.location.href = '/auth';
    return null;
  }

  return <>{children}</>;
};

// Main application component adapted for Capacitor
export function CapacitorAppComponent() {
  const isNative = Capacitor.isNativePlatform();

  // Add back button listener for native platforms
  useEffect(() => {
    if (isNative) {
      const handleBackButton = () => {
        // Handle the back button action
        console.log('Back button pressed');
        
        // Get current path
        const currentPath = window.location.pathname;
        
        // If on home page, confirm exit app
        if (currentPath === '/') {
          if (window.confirm('Do you want to exit the app?')) {
            App.exitApp();
          }
        } else {
          // Otherwise, go back in history
          window.history.back();
        }
      };
      
      // Add the back button listener
      App.addListener('backButton', handleBackButton);
      
      // Clean up
      return () => {
        App.removeAllListeners();
      };
    }
  }, [isNative]);

  return (
    <CapacitorAuthProvider>
      <WalletInitProvider>
        <CapacitorWalletProvider>
          <TooltipProvider>
            <Toaster />
            <Switch>
              {/* Public Routes - Always accessible, NO wallet initialization */}
              <Route path="/auth" component={AuthPage} />
              <Route path="/onboarding" component={SeamlessOnboarding} />
              <Route path="/wallet-setup" component={WalletSetup} />
              
              {/* Protected Routes - Require Authentication */}
              <Route path="/">
                <CapacitorProtectedRoute>
                  <Dashboard />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/buy-sol">
                <CapacitorProtectedRoute>
                  <BuySol />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/swap-sol">
                <CapacitorProtectedRoute>
                  <SwapSol />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/analytics">
                <CapacitorProtectedRoute>
                  <Analytics />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/settings">
                <CapacitorProtectedRoute>
                  <Settings />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/wallet">
                <CapacitorProtectedRoute>
                  <Wallet />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/insights">
                <CapacitorProtectedRoute>
                  <TradingInsights />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/karma">
                <CapacitorProtectedRoute>
                  <FinancialKarma />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route path="/transactions">
                <CapacitorProtectedRoute>
                  <Transactions />
                </CapacitorProtectedRoute>
              </Route>
              
              <Route component={NotFound} />
            </Switch>
          </TooltipProvider>
        </CapacitorWalletProvider>
      </WalletInitProvider>
    </CapacitorAuthProvider>
  );
}

export default CapacitorAppComponent;