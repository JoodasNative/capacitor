import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface BadgeAnimatedProps {
  label: string;
  variant?: "default" | "destructive" | "outline" | "secondary";
  delay?: number;
  className?: string;
}

export function BadgeAnimated({
  label,
  variant = "outline",
  delay = 0,
  className
}: BadgeAnimatedProps) {
  // Map badges to icons and colors with premium styling
  const badgeConfig: Record<string, { icon: string; className: string; premium?: boolean }> = {
    "Diamond Hands": { 
      icon: "ri-hand-coin-line", 
      className: "bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100",
      premium: true 
    },
    "Diamond Hander": { 
      icon: "ri-hand-coin-line", 
      className: "bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100",
      premium: true 
    },
    "Rug Survivor": { 
      icon: "ri-earthquake-line", 
      className: "bg-amber-50 text-amber-600 border border-amber-200 hover:bg-amber-100" 
    },
    "Paper Hands": { 
      icon: "ri-file-paper-2-line", 
      className: "bg-gray-50 text-gray-600 border border-gray-200 hover:bg-gray-100" 
    },
    "Dip Buyer": { 
      icon: "ri-arrow-down-circle-line", 
      className: "bg-green-50 text-green-600 border border-green-200 hover:bg-green-100" 
    },
    "Degen Disciple": { 
      icon: "ri-sword-line", 
      className: "bg-purple-50 text-purple-600 border border-purple-200 hover:bg-purple-100",
      premium: true 
    },
    "Crypto Whale": { 
      icon: "ri-whale-line", 
      className: "bg-indigo-50 text-indigo-600 border border-indigo-200 hover:bg-indigo-100",
      premium: true 
    },
    "Novice Trader": { 
      icon: "ri-user-star-line", 
      className: "bg-gray-50 text-gray-600 border border-gray-200 hover:bg-gray-100" 
    },
    "HODL Master": {
      icon: "ri-time-line",
      className: "bg-poshGold/10 text-poshGold border border-poshGold/20 hover:bg-poshGold/20",
      premium: true
    },
    "Trend Spotter": {
      icon: "ri-line-chart-line",
      className: "bg-green-50 text-green-600 border border-green-200 hover:bg-green-100",
      premium: true
    }
  };

  const config = badgeConfig[label] || { 
    icon: "ri-medal-line", 
    className: "bg-poshGold/10 text-poshGold border border-poshGold/20 hover:bg-poshGold/20"
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay, type: "spring", stiffness: 200, damping: 10 }}
      whileHover={{ scale: 1.05 }}
      className="relative"
    >
      {/* Premium badge indicator */}
      {config.premium && (
        <motion.span 
          className="absolute -top-1 -right-1 w-2 h-2 bg-poshGold rounded-full shadow-sm shadow-amber-200"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: delay + 0.2, type: "spring" }}
        />
      )}
      
      <Badge 
        variant={variant} 
        className={cn(
          "px-3 py-1 gap-1.5 font-medium text-xs rounded-full shadow-sm", 
          config.className,
          className
        )}
      >
        <i className={config.icon}></i>
        {label}
      </Badge>
    </motion.div>
  );
}
