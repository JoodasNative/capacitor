import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Guild } from "@shared/schema";
import { motion } from "framer-motion";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface GuildCardProps {
  guild: Guild;
  isMember: boolean;
  delay?: number;
}

export function GuildCard({ guild, isMember, delay = 0 }: GuildCardProps) {
  const [isJoining, setIsJoining] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const { toast } = useToast();
  
  const handleJoinGuild = async () => {
    try {
      setIsJoining(true);
      
      await apiRequest('POST', '/api/guild-members', {
        guildId: guild.id,
        userId: 1, // In a real app, use the logged-in user ID
        role: 'member'
      });
      
      toast({
        title: "Guild Joined",
        description: `You have joined ${guild.name}. Welcome!`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/guilds'] });
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      
    } catch (error) {
      console.error("Failed to join guild:", error);
      toast({
        title: "Error",
        description: "Failed to join guild. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsJoining(false);
    }
  };
  
  const handleLeaveGuild = async () => {
    try {
      setIsLeaving(true);
      
      await apiRequest('DELETE', `/api/guilds/${guild.id}/members/1`);
      
      toast({
        title: "Guild Left",
        description: `You have left ${guild.name}.`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/guilds'] });
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      
    } catch (error) {
      console.error("Failed to leave guild:", error);
      toast({
        title: "Error",
        description: "Failed to leave guild. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLeaving(false);
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="card p-4 mb-3">
        <div className="flex justify-between items-start mb-1">
          <div>
            <h3 className="font-cinzel font-medium">{guild.name}</h3>
            <p className="text-xs text-softWhite/70">{guild.description || "No description"}</p>
          </div>
          <div className="flex items-center bg-mediumCharcoal px-2 py-1 rounded text-xs">
            <i className="ri-award-line text-poshGold mr-1"></i>
            Level {guild.level}
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 my-3 text-center">
          <div>
            <div className="text-sm font-medium">{guild.memberCount}</div>
            <div className="text-xs text-softWhite/60">Members</div>
          </div>
          <div>
            <div className="text-sm font-medium">{guild.xp}</div>
            <div className="text-xs text-softWhite/60">XP</div>
          </div>
          <div>
            <div className="text-sm font-medium">#{Math.floor(Math.random() * 10) + 1}</div>
            <div className="text-xs text-softWhite/60">Rank</div>
          </div>
        </div>
        
        <div className="flex justify-end">
          {isMember ? (
            <Button 
              variant="outline" 
              size="sm"
              className="border-poshGold/50 text-poshGold hover:bg-poshGold/10"
              onClick={handleLeaveGuild}
              disabled={isLeaving}
            >
              {isLeaving ? <i className="ri-loader-4-line animate-spin mr-1"></i> : null}
              Leave Guild
            </Button>
          ) : (
            <Button 
              variant="default" 
              size="sm"
              className="bg-poshGold text-darkCharcoal hover:bg-poshGold/90"
              onClick={handleJoinGuild}
              disabled={isJoining}
            >
              {isJoining ? <i className="ri-loader-4-line animate-spin mr-1"></i> : null}
              Join Guild
            </Button>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
