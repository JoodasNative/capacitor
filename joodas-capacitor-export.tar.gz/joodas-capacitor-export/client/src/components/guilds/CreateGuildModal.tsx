import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useDegenScore } from "@/hooks/use-degen-score";

interface CreateGuildModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateGuildModal({ open, onOpenChange }: CreateGuildModalProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();
  const { userData } = useDegenScore();
  
  const handleCreateGuild = async () => {
    if (!name) {
      toast({
        title: "Error",
        description: "Guild name is required",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsCreating(true);
      
      await apiRequest('POST', '/api/guilds', {
        name,
        description,
        creatorId: userData?.id || 1, // In a real app, use the logged-in user ID
      });
      
      toast({
        title: "Guild Created",
        description: `Successfully created ${name}`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/guilds'] });
      queryClient.invalidateQueries({ queryKey: ['/api/guilds'] });
      
      // Reset form
      setName("");
      setDescription("");
      
      // Close modal
      onOpenChange(false);
      
    } catch (error) {
      console.error("Failed to create guild:", error);
      toast({
        title: "Error",
        description: "Failed to create guild. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-darkCharcoal border-mediumCharcoal text-softWhite sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-cinzel text-xl">Create New Guild</DialogTitle>
          <DialogDescription className="text-softWhite/70">
            Form your own trading guild and recruit other degens
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Guild Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Diamond Hands Society"
              className="bg-mediumCharcoal border-none"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="We buy dips and never sell..."
              className="bg-mediumCharcoal border-none min-h-[100px]"
            />
          </div>
          
          <div className="bg-poshGold/10 p-3 rounded-md text-sm">
            <div className="flex items-center mb-2">
              <i className="ri-information-line text-poshGold mr-2"></i>
              <span className="font-medium">Guild Benefits</span>
            </div>
            <ul className="text-xs text-softWhite/80 pl-5 list-disc space-y-1">
              <li>Group savings and collaborative trading</li>
              <li>Weekly XP bonuses for active members</li>
              <li>Exclusive access to guild challenges</li>
              <li>Compete in guild wars for rewards</li>
            </ul>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isCreating}
            className="border-mediumCharcoal text-softWhite/70 hover:bg-mediumCharcoal"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleCreateGuild}
            disabled={isCreating}
            className="bg-poshGold text-darkCharcoal hover:bg-poshGold/90"
          >
            {isCreating ? <i className="ri-loader-4-line animate-spin mr-1"></i> : null}
            Create Guild
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
