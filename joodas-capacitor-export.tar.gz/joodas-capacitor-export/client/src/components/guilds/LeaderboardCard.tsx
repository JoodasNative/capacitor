import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";
import { useLeaderboard } from "@/hooks/use-leaderboard";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";

export function LeaderboardCard() {
  const [category, setCategory] = useState<'trading' | 'savings' | 'overall'>('trading');
  const { entries, isLoading } = useLeaderboard(category);
  
  const formatUserName = (userId: number) => {
    // In a real app, fetch the actual username from the user ID
    const usernames = ["degen_trader", "diamond_hands", "eth_maxi", "sol_sailor", "btc_warrior"];
    return usernames[userId % usernames.length] || `user${userId}`;
  };
  
  const getAvatarIcon = (userId: number) => {
    const icons = ["ri-user-3-line", "ri-alien-line", "ri-ghost-line", "ri-robot-line", "ri-bear-smile-line"];
    return icons[userId % icons.length] || "ri-user-3-line";
  };
  
  const getLeaderColor = (rank: number) => {
    if (rank === 1) return "text-yellow-500";
    if (rank === 2) return "text-gray-300";
    if (rank === 3) return "text-amber-600";
    return "text-softWhite";
  };
  
  const getScoreBarColor = (score: number, maxScore: number) => {
    const percentage = (score / maxScore) * 100;
    if (percentage > 80) return "gold-gradient";
    if (percentage > 50) return "bg-blue-500";
    if (percentage > 30) return "bg-purple-500";
    return "bg-slate-500";
  };
  
  return (
    <Card className="card overflow-hidden">
      <Tabs defaultValue="trading" className="w-full" onValueChange={(val) => setCategory(val as any)}>
        <TabsList className="grid grid-cols-3 mb-0 bg-darkCharcoal">
          <TabsTrigger 
            value="trading" 
            className="data-[state=active]:bg-mediumCharcoal data-[state=active]:text-poshGold text-softWhite/70 py-3"
          >
            Trading
          </TabsTrigger>
          <TabsTrigger 
            value="savings" 
            className="data-[state=active]:bg-mediumCharcoal data-[state=active]:text-poshGold text-softWhite/70 py-3"
          >
            Savings
          </TabsTrigger>
          <TabsTrigger 
            value="overall" 
            className="data-[state=active]:bg-mediumCharcoal data-[state=active]:text-poshGold text-softWhite/70 py-3"
          >
            Overall
          </TabsTrigger>
        </TabsList>
        
        <AnimatePresence mode="wait">
          <motion.div
            key={category}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <TabsContent value="trading" className="mt-0">
              <LeaderboardContent 
                entries={entries} 
                isLoading={isLoading} 
                formatUserName={formatUserName}
                getAvatarIcon={getAvatarIcon}
                getLeaderColor={getLeaderColor}
                getScoreBarColor={getScoreBarColor}
              />
            </TabsContent>
            
            <TabsContent value="savings" className="mt-0">
              <LeaderboardContent 
                entries={entries} 
                isLoading={isLoading} 
                formatUserName={formatUserName}
                getAvatarIcon={getAvatarIcon}
                getLeaderColor={getLeaderColor}
                getScoreBarColor={getScoreBarColor}
              />
            </TabsContent>
            
            <TabsContent value="overall" className="mt-0">
              <LeaderboardContent 
                entries={entries} 
                isLoading={isLoading} 
                formatUserName={formatUserName}
                getAvatarIcon={getAvatarIcon}
                getLeaderColor={getLeaderColor}
                getScoreBarColor={getScoreBarColor}
              />
            </TabsContent>
          </motion.div>
        </AnimatePresence>
      </Tabs>
    </Card>
  );
}

interface LeaderboardContentProps {
  entries: any[];
  isLoading: boolean;
  formatUserName: (userId: number) => string;
  getAvatarIcon: (userId: number) => string;
  getLeaderColor: (rank: number) => string;
  getScoreBarColor: (score: number, maxScore: number) => string;
}

function LeaderboardContent({
  entries,
  isLoading,
  formatUserName,
  getAvatarIcon,
  getLeaderColor,
  getScoreBarColor
}: LeaderboardContentProps) {
  const maxScore = entries.length > 0 ? Math.max(...entries.map(entry => entry.score)) : 1000;
  
  if (isLoading) {
    return (
      <div className="p-4">
        {Array(5).fill(0).map((_, index) => (
          <div key={index} className="flex items-center mb-4 animate-pulse">
            <div className="w-6 text-center mr-2">
              <div className="h-5 w-5 bg-mediumCharcoal rounded"></div>
            </div>
            <div className="w-10 h-10 rounded-full bg-mediumCharcoal mr-3"></div>
            <div className="flex-1">
              <div className="h-4 w-28 bg-mediumCharcoal rounded mb-2"></div>
              <div className="h-2 w-full bg-mediumCharcoal/30 rounded"></div>
            </div>
            <div className="ml-3 w-12">
              <div className="h-5 w-12 bg-mediumCharcoal rounded"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <div className="p-4">
      {entries.length > 0 ? (
        entries.map((entry, index) => (
          <motion.div 
            key={entry.id}
            className="flex items-center mb-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <div className={`w-6 text-center mr-2 font-medium ${getLeaderColor(entry.rank)}`}>
              {entry.rank}
            </div>
            <Avatar className="h-10 w-10 mr-3 bg-mediumCharcoal">
              <AvatarFallback className="bg-darkCharcoal text-poshGold">
                <i className={getAvatarIcon(entry.userId)}></i>
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="text-sm font-medium mb-1">{formatUserName(entry.userId)}</div>
              <Progress value={(entry.score / maxScore) * 100} className="progress-bar h-2">
                <div 
                  className={`progress-fill ${getScoreBarColor(entry.score, maxScore)}`} 
                  style={{ width: `${(entry.score / maxScore) * 100}%` }}
                ></div>
              </Progress>
            </div>
            <div className="ml-3 text-sm font-medium text-poshGold">
              {entry.score}
            </div>
          </motion.div>
        ))
      ) : (
        <div className="py-6 text-center">
          <div className="text-poshGold text-2xl mb-2">
            <i className="ri-trophy-line"></i>
          </div>
          <p className="text-softWhite/70">No entries for this category yet</p>
        </div>
      )}
    </div>
  );
}
