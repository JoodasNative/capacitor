import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/context/WalletContext";
import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

interface ConnectWalletModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ConnectWalletModal({ open, onOpenChange }: ConnectWalletModalProps) {
  const { connectWallet } = useWallet();
  const [isConnecting, setIsConnecting] = useState(false);
  const [, navigate] = useLocation();

  const walletOptions = [
    { 
      name: "Phantom", 
      icon: "ri-ghost-line", 
      type: "solana", 
      color: "bg-purple-900 hover:bg-purple-800",
      description: "Connect to Solana"
    },
    { 
      name: "MetaMask", 
      icon: "ri-firefox-line", 
      type: "ethereum", 
      color: "bg-orange-700 hover:bg-orange-600",
      description: "Connect to Ethereum"
    },
    { 
      name: "Ledger", 
      icon: "ri-hard-drive-2-line", 
      type: "bitcoin", 
      color: "bg-blue-900 hover:bg-blue-800",
      description: "Hardware wallet"
    }
  ];

  const handleConnect = async (type: string) => {
    try {
      setIsConnecting(true);
      await connectWallet(type);
      onOpenChange(false);
      navigate("/dashboard");
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-darkCharcoal border-mediumCharcoal text-softWhite sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-cinzel text-xl text-center">Connect Your Wallet</DialogTitle>
          <DialogDescription className="text-center text-softWhite/70">
            Choose a wallet to connect and start your degen journey
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          {walletOptions.map((wallet, index) => (
            <motion.div
              key={wallet.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Button
                variant="outline"
                onClick={() => handleConnect(wallet.type)}
                disabled={isConnecting}
                className={`w-full justify-start ${wallet.color} text-softWhite border-mediumCharcoal hover:text-softWhite`}
              >
                <i className={`${wallet.icon} mr-2 text-lg`}></i>
                <div className="flex flex-col items-start">
                  <span>{wallet.name}</span>
                  <span className="text-xs opacity-70">{wallet.description}</span>
                </div>
                {isConnecting && <i className="ri-loader-4-line animate-spin ml-auto"></i>}
              </Button>
            </motion.div>
          ))}
        </div>
        
        <div className="flex flex-col items-center text-center text-xs text-softWhite/50 space-y-2">
          <p>By connecting, you agree to the Joodas 2.0 Terms of Service</p>
          <p>We don't store your private keys - everything is secure and encrypted</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
