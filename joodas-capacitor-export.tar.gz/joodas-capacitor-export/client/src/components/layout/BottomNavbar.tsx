import { useLocation } from "wouter";

interface BottomNavbarProps {
  activePage?: string;
}

export default function BottomNavbar({ activePage }: BottomNavbarProps) {
  const [location] = useLocation();
  
  // Simple function to check active state
  const isActive = (path: string) => {
    if (activePage) {
      return (activePage === 'home' && path === '/') || 
             (activePage === 'analytics' && path === '/analytics') ||
             (activePage === 'trade' && path === '/swap-sol') ||
             (activePage === 'guild' && path === '/guilds') ||
             (activePage === 'settings' && path === '/settings') ||
             (activePage === 'stats' && (path === '/karma' || path === '/insights')) ||
             (activePage === 'wallet' && path === '/wallet');
    }
    return location === path;
  };
  
  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white py-3 px-5 pt-2 pb-6 flex justify-around items-end z-10 shadow-[0_-8px_20px_rgba(0,0,0,0.06)]">
      {/* Home Button */}
      <a href="/" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-home-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/') ? 'text-poshGold' : 'text-gray-500'}`}>Home</span>
      </a>
      
      {/* Stats Button */}
      <a href="/karma" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${(isActive('/karma') || isActive('/insights')) ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-line-chart-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${(isActive('/karma') || isActive('/insights')) ? 'text-poshGold' : 'text-gray-500'}`}>Stats</span>
      </a>
      
      {/* Trade Button - Special Case */}
      <a href="/swap-sol" className="flex flex-col items-center absolute left-1/2 transform -translate-x-1/2 -translate-y-4">
        <div className="w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-r from-poshGold to-amber-400 text-white shadow-lg hover:shadow-xl transition-all duration-300 shimmer-effect">
          <i className="ri-exchange-line text-2xl"></i>
        </div>
        <span className="text-xs mt-1 font-medium text-poshGold">Trade</span>
      </a>
      
      {/* Wallet Button */}
      <a href="/wallet" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/wallet') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-wallet-3-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/wallet') ? 'text-poshGold' : 'text-gray-500'}`}>Wallet</span>
      </a>
      
      {/* Settings Button */}
      <a href="/settings" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/settings') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-settings-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/settings') ? 'text-poshGold' : 'text-gray-500'}`}>Settings</span>
      </a>
    </nav>
  );
}