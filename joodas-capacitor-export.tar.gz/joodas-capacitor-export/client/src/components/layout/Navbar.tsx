import { useLocation, Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface NavbarProps {
  title?: string;
  showBackButton?: boolean;
  showSearch?: boolean;
  compact?: boolean;
}

export function Navbar({ title, showBackButton = false, showSearch = false, compact = false }: NavbarProps) {
  const [location, navigate] = useLocation();
  // Using mock values for now
  const isConnected = true;
  const walletAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e";
  const [showConnectModal, setShowConnectModal] = useState(false);

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      <div className="bg-background px-4 py-2 flex justify-between items-center">
        <div className="text-sm text-gray-800">9:41</div>
        <div className="flex items-center space-x-2 text-gray-700">
          <i className="ri-signal-wifi-fill"></i>
          <i className="ri-battery-fill"></i>
        </div>
      </div>
      
      <div className={`bg-background px-4 ${compact ? 'py-2' : 'py-3'} flex justify-between items-center border-b border-gray-100`}>
        {showBackButton ? (
          <button onClick={() => window.history.back()} className="text-gray-700">
            <i className="ri-arrow-left-s-line text-lg"></i>
          </button>
        ) : (
          <a href="/settings" className="text-gray-700">
            <i className="ri-menu-line text-lg"></i>
          </a>
        )}
        
        {title ? (
          <div className={`${compact ? 'text-base' : 'text-lg'} font-semibold text-gray-800`}>{title}</div>
        ) : (
          <div className="flex items-center space-x-2">
            <div className="text-poshGold font-semibold">Joodas</div>
            <i className="ri-copper-coin-line text-poshGold"></i>
          </div>
        )}
        
        {showSearch ? (
          <button className="text-gray-700">
            <i className="ri-search-line text-lg"></i>
          </button>
        ) : (
          <div className="w-8 h-8 rounded-full bg-white overflow-hidden flex items-center justify-center shadow-sm border border-gray-100">
            {isConnected ? (
              <Avatar className="h-8 w-8 bg-white">
                <AvatarFallback className="bg-transparent text-gray-700">
                  <i className="ri-user-3-line"></i>
                </AvatarFallback>
              </Avatar>
            ) : (
              <button 
                className="h-full w-full flex items-center justify-center text-poshGold"
                onClick={() => setShowConnectModal(true)}
              >
                <i className="ri-wallet-3-line"></i>
              </button>
            )}
          </div>
        )}
      </div>
      
      {/* Wallet modal removed temporarily */}
    </>
  );
}

interface BottomNavbarProps {
  activePage?: string;
}

export function BottomNavbar({ activePage }: BottomNavbarProps) {
  const [location] = useLocation();
  
  // Simple function to check active state
  const isActive = (path: string) => {
    if (activePage) {
      return (activePage === 'home' && path === '/') || 
             (activePage === 'analytics' && path === '/analytics') ||
             (activePage === 'trade' && path === '/swap-sol') ||
             (activePage === 'guild' && path === '/guilds') ||
             (activePage === 'settings' && path === '/settings');
    }
    return location === path;
  };
  
  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white py-3 px-5 pt-2 pb-6 flex justify-around items-end z-10 shadow-[0_-8px_20px_rgba(0,0,0,0.06)]">
      {/* Home Button */}
      <a href="/" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-home-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/') ? 'text-poshGold' : 'text-gray-500'}`}>Home</span>
      </a>
      
      {/* Stats Button */}
      <a href="/karma" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${(isActive('/karma') || isActive('/insights')) ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-line-chart-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${(isActive('/karma') || isActive('/insights')) ? 'text-poshGold' : 'text-gray-500'}`}>Stats</span>
      </a>
      
      {/* Trade Button - Special Case */}
      <a href="/swap-sol" className="flex flex-col items-center absolute left-1/2 transform -translate-x-1/2 -translate-y-4">
        <div className="w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-r from-poshGold to-amber-400 text-white shadow-lg hover:shadow-xl transition-all duration-300 shimmer-effect">
          <i className="ri-exchange-line text-2xl"></i>
        </div>
        <span className="text-xs mt-1 font-medium text-poshGold">Trade</span>
      </a>
      
      {/* Wallet Button */}
      <a href="/wallet" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/wallet') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-wallet-3-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/wallet') ? 'text-poshGold' : 'text-gray-500'}`}>Wallet</span>
      </a>
      
      {/* Settings Button */}
      <a href="/settings" className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isActive('/settings') ? 'bg-poshGold text-white' : 'text-gray-500'} shadow-sm hover:shadow-md transition-all duration-200`}>
          <i className="ri-settings-line text-lg"></i>
        </div>
        <span className={`text-xs mt-1 font-medium ${isActive('/settings') ? 'text-poshGold' : 'text-gray-500'}`}>Settings</span>
      </a>
    </nav>
  );
}
