import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useUserWallet, useRefreshWalletBalance, formatWalletAddress, useCreateWallet } from '@/hooks/use-solana-wallet';
import { formatCurrency } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

export function SolanaWalletCard() {
  const { data: wallets, isLoading, isError, error } = useUserWallet();
  const refreshBalance = useRefreshWalletBalance();
  const createWallet = useCreateWallet();
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();
  
  // If we have wallets, use the first one (since we enforce one wallet per user)
  const wallet = Array.isArray(wallets) && wallets.length > 0 ? wallets[0] : null;
  
  // Check if we have a wallet address in localStorage as a fallback
  const storedWalletAddress = localStorage.getItem('userWalletAddress');
  const hasStoredWallet = !wallet && storedWalletAddress;
  
  const handleCreateWallet = async () => {
    try {
      await createWallet.mutateAsync();
      toast({
        title: "Wallet Created!",
        description: "Your non-custodial Solana wallet has been created successfully."
      });
    } catch (err) {
      console.error("Error creating wallet:", err);
      toast({
        title: "Wallet Creation Failed",
        description: "There was an issue creating your wallet. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleCopyAddress = () => {
    if (wallet?.address) {
      navigator.clipboard.writeText(wallet.address);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
      
      toast({
        title: "Address Copied!",
        description: "Wallet address copied to clipboard.",
      });
    }
  };
  
  const handleRefreshBalance = () => {
    if (wallet?.id) {
      refreshBalance.mutate(wallet.id);
    }
  };
  
  const openExplorer = () => {
    if (wallet?.address) {
      // Use devnet explorer in development, mainnet in production
      const network = process.env.NODE_ENV === 'production' ? 'mainnet-beta' : 'devnet';
      window.open(`https://explorer.solana.com/address/${wallet.address}?cluster=${network}`, '_blank');
    }
  };
  
  return (
    <Card className="shadow-xl hover:shadow-2xl transition-all bg-white relative overflow-hidden rounded-xl border-gray-100">
      {/* Premium shimmer effect */}
      <div className="absolute inset-0 z-0 opacity-20 overflow-hidden pointer-events-none">
        <div className="absolute -inset-[200%] z-0 animate-[shimmer_4s_linear_infinite] bg-gradient-to-r from-transparent via-white to-transparent"></div>
      </div>
      
      {/* Gold corner accents */}
      <div className="absolute top-0 left-0 w-12 h-12 border-t-2 border-l-2 border-poshGold/30 rounded-tl-lg"></div>
      <div className="absolute bottom-0 right-0 w-12 h-12 border-b-2 border-r-2 border-poshGold/30 rounded-br-lg"></div>
      
      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-poshGold/80 via-poshGold to-amber-300/80"></div>
      
      <CardHeader className="pb-3 relative z-10">
        <CardTitle className="text-xl flex items-center">
          <div className="mr-2 text-poshGold">
            <i className="ri-wallet-3-line"></i>
          </div>
          Your Solana Wallet
        </CardTitle>
        <CardDescription>
          {isLoading ? (
            <Skeleton className="h-4 w-32" />
          ) : wallet ? (
            <span className="flex items-center">
              <i className="ri-shield-check-fill text-green-500 mr-1.5 text-xs"></i>
              Non-custodial wallet
            </span>
          ) : (
            <span className="text-amber-600">
              Wallet creation required
            </span>
          )}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="py-3">
        {isLoading ? (
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
              <div className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-full" />
              </div>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-100">
              <div className="space-y-2">
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-8 w-28" />
              </div>
            </div>
            <div className="flex justify-center">
              <Skeleton className="h-9 w-32 rounded-md" />
            </div>
          </div>
        ) : isError && !hasStoredWallet ? (
          <div className="space-y-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-100 text-center">
              <div className="text-2xl text-red-500 mb-2">
                <i className="ri-error-warning-line"></i>
              </div>
              <p className="text-red-700 mb-1 font-medium">Error Loading Wallet</p>
              <p className="text-sm text-red-600">
                {(error as any)?.status === 401
                  ? "Please login to view your wallet"
                  : "There was a problem loading your wallet data"}
              </p>
            </div>
            <div className="flex justify-center">
              <Button onClick={() => window.location.href = "/onboarding"} variant="outline" className="text-sm">
                <i className="ri-login-circle-line mr-2"></i>
                Complete Degen Onboarding
              </Button>
            </div>
          </div>
        ) : wallet ? (
          <div className="space-y-4">
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-100 relative group hover:border-poshGold/30 transition-colors">
              <div className="text-xs text-gray-500 mb-1">Wallet Address</div>
              <div className="font-mono text-sm break-all pr-10">
                {wallet.address}
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-2 top-2 text-gray-500 hover:text-poshGold"
                onClick={handleCopyAddress}
              >
                <i className={`${isCopied ? 'ri-check-line' : 'ri-file-copy-line'}`}></i>
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gradient-to-r from-gray-50 to-white rounded-lg border border-gray-100 hover:border-poshGold/30 transition-colors">
              <div>
                <div className="text-xs text-gray-500 mb-1">Balance</div>
                <div className="text-xl font-semibold text-gray-800">
                  {formatCurrency(wallet.balance || 0)} <span className="text-sm font-normal text-poshGold">SOL</span>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                className="text-xs"
                onClick={handleRefreshBalance}
                disabled={refreshBalance.isPending}
              >
                {refreshBalance.isPending ? (
                  <span className="flex items-center">
                    <i className="ri-loader-4-line animate-spin mr-1"></i> Updating
                  </span>
                ) : (
                  <span className="flex items-center">
                    <i className="ri-refresh-line mr-1"></i> Refresh
                  </span>
                )}
              </Button>
            </div>
          </div>
        ) : hasStoredWallet ? (
          <div className="space-y-4">
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 relative group transition-colors">
              <div className="text-xs text-blue-600 mb-1">Stored Wallet Address (from localStorage)</div>
              <div className="font-mono text-sm break-all pr-10 text-blue-700">
                {storedWalletAddress}
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-2 top-2 text-blue-500 hover:text-blue-700"
                onClick={() => {
                  if (storedWalletAddress) {
                    navigator.clipboard.writeText(storedWalletAddress);
                    setIsCopied(true);
                    setTimeout(() => setIsCopied(false), 2000);
                    
                    toast({
                      title: "Address Copied!",
                      description: "Wallet address copied to clipboard.",
                    });
                  }
                }}
              >
                <i className={`${isCopied ? 'ri-check-line' : 'ri-file-copy-line'}`}></i>
              </Button>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 text-center">
              <p className="text-blue-700 mb-2 font-medium">API Connection Issue</p>
              <p className="text-sm text-blue-600 mb-3">
                We found your wallet in localStorage, but couldn't connect to the API to retrieve its current balance.
              </p>
              <Button 
                variant="outline" 
                className="text-sm mx-auto bg-white"
                onClick={() => window.location.reload()}
              >
                <i className="ri-refresh-line mr-1"></i> Refresh Page
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="text-center text-gray-700">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-3">
                <i className="ri-wallet-3-line text-3xl text-poshGold"></i>
              </div>
              <h3 className="text-lg font-semibold mb-1">No Wallet Found</h3>
              
              {localStorage.getItem('isGuestMode') === 'true' ? (
                <>
                  <p className="text-sm text-gray-500 mb-4">
                    Sign in to create your non-custodial Solana wallet and start trading.
                  </p>
                  <Button 
                    onClick={() => window.location.href = '/onboarding'}
                    className="bg-gradient-to-r from-poshGold to-amber-500 hover:from-poshGold/90 hover:to-amber-500/90 text-white border-none mb-2"
                  >
                    <span className="flex items-center">
                      <i className="ri-login-circle-line mr-2"></i> Complete Degen Onboarding
                    </span>
                  </Button>
                  <div className="text-xs text-gray-400 mt-2">
                    Guest mode has limited functionality
                  </div>
                </>
              ) : (
                <>
                  <p className="text-sm text-gray-500 mb-4">You don't have a wallet yet. Creating one only takes seconds!</p>
                  <Button 
                    onClick={handleCreateWallet} 
                    className="bg-gradient-to-r from-poshGold to-amber-500 hover:from-poshGold/90 hover:to-amber-500/90 text-white border-none"
                    disabled={createWallet.isPending}
                  >
                    {createWallet.isPending ? (
                      <span className="flex items-center">
                        <i className="ri-loader-4-line animate-spin mr-2"></i> Creating Wallet...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <i className="ri-wallet-add-line mr-2"></i> Create My Wallet
                      </span>
                    )}
                  </Button>
                </>
              )}
            </div>
          </div>
        )}
      </CardContent>
      
      {wallet && (
        <CardFooter className="pt-2 relative z-10">
          <div className="space-y-2 w-full">
            <Button 
              variant="ghost" 
              className="text-xs w-full flex items-center justify-center text-gray-600 hover:text-poshGold"
              onClick={openExplorer}
            >
              <i className="ri-external-link-line mr-1"></i>
              View on Solana Explorer
            </Button>
            
            {/* Success message after wallet creation */}
            {localStorage.getItem('walletJustCreated') === 'true' && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-100 text-sm text-green-700 flex items-center justify-center">
                <i className="ri-checkbox-circle-line mr-2 text-green-600"></i>
                Wallet successfully generated on first login!
              </div>
            )}
          </div>
        </CardFooter>
      )}
    </Card>
  );
}