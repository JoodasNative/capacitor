import { useEffect, ReactNode, useState } from 'react';
import { useGenerateWalletOnFirstLogin } from '@/hooks/use-solana-wallet';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface WalletProviderProps {
  children: ReactNode;
}

/**
 * WalletInitializer: Ensures a wallet is automatically created for new users
 * upon first login, implementing the "Seamless Degen Onboarding" experience
 */
export function WalletInitializer({ children }: WalletProviderProps) {
  const { user, isLoading: isAuthLoading, isAuthenticated } = useAuth();
  const { generateWalletIfNeeded, isCreatingWallet, wallets, isLoadingWallets } = useGenerateWalletOnFirstLogin();
  const { toast } = useToast();
  
  // Check localStorage for an existing flag to avoid repeated attempts
  const [hasCheckedWallet, setHasCheckedWallet] = useState(() => {
    return localStorage.getItem('wallet_generation_attempted') === 'true';
  });
  
  // Automatically create wallet ONLY for fully authenticated users - WITH PROPER CHECKS
  useEffect(() => {
    const attemptWalletCreation = async () => {
      // Skip if already checked or still loading auth/wallet data
      if (hasCheckedWallet || isAuthLoading || isLoadingWallets) {
        return;
      }
      
      // Only proceed for fully authenticated users with valid ID
      if (isAuthenticated && user && user.id) {
        console.log('Authenticated user detected - checking for wallet ONE TIME:', user.id);
        
        try {
          // First, mark as checked to prevent repeated attempts
          setHasCheckedWallet(true);
          localStorage.setItem('wallet_generation_attempted', 'true');
          
          // Then attempt to create/check wallet
          await generateWalletIfNeeded(user);
          console.log('Wallet check/creation complete for authenticated user');
        } catch (error) {
          console.error('Error during wallet creation for authenticated user:', error);
          
          // Show error toast only for authenticated users
          toast({
            title: "Wallet Creation Issue",
            description: "We couldn't create your wallet automatically. You can try manually from the wallet page.",
            variant: "destructive",
          });
        }
      }
    };
    
    // Only attempt wallet creation if proper conditions are met
    // Most importantly, isAuthLoading must be false so we only try after auth state is stable
    if (!isAuthLoading && !hasCheckedWallet) {
      attemptWalletCreation();
    }
    
    // Important: Do NOT include hasCheckedWallet in deps or it will cause infinite loops
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, isAuthenticated, isAuthLoading, isLoadingWallets, generateWalletIfNeeded, toast]);
  
  // Store wallet address in localStorage whenever wallets are loaded
  useEffect(() => {
    if (!isLoadingWallets && Array.isArray(wallets) && wallets.length > 0) {
      console.log('User wallet found:', wallets[0]);
      
      // Store wallet info in localStorage for quick access and better UX
      localStorage.setItem('userWalletAddress', wallets[0].address);
      localStorage.setItem('userWalletId', wallets[0].id.toString());
      
      // If this appears to be a new wallet, show a welcome toast
      if (!localStorage.getItem('walletWelcomeShown')) {
        toast({
          title: "Wallet Created",
          description: "Your Solana wallet has been created! You can view it in the Wallet tab.",
        });
        localStorage.setItem('walletWelcomeShown', 'true');
      }
    }
  }, [wallets, isLoadingWallets, toast]);
  
  return <>{children}</>;
}