import { useGenerateWalletOnAuth } from "@/hooks/use-generate-wallet-on-auth";
import { useFirebaseAuth } from "@/context/FirebaseAuthContext";
import { useWalletInit } from "@/context/WalletInitContext";
import { useEffect, useState } from "react";

/**
 * This component doesn't render anything visible
 * It only serves to trigger the wallet generation hook
 * when a user is authenticated
 */
export function WalletGenerator() {
  const { currentUser } = useFirebaseAuth();
  const { hasInitializedWallet, markWalletInitialized, resetWalletInitState } = useWalletInit();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showDebug, setShowDebug] = useState(false);
  
  // Additional security check to ensure we have a fully authenticated user
  useEffect(() => {
    if (currentUser && currentUser.uid && currentUser.email) {
      setIsAuthenticated(true);
      console.log("WalletGenerator: User is authenticated, can now trigger wallet creation");
    } else {
      setIsAuthenticated(false);
    }
  }, [currentUser]);
  
  // Enable debug mode when pressing ctrl+shift+w
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key === 'W') {
        setShowDebug(prev => !prev);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);
  
  // Custom wrapper to prevent hooks from being conditionally used
  // This ensures React hooks rules are respected
  const WalletInitializer = () => {
    useGenerateWalletOnAuth();
    
    // Mark wallet as initialized after hook runs
    useEffect(() => {
      console.log("WalletInitializer: Marking wallet as initialized in global context");
      markWalletInitialized();
    }, []);
    
    return null;
  };
  
  // Debug UI for easier development
  if (showDebug) {
    return (
      <div 
        style={{ 
          position: 'fixed', 
          bottom: '10px', 
          left: '10px', 
          zIndex: 9999, 
          backgroundColor: 'rgba(0,0,0,0.8)', 
          padding: '10px', 
          borderRadius: '4px',
          color: 'white',
          fontSize: '12px'
        }}
      >
        <div><strong>Wallet Initialization Debug:</strong></div>
        <div>Authenticated: {isAuthenticated ? '✅' : '❌'}</div>
        <div>Wallet Initialized: {hasInitializedWallet ? '✅' : '❌'}</div>
        <div>User ID: {currentUser?.uid || 'None'}</div>
        <div style={{ marginTop: '5px' }}>
          <button 
            onClick={() => {
              resetWalletInitState();
              localStorage.removeItem('wallet_initialization_complete');
              localStorage.removeItem('wallet_generation_attempted');
              localStorage.removeItem('walletWelcomeShown');
              console.log('Wallet initialization state reset!');
            }}
            style={{
              backgroundColor: '#dcb454',
              color: 'black',
              border: 'none',
              padding: '4px 8px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '11px'
            }}
          >
            Reset Wallet State
          </button>
          <button 
            onClick={() => setShowDebug(false)}
            style={{
              backgroundColor: '#333',
              color: 'white',
              border: 'none',
              padding: '4px 8px',
              borderRadius: '4px',
              cursor: 'pointer',
              marginLeft: '5px',
              fontSize: '11px'
            }}
          >
            Close
          </button>
        </div>
      </div>
    );
  }
  
  // Only render the wallet initializer if user is fully authenticated AND wallet hasn't been initialized yet
  if (isAuthenticated && !hasInitializedWallet) {
    console.log("WalletGenerator: First-time wallet initialization for authenticated user");
    return <WalletInitializer />;
  }
  
  // If we've already initialized the wallet, log it
  if (hasInitializedWallet) {
    console.log("WalletGenerator: Wallet has already been initialized, skipping");
  }
  
  // Return null since this is a utility component
  return null;
}