import { ReactNode, useEffect, useState } from "react";
import { useWalletInit } from "@/context/WalletInitContext";

interface WalletInitializationBlockerProps {
  children: ReactNode;
}

/**
 * This component acts as a safety mechanism to prevent infinite wallet initialization loops.
 * It ensures that wallet initialization processes (which might involve API calls, keypair generation,
 * and other resource-intensive operations) don't run in an uncontrolled manner.
 */
export default function WalletInitializationBlocker({ children }: WalletInitializationBlockerProps) {
  const { 
    isInitialized, 
    isInitializing, 
    hasWalletError, 
    errorMessage,
    setWalletError 
  } = useWalletInit();
  
  const [initAttempts, setInitAttempts] = useState(0);
  const [showBlocker, setShowBlocker] = useState(false);
  
  // Track initialization attempts and show blocker if too many attempts happen
  useEffect(() => {
    if (isInitializing) {
      setInitAttempts(prev => prev + 1);
      
      // If we've had too many initialization attempts, show a blocker
      if (initAttempts > 5) {
        console.error("Too many wallet initialization attempts detected!");
        setShowBlocker(true);
        setWalletError("Too many wallet initialization attempts. Please reload the page.");
      }
      
      // Reset attempt counter after a delay
      const timer = setTimeout(() => {
        setInitAttempts(0);
      }, 30000); // Reset after 30 seconds
      
      return () => clearTimeout(timer);
    }
  }, [isInitializing, initAttempts, setWalletError]);
  
  // If we're showing the emergency blocker, prevent rendering children
  if (showBlocker) {
    return (
      <div className="fixed inset-0 bg-white bg-opacity-95 z-50 flex flex-col items-center justify-center p-4">
        <div className="max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">
            Emergency Wallet Initialization Blocker
          </h2>
          <p className="mb-4 text-gray-800">
            We've detected an unusual number of wallet initialization attempts.
            This could indicate a problem with your wallet configuration.
          </p>
          <p className="mb-6 text-gray-800">
            Please reload the page to try again or contact support if this issue persists.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-black text-white rounded-md hover:bg-opacity-90 transition-colors"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  // If wallet has an error but not in emergency mode, show the error
  if (hasWalletError && errorMessage) {
    return (
      <div className="fixed inset-0 bg-white bg-opacity-95 z-50 flex flex-col items-center justify-center p-4">
        <div className="max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">
            Wallet Initialization Error
          </h2>
          <p className="mb-4 text-gray-800">
            {errorMessage}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-black text-white rounded-md hover:bg-opacity-90 transition-colors"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  // If everything is fine, render children
  return <>{children}</>;
}