import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useDegenScore, useNextBadge } from "@/hooks/use-degen-score";
import { motion } from "framer-motion";
import { BadgeAnimated } from "@/components/ui/badge-animated";

interface DegenScoreCardProps {
  userId?: number;
}

export function DegenScoreCard({ userId = 1 }: DegenScoreCardProps) {
  const { userData, isLoading, levelProgress } = useDegenScore(userId);
  const { nextBadge } = useNextBadge(userId);

  if (isLoading) {
    return (
      <Card className="card p-4 animate-pulse">
        <div className="flex justify-between items-center mb-3">
          <div>
            <div className="h-7 w-16 bg-mediumCharcoal rounded mb-2"></div>
            <div className="h-4 w-32 bg-mediumCharcoal/60 rounded"></div>
          </div>
          <div className="w-12 h-12 rounded-full bg-mediumCharcoal"></div>
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between text-xs mb-1">
            <span className="h-3 w-32 bg-mediumCharcoal/60 rounded"></span>
            <span className="h-3 w-6 bg-mediumCharcoal/60 rounded"></span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill gold-gradient" style={{ width: '30%' }}></div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3 text-center">
          {[0, 1, 2].map(index => (
            <div key={index}>
              <div className="h-5 w-10 mx-auto bg-mediumCharcoal rounded mb-1"></div>
              <div className="h-3 w-16 mx-auto bg-mediumCharcoal/60 rounded"></div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card className="card p-4">
      <div className="flex justify-between items-center mb-3">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="font-medium text-lg">{userData?.degenScore || 0}</div>
          <div className="text-xs text-softWhite/70">
            {userData?.badges?.[0] || "Novice Trader"} Status
          </div>
        </motion.div>
        <motion.div 
          className="w-12 h-12 rounded-full bg-mediumCharcoal flex items-center justify-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <i className="ri-award-fill text-poshGold text-xl"></i>
        </motion.div>
      </div>
      
      <div className="mb-4">
        <div className="flex justify-between text-xs mb-1">
          <span>Progress to {nextBadge.name}</span>
          <span>{Math.round(nextBadge.progress)}%</span>
        </div>
        <Progress value={nextBadge.progress} className="progress-bar">
          <div 
            className="progress-fill gold-gradient" 
            style={{ width: `${nextBadge.progress}%` }}
          ></div>
        </Progress>
      </div>
      
      <div className="grid grid-cols-3 gap-3 text-center">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="text-sm font-medium">12</div>
          <div className="text-xs text-softWhite/50">Winning Trades</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="text-sm font-medium">{userData?.badges?.length || 0}</div>
          <div className="text-xs text-softWhite/50">Badges Earned</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <div className="text-sm font-medium">3</div>
          <div className="text-xs text-softWhite/50">Days Streak</div>
        </motion.div>
      </div>
      
      {/* Badges Display */}
      {userData?.badges && userData.badges.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {userData.badges.map((badge, index) => (
            <BadgeAnimated key={index} label={badge} delay={0.5 + (index * 0.1)} />
          ))}
        </div>
      )}
    </Card>
  );
}
