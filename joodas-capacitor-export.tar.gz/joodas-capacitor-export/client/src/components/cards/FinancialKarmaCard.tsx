import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface FinancialKarmaCardProps {
  userId?: number;
}

export function FinancialKarmaCard({ userId = 1 }: FinancialKarmaCardProps) {
  // In a real app, this would come from a hook that fetches user data
  const [karmaData] = useState({
    hodlStreak: 14,
    longestStreak: 28,
    emotionalHealth: 78,
    profitLossRatio: 68,
    holdingPatience: 82,
    panicResistance: 65,
    tradingMood: "Bullish",
    status: "Diamond Hands",
    statusIcon: "ri-vip-diamond-fill",
    achievements: [
      { name: "HODL Legend", progress: 65 },
      { name: "Dip Buyer", progress: 89 },
      { name: "FUD Resistant", progress: 42 }
    ],
    nextAchievement: {
      name: "Patience Master",
      daysLeft: 7,
      reward: "+5 Emotional Health"
    }
  });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 10, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { type: "spring", stiffness: 300, damping: 24 }
    }
  };
  
  // Get appropriate colors for the emotional health
  const getHealthColor = (value: number) => {
    if (value >= 80) return "text-emerald-500";
    if (value >= 60) return "text-poshGold";
    if (value >= 40) return "text-amber-500";
    return "text-red-500";
  };
  
  const getHealthBg = (value: number) => {
    if (value >= 80) return "bg-emerald-500/10";
    if (value >= 60) return "bg-poshGold/10";
    if (value >= 40) return "bg-amber-500/10";
    return "bg-red-500/10";
  };

  // Get label based on emotional health score
  const getEmotionalLabel = (value: number) => {
    if (value >= 80) return "Diamond Hands";
    if (value >= 60) return "Steady Hodler";
    if (value >= 40) return "Paper Hander";
    return "Rug Magnet";
  };
  
  return (
    <Card className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
      <div className="p-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="relative"
        >
          <motion.div variants={itemVariants} className="flex justify-between items-center mb-4">
            <div>
              <div className="text-sm text-gray-500 mb-1">Personal Financial Karma</div>
              <div className="text-xl font-semibold flex items-center">
                {karmaData.status}
                <i className={`${karmaData.statusIcon} text-poshGold ml-2 pulse-effect`}></i>
              </div>
            </div>
            <div className={`w-20 h-20 ${getHealthBg(karmaData.emotionalHealth)} rounded-full flex items-center justify-center text-2xl font-bold shadow-lg shimmer-effect relative`}>
              <span className={getHealthColor(karmaData.emotionalHealth)}>{karmaData.emotionalHealth}</span>
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 bg-white px-2 py-0.5 rounded-full text-[10px] font-medium border border-gray-200 whitespace-nowrap shadow-sm">
                Emotional Health
              </div>
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants} className="mb-6">
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">HODL Streak</div>
              <div className="text-xs text-poshGold font-medium">
                {karmaData.hodlStreak} Days
              </div>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-poshGold to-amber-400"
                style={{ width: `${(karmaData.hodlStreak / karmaData.longestStreak) * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between items-center text-xs text-gray-500 mt-1">
              <div>Best: {karmaData.longestStreak} days</div>
              <div className="flex items-center">
                <i className="ri-fire-line text-amber-500 mr-1"></i>
                <span>+{Math.floor(karmaData.hodlStreak / 3)} karma pts/day</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-xl p-3 border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-xs text-gray-500">Profit/Loss Ratio</div>
                  <div className={`text-xs ${getHealthColor(karmaData.profitLossRatio)}`}>
                    {karmaData.profitLossRatio}%
                  </div>
                </div>
                <Progress value={karmaData.profitLossRatio} className="h-1.5" />
              </div>
              <div className="bg-white rounded-xl p-3 border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-xs text-gray-500">Holding Patience</div>
                  <div className={`text-xs ${getHealthColor(karmaData.holdingPatience)}`}>
                    {karmaData.holdingPatience}%
                  </div>
                </div>
                <Progress value={karmaData.holdingPatience} className="h-1.5" />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-xl p-3 border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-xs text-gray-500">Panic Resistance</div>
                  <div className={`text-xs ${getHealthColor(karmaData.panicResistance)}`}>
                    {karmaData.panicResistance}%
                  </div>
                </div>
                <Progress value={karmaData.panicResistance} className="h-1.5" />
              </div>
              <div className="bg-white rounded-xl p-3 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-gray-500">Trading Mood</div>
                  <Badge className="bg-emerald-500/10 text-emerald-600 text-xs hover:bg-emerald-500/20">
                    {karmaData.tradingMood}
                  </Badge>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Achievements Section */}
          <motion.div variants={itemVariants} className="mt-5 pt-4 border-t border-gray-100">
            <div className="flex justify-between items-center mb-3">
              <div className="text-sm font-medium text-gray-700">Achievements</div>
              <div className="text-xs text-poshGold">3/8 Unlocked</div>
            </div>
            
            <div className="space-y-3">
              {karmaData.achievements.map((achievement, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-poshGold/10 flex items-center justify-center text-poshGold">
                    <i className={index === 0 ? "ri-trophy-line" : index === 1 ? "ri-hand-coin-line" : "ri-shield-star-line"}></i>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <div className="text-xs font-medium text-gray-700">{achievement.name}</div>
                      <div className="text-[10px] text-gray-500">{achievement.progress}%</div>
                    </div>
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-poshGold"
                        style={{ width: `${achievement.progress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants} className="mt-5 bg-amber-50 border border-amber-200 rounded-xl p-3 relative">
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-amber-400 rounded-full flex items-center justify-center">
              <i className="ri-lightbulb-flash-line text-white text-xs"></i>
            </div>
            <div className="text-xs font-medium text-amber-800 mb-1">Next Achievement</div>
            <div className="text-xs text-amber-700 mb-2">
              Continue your HODL streak for {karmaData.nextAchievement.daysLeft} more days to unlock the
              <span className="font-semibold"> {karmaData.nextAchievement.name}</span> achievement!
            </div>
            <div className="flex items-center">
              <div className="flex-1 h-1.5 bg-amber-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500"
                  style={{ width: `${100 - (karmaData.nextAchievement.daysLeft / 0.3)}%` }}
                ></div>
              </div>
              <div className="ml-2 text-amber-700 text-[10px] font-medium">
                Reward: {karmaData.nextAchievement.reward}
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </Card>
  );
}