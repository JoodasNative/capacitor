import { Card } from "@/components/ui/card";
import { formatCurrency, maskCardNumber } from "@/lib/utils";
import { motion } from "framer-motion";
import { useUserWallets } from "@/hooks/use-wallet";

interface WalletCardProps {
  userId?: number;
}

export function WalletCard({ userId = 1 }: WalletCardProps) {
  const { wallets, isLoading } = useUserWallets(userId);

  if (isLoading) {
    return (
      <Card className="card p-4 mb-3 animate-pulse">
        <div className="flex items-center justify-between mb-3">
          <div className="h-6 w-20 bg-mediumCharcoal rounded"></div>
          <div className="h-8 w-28 bg-mediumCharcoal rounded-full"></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-mediumCharcoal rounded-xl p-3 h-24"></div>
          <div className="bg-mediumCharcoal rounded-xl p-3 h-24"></div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="card p-4 mb-3">
      <div className="flex items-center justify-between mb-3">
        <div className="font-medium">My Card</div>
        <button className="bg-poshGold/10 text-poshGold text-sm rounded-full px-3 py-1 flex items-center">
          <i className="ri-add-line mr-1"></i> Add Card
        </button>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        {wallets.map((wallet, index) => (
          <motion.div 
            key={wallet.id}
            className="bg-mediumCharcoal rounded-xl p-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <div className="text-xs text-softWhite/70 mb-1">
              {wallet.type === 'Ethereum' ? 'Ethereum' : wallet.type === 'Solana' ? 'Solana' : 'Bitcoin'}
            </div>
            <div className="text-xs bg-darkCharcoal px-2 py-0.5 rounded-full w-fit mb-3">
              {wallet.type}
            </div>
            <div className="font-semibold mb-1">{formatCurrency(wallet.balance)}</div>
            <div className="flex justify-between items-center">
              <div className="text-xs text-softWhite/50">
                {maskCardNumber(wallet.address.substring(0, 16))}
              </div>
              <i className="ri-wifi-line text-softWhite/30 rotate-90"></i>
            </div>
          </motion.div>
        ))}

        {wallets.length === 0 && (
          <div className="col-span-2 bg-mediumCharcoal rounded-xl p-4 text-center">
            <div className="text-poshGold text-2xl mb-2">
              <i className="ri-wallet-3-line"></i>
            </div>
            <h3 className="font-medium mb-1">No Wallets Connected</h3>
            <p className="text-xs text-softWhite/70 mb-3">
              Connect your crypto wallets to start tracking your portfolio
            </p>
            <button className="bg-poshGold/10 text-poshGold text-sm rounded-full px-4 py-2">
              Connect Wallet
            </button>
          </div>
        )}
      </div>
    </Card>
  );
}

interface BalanceCardProps {
  totalBalance: number;
  percentageChange: number;
}

export function BalanceCard({ 
  totalBalance = 56498.50, 
  percentageChange = 4.6 
}: BalanceCardProps) {
  return (
    <div className="px-4 py-6">
      <div className="text-sm text-softWhite/70 mb-1">Total Balance</div>
      <div className="flex items-end space-x-2">
        <motion.div 
          className="text-3xl font-semibold flex items-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <span className="text-xl text-softWhite/70">$</span>
          {totalBalance.toLocaleString('en-US', { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
          }).split('.').map((part, index) => (
            index === 0 
              ? part 
              : <span key={index} className="text-softWhite/50">.{part}</span>
          ))}
        </motion.div>
        <div className={`text-sm ${percentageChange >= 0 ? 'text-success bg-success/10' : 'text-warning bg-warning/10'} py-1 px-2 rounded-full flex items-center`}>
          {percentageChange >= 0 ? '+' : ''}{percentageChange}% 
          <i className={`${percentageChange >= 0 ? 'ri-arrow-up-line' : 'ri-arrow-down-line'} ml-1`}></i>
        </div>
      </div>
    </div>
  );
}
