import { Card } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";
import { cn } from "@/lib/utils";

interface TimeRange {
  id: string;
  label: string;
  active: boolean;
}

interface ChartCardProps {
  title: string;
  dateRange: string;
  data?: any[];
  type?: 'line' | 'bar';
}

export function ChartCard({
  title = "Statistics Summary",
  dateRange = "Jan 1, 2023 - Jan 30, 2023",
  data,
  type = 'line'
}: ChartCardProps) {
  const [timeRanges, setTimeRanges] = useState<TimeRange[]>([
    { id: '1D', label: '1D', active: false },
    { id: '1W', label: '1W', active: false },
    { id: '1M', label: '1M', active: true },
    { id: '3M', label: '3M', active: false },
    { id: 'All', label: 'All', active: false }
  ]);

  // Sample data if none provided
  const chartData = data || [
    { name: 'S', spending: 40, income: 65 },
    { name: 'M', spending: 60, income: 40 },
    { name: 'T', spending: 70, income: 80 },
    { name: 'W', spending: 50, income: 35 },
    { name: 'T', spending: 80, income: 55 },
    { name: 'F', spending: 30, income: 45 },
    { name: 'S', spending: 60, income: 70 }
  ];

  const handleTimeRangeClick = (id: string) => {
    setTimeRanges(timeRanges.map(range => ({
      ...range,
      active: range.id === id
    })));
  };

  return (
    <Card className="card p-4 mb-3">
      <div className="flex justify-between items-center mb-2">
        <h2 className="font-cinzel text-lg font-medium">{title}</h2>
        <div className="flex items-center text-xs bg-darkCharcoal px-2 py-1 rounded">
          <i className="ri-calendar-line mr-1 text-poshGold"></i>
          <span>Aug 2023</span>
          <i className="ri-arrow-down-s-line ml-1"></i>
        </div>
      </div>
      
      <div className="text-xs text-softWhite/70 mb-4">{dateRange}</div>
      
      {/* Time Range Tabs */}
      <div className="flex space-x-2 mb-6">
        {timeRanges.map((range) => (
          <button
            key={range.id}
            className={cn(
              "px-3 py-1 rounded-full text-xs",
              range.active 
                ? "bg-darkCharcoal text-poshGold" 
                : "text-softWhite/70"
            )}
            onClick={() => handleTimeRangeClick(range.id)}
          >
            {range.label}
          </button>
        ))}
      </div>
      
      {/* Chart */}
      <div className="h-40 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={type} 
            className="h-full w-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <ResponsiveContainer width="100%" height="100%">
              {type === 'line' ? (
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(42, 63%, 60%)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="hsl(42, 63%, 60%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'hsl(0, 0%, 70%)', fontSize: 10 }}
                  />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(90, 14%, 10%)', 
                      borderColor: 'hsl(90, 14%, 20%)',
                      color: 'hsl(0, 0%, 96%)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="income" 
                    stroke="hsl(42, 63%, 60%)" 
                    strokeWidth={2}
                    fill="url(#goldGradient)" 
                  />
                </AreaChart>
              ) : (
                <BarChart data={chartData}>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'hsl(0, 0%, 70%)', fontSize: 10 }}
                  />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(90, 14%, 10%)', 
                      borderColor: 'hsl(90, 14%, 20%)',
                      color: 'hsl(0, 0%, 96%)'
                    }}
                  />
                  <Bar dataKey="spending" radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.name === 'T' ? 'hsl(42, 63%, 60%)' : 'hsl(210, 86%, 64%)'} 
                        opacity={0.7}
                      />
                    ))}
                  </Bar>
                </BarChart>
              )}
            </ResponsiveContainer>
          </motion.div>
        </AnimatePresence>
        
        {/* Chart Legend */}
        <div className="absolute top-5 right-2 bg-darkCharcoal/80 backdrop-blur-sm px-3 py-2 rounded-lg">
          <div className="flex items-center mb-1">
            <div className="w-2 h-2 rounded-full bg-blue-400 mr-2"></div>
            <div className="text-xs">Spending</div>
          </div>
          <div className="flex items-center">
            <div className="w-2 h-2 rounded-full bg-poshGold mr-2"></div>
            <div className="text-xs">Income</div>
          </div>
        </div>
      </div>
      
      {/* Chart X-axis labels */}
      <div className="flex justify-between text-xs text-softWhite/50 mt-2">
        {chartData.map((item, index) => (
          <div key={index} className={item.name === 'T' ? 'bg-darkCharcoal text-poshGold w-6 h-6 rounded-full flex items-center justify-center' : ''}>
            {item.name}
          </div>
        ))}
      </div>
    </Card>
  );
}

interface SpendingCardProps {
  total: number;
  percentChange: number;
  categories: Array<{
    name: string;
    amount: number;
    color: string;
  }>;
}

export function SpendingOverviewCard({
  total = 20389.0,
  percentChange = 3.7,
  categories = [
    { name: 'Investment', amount: 18493.70, color: 'bg-blue-400' },
    { name: 'Entertainment', amount: 7303.90, color: 'bg-purple-400' },
    { name: 'Food & beverages', amount: 4209.40, color: 'bg-poshGold' }
  ]
}: SpendingCardProps) {
  // Calculate total for percentages
  const categoryTotal = categories.reduce((sum, category) => sum + category.amount, 0);
  
  return (
    <div className="px-4 py-4">
      <div className="flex justify-between items-center mb-2">
        <div className="text-sm text-softWhite/70">Spent overview</div>
        <div className="text-xs bg-poshGold/20 text-poshGold px-2 py-1 rounded-full flex items-center">
          June <i className="ri-arrow-down-s-line ml-1"></i>
        </div>
      </div>
      
      <div className="font-semibold text-2xl mb-4">
        ${total.toLocaleString()} 
        <span className={`text-sm ${percentChange >= 0 ? 'text-success' : 'text-warning'}`}>
          {percentChange >= 0 ? '+' : ''}{percentChange}%
        </span>
      </div>
      
      {/* Categories Bar Chart */}
      <div className="mb-6">
        <div className="flex h-4 rounded-full overflow-hidden mb-3">
          {categories.map((category, index) => (
            <motion.div
              key={index}
              className={`${category.color}`}
              style={{ width: `${(category.amount / categoryTotal) * 100}%` }}
              initial={{ width: 0 }}
              animate={{ width: `${(category.amount / categoryTotal) * 100}%` }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            />
          ))}
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          {categories.map((category, index) => (
            <motion.div 
              key={index}
              className="flex items-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + (index * 0.1) }}
            >
              <div className={`w-2 h-2 rounded-full ${category.color} mr-2`}></div>
              <div className="text-xs truncate">{category.name}</div>
              <div className="ml-auto text-xs font-medium">${category.amount.toLocaleString()}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
