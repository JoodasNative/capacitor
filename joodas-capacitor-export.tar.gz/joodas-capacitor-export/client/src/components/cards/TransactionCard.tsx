import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTransactionsByPeriod } from "@/hooks/use-transactions";
import { motion } from "framer-motion";
import { useState } from "react";

interface TransactionCardProps {
  userId?: number;
}

export function TransactionCard({ userId = 1 }: TransactionCardProps) {
  const [period, setPeriod] = useState<'today' | 'week' | 'month'>('today');
  const { transactions, isLoading } = useTransactionsByPeriod(userId, period);

  const formatDate = (date: Date) => {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const month = months[date.getMonth()];
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    
    return `${day} ${month} • ${displayHours}:${minutes} ${ampm}`;
  };

  // Icons for different transaction types
  const getTransactionIcon = (note: string | undefined, type: string) => {
    if (note?.includes('Netflix')) return 'ri-netflix-fill text-warning';
    if (note?.includes('House')) return 'ri-home-4-line text-poshGold';
    if (note?.includes('Grocery')) return 'ri-shopping-bag-line text-info';
    if (note?.includes('SOL')) return 'ri-coin-line text-poshGold';
    if (note?.includes('NFT')) return 'ri-gamepad-line text-poshGold';
    
    return type === 'receive' 
      ? 'ri-arrow-down-circle-line text-success' 
      : 'ri-arrow-up-circle-line text-warning';
  };

  return (
    <div className="px-4 mb-6">
      <h2 className="font-cinzel text-lg font-medium mb-3">Recent Transactions</h2>
      
      <Tabs defaultValue="today" className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger 
            value="today" 
            className="data-[state=active]:bg-darkCharcoal data-[state=active]:text-softWhite text-softWhite/70 px-4 py-2 rounded-full text-sm"
            onClick={() => setPeriod('today')}
          >
            Today
          </TabsTrigger>
          <TabsTrigger 
            value="week" 
            className="data-[state=active]:bg-darkCharcoal data-[state=active]:text-softWhite text-softWhite/70 px-4 py-2 rounded-full text-sm"
            onClick={() => setPeriod('week')}
          >
            This Week
          </TabsTrigger>
          <TabsTrigger 
            value="month" 
            className="data-[state=active]:bg-darkCharcoal data-[state=active]:text-softWhite text-softWhite/70 px-4 py-2 rounded-full text-sm"
            onClick={() => setPeriod('month')}
          >
            This Month
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="today" className="mt-0">
          <Card className="card divide-y divide-softWhite/10">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <div key={index} className="p-3 flex items-center justify-between animate-pulse">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-mediumCharcoal mr-3"></div>
                    <div>
                      <div className="h-4 w-24 bg-mediumCharcoal rounded mb-2"></div>
                      <div className="h-3 w-32 bg-mediumCharcoal/60 rounded"></div>
                    </div>
                  </div>
                  <div className="h-4 w-16 bg-mediumCharcoal rounded"></div>
                </div>
              ))
            ) : transactions.length > 0 ? (
              transactions.map((tx, index) => (
                <motion.div 
                  key={tx.id}
                  className="p-3 flex items-center justify-between"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-mediumCharcoal flex items-center justify-center mr-3">
                      <i className={getTransactionIcon(tx.note, tx.type)}></i>
                    </div>
                    <div>
                      <div className="font-medium">{tx.note || `${tx.type} ${tx.token}`}</div>
                      <div className="text-xs text-softWhite/50">{formatDate(new Date(tx.date))}</div>
                    </div>
                  </div>
                  <div className={tx.amount > 0 ? 'text-success' : 'text-warning'}>
                    {tx.amount > 0 ? '+' : ''}{tx.amount}
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="p-6 text-center">
                <div className="text-poshGold text-xl mb-2">
                  <i className="ri-exchange-dollar-line"></i>
                </div>
                <p className="text-softWhite/70">No transactions for this period</p>
              </div>
            )}
          </Card>
        </TabsContent>
        
        <TabsContent value="week" className="mt-0">
          {/* Content is dynamically loaded by the same transactions list based on the period state */}
          <Card className="card">
            {!isLoading && transactions.length === 0 && (
              <div className="p-6 text-center">
                <div className="text-poshGold text-xl mb-2">
                  <i className="ri-exchange-dollar-line"></i>
                </div>
                <p className="text-softWhite/70">No transactions this week</p>
              </div>
            )}
          </Card>
        </TabsContent>
        
        <TabsContent value="month" className="mt-0">
          {/* Content is dynamically loaded by the same transactions list based on the period state */}
          <Card className="card">
            {!isLoading && transactions.length === 0 && (
              <div className="p-6 text-center">
                <div className="text-poshGold text-xl mb-2">
                  <i className="ri-exchange-dollar-line"></i>
                </div>
                <p className="text-softWhite/70">No transactions this month</p>
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
