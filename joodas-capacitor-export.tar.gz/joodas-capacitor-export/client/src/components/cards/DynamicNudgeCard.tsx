import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface NudgeItem {
  id: number;
  type: 'roast' | 'regret' | 'opportunity' | 'alert';
  message: string;
  icon: string;
}

interface DynamicNudgeCardProps {
  userId?: number;
}

export function DynamicNudgeCard({ userId = 1 }: DynamicNudgeCardProps) {
  // In a real app, this would come from a hook that fetches user data
  const [nudges] = useState<NudgeItem[]>([
    {
      id: 1,
      type: 'roast',
      message: "Your paper hands cost you 2.8 SOL last month. Try hodling next time!",
      icon: "ri-emotion-sad-line"
    },
    {
      id: 2,
      type: 'opportunity',
      message: "Last 5 times SOL dipped this low, it pumped 12% within 48 hours.",
      icon: "ri-line-chart-line"
    },
    {
      id: 3,
      type: 'regret',
      message: "If you'd held your SOL from January, you'd be up 43% more.",
      icon: "ri-time-line"
    },
    {
      id: 4,
      type: 'alert',
      message: "Jupiter offering 9.2% APY on SOL staking, better than your current 5.8%.",
      icon: "ri-alert-line"
    }
  ]);
  
  const [activeNudge, setActiveNudge] = useState(0);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 10, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { type: "spring", stiffness: 300, damping: 24 }
    }
  };
  
  // Get appropriate colors for the nudge type
  const getNudgeColor = (type: string) => {
    switch(type) {
      case 'roast':
        return "text-red-500";
      case 'opportunity':
        return "text-emerald-500";
      case 'regret':
        return "text-amber-500";
      case 'alert':
        return "text-poshGold";
      default:
        return "text-blue-500";
    }
  };
  
  const getNudgeBg = (type: string) => {
    switch(type) {
      case 'roast':
        return "bg-red-500/10";
      case 'opportunity':
        return "bg-emerald-500/10";
      case 'regret':
        return "bg-amber-500/10";
      case 'alert':
        return "bg-poshGold/10";
      default:
        return "bg-blue-500/10";
    }
  };
  
  const getNudgeTitle = (type: string) => {
    switch(type) {
      case 'roast':
        return "Crypto Roast";
      case 'opportunity':
        return "Trade Opportunity";
      case 'regret':
        return "HODL Regret";
      case 'alert':
        return "Action Alert";
      default:
        return "Nudge";
    }
  };
  
  return (
    <Card className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
      <div className="p-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="relative"
        >
          <motion.div variants={itemVariants} className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${getNudgeBg(nudges[activeNudge].type)}`}>
                <i className={`${nudges[activeNudge].icon} ${getNudgeColor(nudges[activeNudge].type)}`}></i>
              </div>
              <div className="text-sm font-semibold text-gray-800">{getNudgeTitle(nudges[activeNudge].type)}</div>
            </div>
            <div className="flex space-x-1">
              {nudges.map((_, index) => (
                <button 
                  key={index}
                  onClick={() => setActiveNudge(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${index === activeNudge ? 'bg-poshGold' : 'bg-gray-200'}`}
                />
              ))}
            </div>
          </motion.div>
          
          <motion.div variants={itemVariants} className="mb-4">
            <div className="text-base text-gray-700 mb-3">{nudges[activeNudge].message}</div>
            {nudges[activeNudge].type === 'opportunity' && (
              <div className="flex items-center space-x-2">
                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200">
                  Likely Pump
                </Badge>
                <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200">
                  Historical Pattern
                </Badge>
              </div>
            )}
            {nudges[activeNudge].type === 'roast' && (
              <div className="flex items-center space-x-2">
                <Badge className="bg-red-100 text-red-700 hover:bg-red-200">
                  Paper Hands
                </Badge>
                <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-200">
                  Missed Gains
                </Badge>
              </div>
            )}
          </motion.div>
          
          <motion.div variants={itemVariants} className="flex space-x-2">
            {nudges[activeNudge].type === 'opportunity' && (
              <>
                <button className="bg-gradient-to-r from-poshGold to-amber-400 text-white text-xs rounded-lg py-2 px-4 font-medium flex-1 shadow-sm hover:shadow-md transition-all duration-300">
                  Take Action
                </button>
                <button className="bg-transparent text-gray-500 border border-gray-200 text-xs rounded-lg py-2 px-4 font-medium hover:bg-gray-50 transition-all duration-300">
                  Dismiss
                </button>
              </>
            )}
            {nudges[activeNudge].type === 'alert' && (
              <>
                <button className="bg-poshGold text-white text-xs rounded-lg py-2 px-4 font-medium flex-1 shadow-sm hover:shadow-md transition-all duration-300">
                  Stake Now
                </button>
                <button className="bg-transparent text-gray-500 border border-gray-200 text-xs rounded-lg py-2 px-4 font-medium hover:bg-gray-50 transition-all duration-300">
                  Remind Later
                </button>
              </>
            )}
            {(nudges[activeNudge].type === 'roast' || nudges[activeNudge].type === 'regret') && (
              <button className="bg-gray-100 text-gray-700 text-xs rounded-lg py-2 px-4 font-medium w-full hover:bg-gray-200 transition-all duration-300">
                Got it
              </button>
            )}
          </motion.div>
        </motion.div>
      </div>
    </Card>
  );
}