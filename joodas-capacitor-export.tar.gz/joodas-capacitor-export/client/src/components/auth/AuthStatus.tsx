import { useFirebaseAuth } from "@/context/FirebaseAuthContext";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { UserIcon, LogOut } from "lucide-react";

export function AuthStatus() {
  const { currentUser, logout } = useFirebaseAuth();
  const [, navigate] = useLocation();
  
  const isDevMode = localStorage.getItem("devModeActive") === "true";

  if (isDevMode) {
    return (
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 bg-yellow-500/20 px-3 py-1.5 rounded-full text-xs text-yellow-600">
          <span>Developer Mode</span>
        </div>
        <Button 
          variant="ghost" 
          className="text-gray-600 hover:text-poshGold hover:bg-transparent"
          onClick={() => {
            localStorage.removeItem("devModeActive");
            navigate("/auth");
          }}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Exit Dev Mode
        </Button>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <Button
        variant="ghost"
        className="text-poshGold hover:bg-black/5"
        onClick={() => navigate("/auth")}
      >
        <UserIcon className="h-4 w-4 mr-2" />
        Sign In
      </Button>
    );
  }

  return (
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2">
        {currentUser.photoURL ? (
          <img 
            src={currentUser.photoURL} 
            alt="Profile" 
            className="h-6 w-6 rounded-full"
          />
        ) : (
          <div className="h-6 w-6 rounded-full bg-poshGold/20 text-poshGold flex items-center justify-center text-xs">
            {currentUser.email?.[0]?.toUpperCase() || '?'}
          </div>
        )}
        <span className="text-sm hidden md:inline text-gray-600">
          {currentUser.displayName || currentUser.email?.split('@')[0] || 'User'}
        </span>
      </div>
      <Button 
        variant="ghost" 
        size="sm"
        className="text-gray-600 hover:text-poshGold hover:bg-transparent"
        onClick={() => logout()}
      >
        <LogOut className="h-4 w-4" />
        <span className="ml-2 hidden md:inline">Logout</span>
      </Button>
    </div>
  );
}