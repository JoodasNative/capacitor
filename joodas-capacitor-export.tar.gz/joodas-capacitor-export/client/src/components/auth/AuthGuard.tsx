import React, { ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '../../hooks/use-toast';
import { useAuth } from '@/context/AuthContext';

interface AuthGuardProps {
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * Simplified AuthGuard component that protects routes requiring authentication
 * Focuses on a single auth path without guest mode to simplify the flow
 */
export function AuthGuard({ children, fallback }: AuthGuardProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading, isAuthenticated } = useAuth();
  const [loadingState, setLoadingState] = useState<'initial' | 'loading' | 'timeout'>('initial');
  
  // Check if we've already verified login via localStorage for faster UX
  useEffect(() => {
    const localStorageUserId = localStorage.getItem('userId');
    if (localStorageUserId) {
      console.log('User ID found in localStorage, user should be authenticated');
    }
  }, []);
  
  // Set a timeout for auth loading to prevent indefinite loading
  useEffect(() => {
    if (isLoading) {
      setLoadingState('loading');
      
      // If still loading after 5 seconds, show timeout UI
      const timer = setTimeout(() => {
        if (isLoading) {
          setLoadingState('timeout');
        }
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [isLoading]);
  
  // Bypass auth check if we have localStorage data (for better UX)
  const hasLocalAuthData = !!localStorage.getItem('userId');
  if (hasLocalAuthData) {
    console.log('User is authenticated via localStorage, bypassing auth check');
    return <>{children}</>;
  }
  
  // If still loading auth state, show a loading spinner
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-poshGold border-solid rounded-full border-t-transparent animate-spin mb-4"></div>
        <p className="text-lg font-medium text-gray-700 mb-2">Verifying authentication...</p>
        
        {loadingState === 'timeout' && (
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500 mb-4">Authentication is taking longer than expected.</p>
            <div className="flex gap-3 justify-center">
              <a 
                href="/onboarding"
                className="px-4 py-2 bg-poshGold text-white rounded-md text-sm hover:bg-poshGold/90"
              >
                Try Again
              </a>
              <a 
                href="/wallet-setup"
                className="px-4 py-2 bg-white border border-gray-300 rounded-md text-gray-700 text-sm hover:bg-gray-50"
              >
                Quick Wallet Setup
              </a>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    // Store current path for post-login redirect
    localStorage.setItem('redirectAfterLogin', window.location.pathname);
    
    // Notify user and redirect
    toast({
      title: "Authentication Required",
      description: "Please sign in to access this page",
      variant: "destructive",
    });
    
    // Redirect to onboarding page
    navigate('/onboarding');
    
    // Return fallback or null while redirecting
    return fallback ? <>{fallback}</> : null;
  }
  
  // If authenticated, store the user ID for faster client-side checks
  if (isAuthenticated && user) {
    localStorage.setItem('userId', user.id);
  }
  
  // User is authenticated, show the protected content
  return <>{children}</>;
}