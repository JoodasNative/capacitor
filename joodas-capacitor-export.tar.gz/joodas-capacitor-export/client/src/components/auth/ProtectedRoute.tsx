import { ReactNode, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useFirebaseAuth } from "@/context/FirebaseAuthContext";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProtectedRouteProps {
  children: ReactNode;
}

// This is a temporary solution for development and testing
// while Firebase domain authorization is being set up
const ENABLE_DEV_MODE = true;

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { currentUser, loading } = useFirebaseAuth();
  const [, navigate] = useLocation();
  const [usingDevMode, setUsingDevMode] = useState(false);
  
  // Check if dev bypass is active
  const isDevBypassActive = () => {
    return ENABLE_DEV_MODE && localStorage.getItem("devModeActive") === "true";
  };

  // Redirect to auth page if user is not authenticated
  useEffect(() => {
    // If dev mode bypass is active, skip authentication check
    if (isDevBypassActive()) {
      setUsingDevMode(true);
      return;
    }
    
    if (!loading && !currentUser) {
      // Store the current path for redirect after login
      localStorage.setItem("redirectAfterLogin", window.location.pathname);
      navigate("/auth");
    }
  }, [currentUser, loading, navigate]);

  // Enable developer testing mode
  const enableDevMode = () => {
    localStorage.setItem("devModeActive", "true");
    setUsingDevMode(true);
  };

  // Show loading indicator while checking auth state
  if (loading && !isDevBypassActive()) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 animate-spin text-poshGold" />
          <p className="mt-4 text-lg font-medium text-gray-600">Verifying authentication...</p>
          
          {ENABLE_DEV_MODE && (
            <div className="mt-8 text-center">
              <p className="text-gray-500 mb-2">Having trouble with Firebase auth?</p>
              <Button 
                variant="outline" 
                onClick={enableDevMode}
                className="border-poshGold text-poshGold hover:bg-poshGold/10"
              >
                Continue in Developer Mode
              </Button>
              <p className="text-xs text-gray-400 mt-2">
                (This bypasses authentication for testing purposes)
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // If dev mode or authenticated, render children
  if (isDevBypassActive() || usingDevMode || currentUser) {
    if (usingDevMode || isDevBypassActive()) {
      return (
        <>
          <div className="fixed top-0 left-0 right-0 bg-yellow-500 text-black text-xs py-1 text-center z-50">
            Developer Mode Active - Authentication Bypassed
          </div>
          {children}
        </>
      );
    }
    return <>{children}</>;
  }
  
  return null; // Don't render anything if not authenticated and not in dev mode
}