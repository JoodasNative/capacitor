import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface SettingItem {
  icon: string;
  label: string;
  action: () => void;
  badge?: string;
  danger?: boolean;
  premium?: boolean;
  comingSoon?: boolean;
}

interface SettingsCardProps {
  items: SettingItem[];
}

export function SettingsCard({ items }: SettingsCardProps) {
  return (
    <Card className="card-premium divide-y divide-gray-100 overflow-hidden rounded-xl shadow-md">
      {items.map((item, index) => (
        <motion.button
          key={index}
          onClick={item.action}
          disabled={item.comingSoon}
          whileHover={{ backgroundColor: item.danger ? "rgba(252, 165, 165, 0.1)" : "rgba(248, 250, 252, 0.8)" }}
          whileTap={{ scale: 0.98 }}
          className={cn(
            "w-full flex items-center justify-between p-4 transition-all duration-200",
            item.danger && "hover:text-red-500",
            item.comingSoon && "opacity-60 cursor-not-allowed"
          )}
        >
          <div className="flex items-center">
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center mr-4 transition-all duration-300",
              item.danger ? "bg-red-50 text-red-500" : 
              item.premium ? "bg-gradient-to-br from-poshGold to-amber-200 text-white" : 
              "bg-gray-50 text-gray-700"
            )}>
              <i className={item.icon}></i>
            </div>
            <div className="flex flex-col items-start">
              <div className={cn(
                "text-left font-medium text-gray-800",
                item.danger && "text-red-500"
              )}>
                {item.label}
              </div>
              
              {item.comingSoon && (
                <span className="text-xs text-gray-400 mt-0.5">Coming soon</span>
              )}
            </div>
          </div>
          
          <div className="flex items-center">
            {item.badge && (
              <div className={cn(
                "text-xs px-3 py-1 rounded-full mr-3 font-medium",
                item.premium ? "bg-poshGold/10 text-poshGold" : "bg-gray-100 text-gray-700"
              )}>
                {item.badge}
              </div>
            )}
            {!item.comingSoon && (
              <div className="w-6 h-6 flex items-center justify-center text-gray-400">
                <i className="ri-arrow-right-s-line"></i>
              </div>
            )}
          </div>
        </motion.button>
      ))}
    </Card>
  );
}
