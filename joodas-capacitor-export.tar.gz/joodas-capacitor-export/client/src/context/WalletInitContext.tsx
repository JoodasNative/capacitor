import { createContext, ReactNode, useContext, useState, useEffect } from "react";

interface WalletInitContextType {
  isInitialized: boolean;
  isInitializing: boolean;
  hasWalletError: boolean;
  errorMessage: string | null;
  setInitialized: (value: boolean) => void;
  setInitializing: (value: boolean) => void;
  setWalletError: (error: string | null) => void;
  resetWalletState: () => void;
}

const defaultContext: WalletInitContextType = {
  isInitialized: false,
  isInitializing: false,
  hasWalletError: false,
  errorMessage: null,
  setInitialized: () => {},
  setInitializing: () => {},
  setWalletError: () => {},
  resetWalletState: () => {}
};

const WalletInitContext = createContext<WalletInitContextType>(defaultContext);

export function useWalletInit() {
  return useContext(WalletInitContext);
}

export function WalletInitProvider({ children }: { children: ReactNode }) {
  // We'll use localStorage to persist the wallet initialization state
  // This prevents repeated initialization attempts across page reloads
  const [isInitialized, setIsInitialized] = useState<boolean>(() => {
    const savedState = localStorage.getItem('wallet_initialized');
    return savedState === 'true';
  });
  
  const [isInitializing, setIsInitializing] = useState<boolean>(false);
  const [hasWalletError, setHasWalletError] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Store initialization state in localStorage when it changes
  useEffect(() => {
    localStorage.setItem('wallet_initialized', isInitialized.toString());
  }, [isInitialized]);

  // Set initialized state
  const setInitialized = (value: boolean) => {
    setIsInitialized(value);
    
    // Clear any error if we successfully initialize
    if (value) {
      setHasWalletError(false);
      setErrorMessage(null);
    }
  };

  // Set wallet error
  const setWalletError = (error: string | null) => {
    if (error) {
      setHasWalletError(true);
      setErrorMessage(error);
    } else {
      setHasWalletError(false);
      setErrorMessage(null);
    }
  };

  // Reset wallet state (for logout, etc.)
  const resetWalletState = () => {
    setIsInitialized(false);
    setIsInitializing(false);
    setHasWalletError(false);
    setErrorMessage(null);
    localStorage.removeItem('wallet_initialized');
  };

  const value: WalletInitContextType = {
    isInitialized,
    isInitializing,
    hasWalletError,
    errorMessage,
    setInitialized,
    setInitializing: setIsInitializing,
    setWalletError,
    resetWalletState
  };

  return (
    <WalletInitContext.Provider value={value}>
      {children}
    </WalletInitContext.Provider>
  );
}