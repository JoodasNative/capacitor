import { createContext, useState, useEffect, useContext, ReactNode } from "react";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  GoogleAuthProvider,
  signInWithPopup,
  User,
  onAuthStateChanged 
} from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import { initializeApp } from "firebase/app";
import { Capacitor } from "@capacitor/core";
import { Device } from "@capacitor/device";

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  messagingSenderId: "",
  measurementId: ""
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Define user profile and wallet types
interface UserWallet {
  address: string;
  type: string;
  createdAt: Date;
}

interface UserProfile {
  userId: string;
  email: string | null;
  name?: string | null;
  wallet?: UserWallet;
  deviceInfo?: any;
  lastLogin?: Date;
}

// Auth context type definition
interface AuthContextType {
  currentUser: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isNative: boolean;
  isAuthenticated: boolean;
  signUp: (email: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
}

// Default context values
const defaultContextValue: AuthContextType = {
  currentUser: null,
  profile: null,
  loading: true,
  isNative: false,
  isAuthenticated: false,
  signUp: async () => {},
  login: async () => {},
  loginWithGoogle: async () => {},
  logout: async () => {},
  resetPassword: async () => {},
  updateProfile: async () => {}
};

// Create the auth context
const AuthContext = createContext<AuthContextType>(defaultContextValue);

// Custom hook to use auth context
export function useAuth() {
  return useContext(AuthContext);
}

// Auth provider component
export function CapacitorAuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const isNative = Capacitor.isNativePlatform();
  
  // Create or update user profile in Firestore
  const createOrUpdateProfile = async (user: User) => {
    try {
      // Get device info for native platforms
      let deviceInfo = null;
      if (isNative) {
        deviceInfo = await Device.getInfo();
      }
      
      const userRef = doc(db, "users", user.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        // Update existing profile
        await updateDoc(userRef, {
          lastLogin: serverTimestamp(),
          ...(deviceInfo && { deviceInfo })
        });
        
        // Get updated profile
        const updatedSnap = await getDoc(userRef);
        setProfile(updatedSnap.data() as UserProfile);
      } else {
        // Create new profile
        const updatedProfile: UserProfile = {
          userId: user.uid,
          email: user.email,
          name: user.displayName,
          lastLogin: new Date(),
          ...(deviceInfo && { deviceInfo })
        };
        
        await setDoc(userRef, updatedProfile);
        setProfile(updatedProfile);
      }
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };
  
  // Sign up with email and password
  async function signUp(email: string, password: string) {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await createOrUpdateProfile(userCredential.user);
    } catch (error: any) {
      console.error("Error signing up:", error.message);
      throw error;
    }
  }
  
  // Log in with email and password
  async function login(email: string, password: string) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      await createOrUpdateProfile(userCredential.user);
    } catch (error: any) {
      console.error("Error logging in:", error.message);
      throw error;
    }
  }
  
  // Log in with Google
  async function handleGoogleLogin() {
    try {
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      await createOrUpdateProfile(userCredential.user);
    } catch (error: any) {
      console.error("Error with Google login:", error.message);
      throw error;
    }
  }
  
  // Log out
  async function logout() {
    try {
      await signOut(auth);
      setProfile(null);
    } catch (error: any) {
      console.error("Error logging out:", error.message);
      throw error;
    }
  }
  
  // Reset password
  async function resetPassword(email: string) {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error: any) {
      console.error("Error resetting password:", error.message);
      throw error;
    }
  }
  
  // Update user profile
  async function updateProfile(data: Partial<UserProfile>) {
    if (!currentUser) {
      throw new Error("No authenticated user");
    }
    
    try {
      const userRef = doc(db, "users", currentUser.uid);
      await updateDoc(userRef, { ...data, updatedAt: serverTimestamp() });
      
      // Update local state
      setProfile(prev => prev ? { ...prev, ...data } : null);
    } catch (error: any) {
      console.error("Error updating profile:", error.message);
      throw error;
    }
  }

  // Effect to listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      if (user) {
        try {
          const userRef = doc(db, "users", user.uid);
          const userSnap = await getDoc(userRef);
          
          if (userSnap.exists()) {
            setProfile(userSnap.data() as UserProfile);
          } else {
            await createOrUpdateProfile(user);
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
        }
      } else {
        setProfile(null);
      }
      
      setLoading(false);
    });
    
    return unsubscribe;
  }, []);

  // Create context value
  const value: AuthContextType = {
    currentUser,
    profile,
    loading,
    isNative,
    isAuthenticated: !!currentUser,
    signUp,
    login,
    loginWithGoogle: handleGoogleLogin,
    logout,
    resetPassword,
    updateProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading ? children : (
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin h-8 w-8 border-4 border-gold border-t-transparent rounded-full"></div>
        </div>
      )}
    </AuthContext.Provider>
  );
}