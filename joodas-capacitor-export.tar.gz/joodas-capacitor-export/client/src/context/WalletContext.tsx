import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface WalletContextType {
  walletAddress: string | null;
  isConnected: boolean;
  balance: number;
  connectWallet: (type: string) => Promise<void>;
  disconnectWallet: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

interface WalletProviderProps {
  children: ReactNode;
}

export function WalletProvider({ children }: WalletProviderProps) {
  // Provide mock values for development
  const walletAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e";
  const isConnected = true;
  const balance = 47.57;

  // Simplified mock functions
  const connectWallet = async (type: string) => {
    console.log(`Mock connecting to ${type} wallet`);
    return Promise.resolve();
  };

  const disconnectWallet = () => {
    console.log("Mock disconnecting wallet");
  };

  return (
    <WalletContext.Provider value={{
      walletAddress,
      isConnected,
      balance,
      connectWallet,
      disconnectWallet,
    }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
