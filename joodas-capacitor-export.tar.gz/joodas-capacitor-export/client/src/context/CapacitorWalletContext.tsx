import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { createWallet, getWallet, refreshWalletBalance, getWalletTransactions, SolanaWallet } from "@/services/capacitor-wallet";
import { useAuth } from "./CapacitorAuthContext";
import { Capacitor } from "@capacitor/core";

interface WalletContextType {
  wallet: SolanaWallet | null;
  loading: boolean;
  isCreating: boolean;
  transactions: any[];
  isNative: boolean;
  createUserWallet: () => Promise<SolanaWallet | null>;
  refreshBalance: () => Promise<number>;
  loadTransactions: () => Promise<any[]>;
}

const defaultContextValue: WalletContextType = {
  wallet: null,
  loading: true,
  isCreating: false,
  transactions: [],
  isNative: false,
  createUserWallet: async () => null,
  refreshBalance: async () => 0,
  loadTransactions: async () => [],
};

const CapacitorWalletContext = createContext<WalletContextType>(defaultContextValue);

export function useCapacitorWallet() {
  return useContext(CapacitorWalletContext);
}

export function CapacitorWalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<SolanaWallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const isNative = Capacitor.isNativePlatform();
  
  const { currentUser, isAuthenticated } = useAuth();

  // Initialize wallet
  useEffect(() => {
    async function initWallet() {
      try {
        if (isAuthenticated && currentUser) {
          setLoading(true);
          const existingWallet = await getWallet();
          
          if (existingWallet) {
            setWallet(existingWallet);
            // Load transactions
            const txHistory = await getWalletTransactions();
            setTransactions(txHistory);
            // Refresh balance
            refreshBalance();
          }
        }
      } catch (error) {
        console.error("Error initializing wallet:", error);
      } finally {
        setLoading(false);
      }
    }

    initWallet();
  }, [isAuthenticated, currentUser]);

  // Create a new wallet for the authenticated user
  const createUserWallet = async (): Promise<SolanaWallet | null> => {
    if (!isAuthenticated || !currentUser) {
      console.error("User must be authenticated to create a wallet");
      return null;
    }
    
    try {
      setIsCreating(true);
      const newWallet = await createWallet();
      if (newWallet) {
        setWallet(newWallet);
        return newWallet;
      }
      return null;
    } catch (error) {
      console.error("Error creating wallet:", error);
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  // Refresh the wallet balance
  const refreshBalance = async (): Promise<number> => {
    if (!wallet) return 0;
    
    try {
      const balance = await refreshWalletBalance();
      setWallet(prev => prev ? { ...prev, balance, lastUpdated: new Date() } : null);
      return balance;
    } catch (error) {
      console.error("Error refreshing balance:", error);
      return 0;
    }
  };

  // Load wallet transactions
  const loadTransactions = async (): Promise<any[]> => {
    if (!wallet) return [];
    
    try {
      const txHistory = await getWalletTransactions();
      setTransactions(txHistory);
      return txHistory;
    } catch (error) {
      console.error("Error loading transactions:", error);
      return [];
    }
  };

  const value: WalletContextType = {
    wallet,
    loading,
    isCreating,
    transactions,
    isNative,
    createUserWallet,
    refreshBalance,
    loadTransactions,
  };

  return (
    <CapacitorWalletContext.Provider value={value}>
      {children}
    </CapacitorWalletContext.Provider>
  );
}