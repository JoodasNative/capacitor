import React, { createContext, useContext, ReactNode } from 'react';
import { useAuthQuery, redirectToLogin, redirectToLogout, User } from '../hooks/useAuth';

// Define the context shape
interface AuthContextType {
  user: User | null | undefined;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: Error | null;
  login: () => void;
  logout: () => void;
}

// Default values for the context
const defaultContextValue: AuthContextType = {
  user: null,
  isLoading: true,
  isAuthenticated: false,
  error: null,
  login: () => {},
  logout: () => {},
};

// Create the context with the default value
const AuthContext = createContext<AuthContextType>(defaultContextValue);

// Define the provider props
interface AuthProviderProps {
  children: ReactNode;
}

// Create the provider component
export function AuthProvider({ children }: AuthProviderProps) {
  // Query for auth state
  const { data, isLoading, error } = useAuthQuery();

  // Cast the user data to our User type or null
  const user = data as User | null | undefined;
  
  // Check if user is authenticated
  const isAuthenticated = !!user;

  // Login function
  const login = () => {
    redirectToLogin();
  };

  // Logout function
  const logout = () => {
    redirectToLogout();
  };

  // Create context value
  const value = {
    user,
    isLoading,
    isAuthenticated,
    error,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Create a hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}