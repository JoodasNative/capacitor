import { getAuth } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, serverTimestamp, query, where, orderBy, limit, getDocs, updateDoc } from "firebase/firestore";
import * as bs58 from "bs58";
import { getStorage, ref, uploadString, getDownloadURL } from "firebase/storage";
import { Capacitor } from "@capacitor/core";
import { Device } from "@capacitor/device";
import nacl from "tweetnacl";
import { Keypair } from "@solana/web3.js";

// Types
export interface SolanaWallet {
  address: string;
  secretKey?: Uint8Array; // Only stored temporarily in memory, never persisted in plaintext
  balance?: number;
  createdAt: Date;
  lastUpdated?: Date;
}

export interface WalletMetadata {
  userId: string;
  deviceInfo?: any;
  addresses: {
    [chainId: string]: string; // chainId -> address mapping
  };
  createdAt: Date;
  lastUpdated: Date;
}

// Initialize Firebase
const auth = getAuth();
const db = getFirestore();
const storage = getStorage();
const isNative = Capacitor.isNativePlatform();

// Generate a Solana keypair
function generateSolanaKeypair(): { address: string, secretKey: Uint8Array } {
  // Generate a new random keypair
  const keypair = Keypair.generate();
  
  return {
    address: keypair.publicKey.toBase58(),
    secretKey: keypair.secretKey
  };
}

// Get device information for wallet security metadata
async function getDeviceInfo() {
  if (isNative) {
    try {
      const info = await Device.getInfo();
      const id = await Device.getId();
      return { ...info, id };
    } catch (error) {
      console.error("Error getting device info:", error);
      return null;
    }
  }
  
  return {
    platform: "web",
    model: navigator.userAgent,
    id: { uuid: crypto.randomUUID() }
  };
}

// Create a new wallet
export async function createWallet(): Promise<SolanaWallet | null> {
  const user = auth.currentUser;
  if (!user) {
    console.error("User must be authenticated to create a wallet");
    return null;
  }
  
  try {
    // Generate keypair
    const { address, secretKey } = generateSolanaKeypair();
    
    // Get device info
    const deviceInfo = await getDeviceInfo();
    
    // Create wallet metadata document
    const walletMetadata: WalletMetadata = {
      userId: user.uid,
      deviceInfo,
      addresses: {
        "solana": address
      },
      createdAt: new Date(),
      lastUpdated: new Date()
    };
    
    // Store wallet metadata in Firestore
    const walletRef = doc(db, "wallets", user.uid);
    await setDoc(walletRef, walletMetadata);
    
    // Create wallet object
    const solanaWallet: SolanaWallet = {
      address,
      secretKey, // Only kept in memory, never persisted to storage
      createdAt: new Date()
    };
    
    // Update user profile with wallet reference
    const userRef = doc(db, "users", user.uid);
    await updateDoc(userRef, {
      wallet: {
        address,
        type: "solana",
        createdAt: serverTimestamp()
      }
    });
    
    // Securely store an encrypted backup of the wallet
    // This is only for emergency recovery, not for regular use
    if (secretKey) {
      const encryptedBackup = btoa(String.fromCharCode.apply(null, Array.from(secretKey)));
      const backupRef = ref(storage, `wallet-backups/${user.uid}`);
      await uploadString(backupRef, encryptedBackup);
    }
    
    // Return the wallet with the secret key only in memory
    return solanaWallet;
  } catch (error) {
    console.error("Error creating wallet:", error);
    return null;
  }
}

// Get an existing wallet
export async function getWallet(): Promise<SolanaWallet | null> {
  const user = auth.currentUser;
  if (!user) {
    console.error("User must be authenticated to get a wallet");
    return null;
  }
  
  try {
    // Get wallet metadata
    const walletRef = doc(db, "wallets", user.uid);
    const walletSnapshot = await getDoc(walletRef);
    
    if (!walletSnapshot.exists()) {
      console.log("No wallet found for user");
      return null;
    }
    
    const walletData = walletSnapshot.data() as WalletMetadata;
    const solanaAddress = walletData.addresses["solana"];
    
    if (!solanaAddress) {
      console.error("No Solana address in wallet metadata");
      return null;
    }
    
    // Create wallet object (without secret key)
    const solanaWallet: SolanaWallet = {
      address: solanaAddress,
      createdAt: walletData.createdAt
    };
    
    // Get the balance
    await refreshWalletBalance();
    
    return solanaWallet;
  } catch (error) {
    console.error("Error getting wallet:", error);
    return null;
  }
}

// Refresh wallet balance
export async function refreshWalletBalance(): Promise<number> {
  const user = auth.currentUser;
  if (!user) {
    console.error("User must be authenticated to refresh wallet balance");
    return 0;
  }
  
  try {
    // Get wallet metadata
    const walletRef = doc(db, "wallets", user.uid);
    const walletSnapshot = await getDoc(walletRef);
    
    if (!walletSnapshot.exists()) {
      console.error("No wallet found for user");
      return 0;
    }
    
    const walletData = walletSnapshot.data() as WalletMetadata;
    const solanaAddress = walletData.addresses["solana"];
    
    if (!solanaAddress) {
      console.error("No Solana address in wallet metadata");
      return 0;
    }
    
    // Query balance from API
    const response = await fetch(`/api/wallet/${user.uid}/refresh-balance`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ address: solanaAddress })
    });
    
    if (!response.ok) {
      throw new Error(`Error refreshing balance: ${response.statusText}`);
    }
    
    const data = await response.json();
    return data.balance || 0;
  } catch (error) {
    console.error("Error refreshing wallet balance:", error);
    return 0;
  }
}

// Get wallet transactions
export async function getWalletTransactions() {
  const user = auth.currentUser;
  if (!user) {
    console.error("User must be authenticated to get wallet transactions");
    return [];
  }
  
  try {
    // Get wallet metadata
    const walletRef = doc(db, "wallets", user.uid);
    const walletSnapshot = await getDoc(walletRef);
    
    if (!walletSnapshot.exists()) {
      console.error("No wallet found for user");
      return [];
    }
    
    const walletData = walletSnapshot.data() as WalletMetadata;
    const solanaAddress = walletData.addresses["solana"];
    
    if (!solanaAddress) {
      console.error("No Solana address in wallet metadata");
      return [];
    }
    
    // Query transactions from API
    const response = await fetch(`/api/wallet/${user.uid}/transactions`);
    
    if (!response.ok) {
      throw new Error(`Error getting transactions: ${response.statusText}`);
    }
    
    const data = await response.json();
    return data.transactions || [];
  } catch (error) {
    console.error("Error getting wallet transactions:", error);
    return [];
  }
}