import BottomNavbar from "@/components/layout/BottomNavbar";
import { ChartCard, SpendingOverviewCard } from "@/components/cards/ChartCard";
import { motion } from "framer-motion";
import { useTotalBalance } from "@/hooks/use-wallet";
import { useTransactions } from "@/hooks/use-transactions";
import { formatCurrency } from "@/lib/utils";

export default function Analytics() {
  const { totalBalance } = useTotalBalance();
  const { transactions } = useTransactions(1, 20);

  // Sample data for categories
  const spendingCategories = [
    { name: 'Investment', amount: totalBalance * 0.65, color: 'bg-blue-400' },
    { name: 'Entertainment', amount: totalBalance * 0.25, color: 'bg-purple-400' },
    { name: 'Food & beverages', amount: totalBalance * 0.10, color: 'bg-poshGold' }
  ];

  // Prepare chart data based on transactions
  const prepareChartData = () => {
    const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    
    // Generate base data with all days
    const baseData = days.map(day => ({
      name: day,
      spending: 0,
      income: 0
    }));
    
    // If we have transactions, use them to populate data
    if (transactions && transactions.length > 0) {
      transactions.forEach(tx => {
        const day = new Date(tx.date).getDay();
        const dayName = days[day];
        
        const dataIndex = baseData.findIndex(item => item.name === dayName);
        if (dataIndex !== -1) {
          if (tx.amount > 0) {
            baseData[dataIndex].income += tx.amount;
          } else {
            baseData[dataIndex].spending += Math.abs(tx.amount);
          }
        }
      });
    } else {
      // Use random data as fallback
      return [
        { name: 'S', spending: 40, income: 65 },
        { name: 'M', spending: 60, income: 40 },
        { name: 'T', spending: 70, income: 80 },
        { name: 'W', spending: 50, income: 35 },
        { name: 'T', spending: 80, income: 55 },
        { name: 'F', spending: 30, income: 45 },
        { name: 'S', spending: 60, income: 70 }
      ];
    }
    
    return baseData;
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        delayChildren: 0.1,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="relative min-h-screen flex flex-col pb-20">
      <div className="bg-background px-4 py-3 flex justify-between items-center border-b border-gray-100">
        <button onClick={() => window.history.back()} className="text-gray-700">
          <i className="ri-arrow-left-s-line text-lg"></i>
        </button>
        <div className="text-lg font-semibold text-gray-800">Account Statistics</div>
        <button className="text-gray-700">
          <i className="ri-search-line text-lg"></i>
        </button>
      </div>
      
      <motion.div 
        className="flex-1 overflow-y-auto pb-20"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Spent Overview */}
        <motion.div variants={itemVariants}>
          <SpendingOverviewCard 
            total={totalBalance} 
            percentChange={3.7}
            categories={spendingCategories}
          />
        </motion.div>
        
        {/* Statistics Summary */}
        <motion.div className="px-4 mb-6" variants={itemVariants}>
          <ChartCard 
            title="Statistics Summary"
            dateRange="Jan 1, 2023 - Jan 30, 2023"
            data={prepareChartData()}
            type="line"
          />
        </motion.div>
        
        {/* Transaction Section */}
        <motion.div className="px-4 mb-10" variants={itemVariants}>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-cinzel text-lg font-medium">Transaction</h2>
            <button className="text-poshGold text-sm">Filter</button>
          </div>
          
          {/* Transaction List */}
          <div className="card divide-y divide-softWhite/10">
            {/* Dynamically generate transaction items */}
            {transactions && transactions.slice(0, 3).map((tx, index) => (
              <motion.div 
                key={tx.id}
                className="p-3 flex items-center justify-between"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + (index * 0.1) }}
              >
                <div className="flex items-center">
                  <div className={`w-10 h-10 rounded-md ${tx.amount > 0 ? 'bg-success/10' : 'bg-warning/10'} flex items-center justify-center mr-3`}>
                    <i className={`${tx.note?.includes('Netflix') ? 'ri-netflix-fill' : tx.note?.includes('ETH') ? 'ri-coin-line' : tx.note?.includes('NFT') ? 'ri-gamepad-line' : 'ri-exchange-dollar-line'} ${tx.amount > 0 ? 'text-success' : 'text-warning'}`}></i>
                  </div>
                  <div>
                    <div className="font-medium">{tx.note || `${tx.type} ${tx.token}`}</div>
                  </div>
                </div>
                <div className={tx.amount > 0 ? 'text-success' : 'text-warning'}>
                  {formatCurrency(Math.abs(tx.amount))}
                </div>
              </motion.div>
            ))}
            
            {(!transactions || transactions.length === 0) && (
              <div className="p-6 text-center">
                <div className="text-poshGold text-xl mb-2">
                  <i className="ri-exchange-dollar-line"></i>
                </div>
                <p className="text-softWhite/70">No transactions found</p>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
      
      <BottomNavbar activePage="stats" />
    </div>
  );
}
