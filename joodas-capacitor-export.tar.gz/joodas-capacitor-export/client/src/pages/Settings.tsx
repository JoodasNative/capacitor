import BottomNavbar from "@/components/layout/BottomNavbar";
import { SettingsCard } from "@/components/settings/SettingsCard";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { BadgeAnimated } from "@/components/ui/badge-animated";
import { motion } from "framer-motion";
import { Separator } from "@/components/ui/separator";
import { useLocation } from "wouter";
import { redirectToLogout } from "@/hooks/useAuth";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useFirebaseAuth } from "@/context/FirebaseAuthContext";

export default function Settings() {
  // Get Firebase auth user info
  const { currentUser, logout } = useFirebaseAuth();
  
  // Wallet data
  const walletAddress = "3PgoZVo9Cdw1nhtXzA7wSemfRk3jAxHBbu4G9jP4BTV4";
  const isConnected = !!currentUser;
  
  // Sample user data
  const userData = {
    username: currentUser?.displayName || currentUser?.email?.split('@')[0] || "DegenTrader",
    level: 4,
    badges: ["Diamond Hands", "Dip Buyer", "HODL Master"],
  };
  
  // Sample progress data
  const levelProgress = 65;
  const nextLevel = 5;
  
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // User display name 
  const displayName = currentUser?.displayName || currentUser?.email?.split('@')[0] || "Degen Trader";
  
  // User email from Firebase auth
  const userEmail = currentUser?.email || "user@example.com";
  
  // First name for avatar fallback
  const userFirstName = currentUser?.displayName?.split(' ')[0] || currentUser?.email?.[0] || "D";
  
  // Profile image from Firebase
  const profileImage = currentUser?.photoURL || null;

  const handleLogout = async () => {
    setIsLoggingOut(true);
    toast({
      title: "Logging out...",
      description: "You will be redirected to the login page",
    });
    
    try {
      // Use Firebase logout 
      await logout();
      navigate('/auth');
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        title: "Logout failed",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setIsLoggingOut(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        delayChildren: 0.1,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  const settingsSections = [
    {
      title: "Account Settings",
      items: [
        { 
          icon: "ri-user-settings-line", 
          label: "Account Management", 
          action: () => {
            toast({
              title: "Account Management",
              description: "Manage your profile and wallet in one place",
            });
          }, 
          premium: true,
          badge: "Premium" 
        },
        { 
          icon: "ri-wallet-3-line", 
          label: "View Wallet", 
          action: () => {
            navigate("/wallet");
          },
          badge: "One-Click" 
        },
        { 
          icon: "ri-shield-keyhole-line", 
          label: "Authentication", 
          action: () => {
            toast({
              description: "You're using Seamless Degen Onboarding",
            });
          }, 
          badge: "Secure",
          premium: true 
        }
      ]
    },
    {
      title: "Preferences",
      items: [
        { 
          icon: "ri-palette-line", 
          label: "App Theme", 
          action: () => {
            toast({
              title: "Theme Settings",
              description: "Joodas Posh Gold is the default theme",
            });
          }, 
          badge: "Gold" 
        },
        { 
          icon: "ri-notification-3-line", 
          label: "Notifications", 
          action: () => {
            toast({
              title: "Notifications",
              description: "This feature is coming soon",
            });
          }, 
          comingSoon: true 
        },
        { 
          icon: "ri-translate-2", 
          label: "Language", 
          action: () => {}, 
          badge: "English" 
        }
      ]
    },
    {
      title: "Features",
      items: [
        { 
          icon: "ri-robot-line", 
          label: "AI Trading Insights", 
          action: () => {
            navigate("/insights");
          }, 
          premium: true,
          badge: "Pro" 
        },
        { 
          icon: "ri-fire-line", 
          label: "HODL Streaks", 
          action: () => {
            navigate("/karma");
          }
        },
        { 
          icon: "ri-coin-line", 
          label: "Financial Karma", 
          action: () => {
            navigate("/karma");
          }, 
          premium: true,
          badge: "Premium" 
        }
      ]
    },
    {
      title: "Support",
      items: [
        { 
          icon: "ri-customer-service-2-line", 
          label: "Help Center", 
          action: () => {
            toast({
              title: "Help Center",
              description: "This feature is coming soon",
            });
          },
          comingSoon: true 
        },
        { 
          icon: "ri-information-line", 
          label: "About Joodas 2.0", 
          action: () => {
            toast({
              title: "Joodas 2.0",
              description: "The premium crypto personal finance app",
            });
          }
        },
        { 
          icon: "ri-logout-box-line", 
          label: "Logout", 
          action: handleLogout, 
          danger: true,
          badge: "Exit"
        }
      ]
    }
  ];

  return (
    <div className="relative min-h-screen flex flex-col pb-20 bg-white">
      {/* Header with gold accent */}
      <div className="px-4 py-3 flex justify-between items-center border-b border-gray-100 bg-gradient-to-r from-white to-gray-50">
        <button onClick={() => window.history.back()} className="text-gray-700 hover:text-poshGold transition-colors">
          <i className="ri-arrow-left-s-line text-lg"></i>
        </button>
        <div className="text-lg font-semibold text-gray-800">Settings</div>
        <div className="w-8"></div>
      </div>
      
      <motion.div 
        className="flex-1 overflow-y-auto pb-20"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Premium Profile Card */}
        <motion.div 
          className="p-6 mx-4 my-6 rounded-2xl overflow-hidden bg-white shadow-md border border-gray-100 relative"
          variants={itemVariants}
        >
          {/* Gold accent corner */}
          <div className="absolute w-20 h-20 -top-10 -right-10 bg-poshGold/10 rotate-45"></div>
          <div className="absolute w-16 h-16 -top-8 -right-8 bg-poshGold/20 rotate-45"></div>
          
          <div className="flex items-center">
            <Avatar className="h-16 w-16 mr-4 border-2 border-poshGold shadow-md overflow-hidden">
              {profileImage ? (
                <AvatarImage src={profileImage} alt="Profile" />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-poshGold to-amber-200 text-white text-xl">
                  {userFirstName?.charAt(0) || "D"}
                </AvatarFallback>
              )}
            </Avatar>
            
            <div className="flex-1">
              <h2 className="font-semibold text-lg text-gray-800">{displayName}</h2>
              <div className="text-sm text-gray-500 mb-1 flex items-center">
                <i className="ri-mail-line mr-1 text-poshGold"></i>
                {userEmail}
              </div>
              
              <div className="mt-2 flex items-center">
                <span className="text-xs font-medium mr-2 text-poshGold bg-poshGold/10 px-2 py-0.5 rounded-full">
                  Seamless Degen Onboarding
                </span>
                
                <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
                  Connected
                </span>
              </div>
            </div>
          </div>
          
          {/* Level progress */}
          <div className="mt-6">
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-xs font-medium text-gray-700 flex items-center">
                <span className="inline-block mr-1 bg-poshGold/20 text-poshGold px-1.5 py-0.5 rounded">
                  Level {userData?.level || 1}
                </span>
                <span className="text-gray-500">Degen</span>
              </span>
              <span className="text-xs font-medium text-gray-700 flex items-center">
                <span className="text-gray-500 mr-1">Next:</span>
                <span className="inline-block bg-poshGold/10 text-poshGold px-1.5 py-0.5 rounded">
                  Level {nextLevel}
                </span>
              </span>
            </div>
            <div className="h-3 bg-gray-50 rounded-full overflow-hidden border border-gray-100 shadow-inner">
              <div 
                className="h-full bg-gradient-to-r from-poshGold to-amber-300 rounded-full shadow-sm"
                style={{ width: `${levelProgress}%` }}
              >
                <div className="h-full w-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+CiAgPHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0ibm9uZSIgLz4KICA8ZGVmcz4KICAgIDxwYXR0ZXJuIGlkPSJkaWFnb25hbEhhdGNoIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIiB3aWR0aD0iNCIgaGVpZ2h0PSI0Ij4KICAgICAgPHBhdGggZD0iTTAgNCBsNCAtNCBNLTEgMSBsMiAtMiBNMyA1IGwyIC0yIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xNSkiIHN0cm9rZS13aWR0aD0iMC41Ii8+CiAgICA8L3BhdHRlcm4+CiAgPC9kZWZzPgogIDxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZGlhZ29uYWxIYXRjaCkiIC8+Cjwvc3ZnPg==')]"></div>
              </div>
            </div>
            <div className="mt-1.5 text-xs flex justify-between">
              <span className="text-gray-500">Progress:</span>
              <span className="font-medium text-poshGold">{levelProgress}% complete</span>
            </div>
          </div>
        </motion.div>
        
        {/* Badges Section */}
        <motion.div className="px-6 mb-10" variants={itemVariants}>
          <h3 className="text-sm font-semibold mb-4 text-gray-800 flex items-center">
            <i className="ri-award-line mr-2 text-poshGold"></i>
            Your Achievements
            <div className="ml-2 h-px bg-gradient-to-r from-poshGold/20 to-transparent flex-grow"></div>
          </h3>
          <div className="p-4 rounded-xl bg-gradient-to-b from-white to-gray-50 border border-gray-100 shadow-sm">
            <div className="flex flex-wrap gap-3">
              {userData?.badges && userData.badges.length > 0 ? (
                userData.badges.map((badge, index) => (
                  <button 
                    key={index} 
                    className="group relative" 
                    onClick={() => toast({
                      title: badge,
                      description: `You earned the ${badge} achievement! Keep up the good work.`,
                    })}
                  >
                    <BadgeAnimated key={index} label={badge} delay={0.2 + (index * 0.1)} />
                    <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 rounded transition-all duration-200"></div>
                  </button>
                ))
              ) : (
                <div className="flex flex-col items-center w-full py-4 space-y-2">
                  <div className="text-gray-400"><i className="ri-award-line text-3xl"></i></div>
                  <div className="text-sm text-gray-500">No badges yet</div>
                  <Badge variant="outline" className="bg-gray-50/50 text-gray-500 border-gray-200">
                    Complete trades to earn achievements
                  </Badge>
                </div>
              )}
            </div>
          </div>
        </motion.div>
        
        {/* Settings Sections */}
        {settingsSections.map((section, sectionIndex) => (
          <motion.div 
            key={section.title} 
            className="px-6 mb-8"
            variants={itemVariants}
            transition={{ delay: 0.3 + (sectionIndex * 0.1) }}
          >
            <h3 className="text-sm font-semibold mb-3 text-gray-700 flex items-center">
              {section.title}
              <div className="ml-2 h-px bg-gradient-to-r from-poshGold/20 to-transparent flex-grow"></div>
            </h3>
            <SettingsCard items={section.items} />
          </motion.div>
        ))}
        
        {/* App Info */}
        <motion.div 
          className="px-4 mb-24 text-center text-xs"
          variants={itemVariants}
        >
          <div className="pb-4 pt-2">
            <div className="h-px w-24 mx-auto bg-gradient-to-r from-transparent via-poshGold/20 to-transparent"></div>
          </div>
          <p className="text-poshGold font-medium">Joodas 2.0 - Wallet Whisperer</p>
          <p className="mt-1 text-gray-500">The premium crypto personal finance app</p>
          <p className="mt-3 text-gray-400 text-[10px]">© 2025 Joodas Finance</p>
        </motion.div>
      </motion.div>
      
      <BottomNavbar activePage="settings" />
    </div>
  );
}
