import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ConnectWalletModal } from "@/components/modals/ConnectWalletModal";
import { useState } from "react";

export default function Onboarding() {
  const [, navigate] = useLocation();
  const [showConnectModal, setShowConnectModal] = useState(false);

  // Animations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  const handleGetStarted = () => {
    setShowConnectModal(true);
  };

  return (
    <div className="relative h-screen flex flex-col">
      {/* Status Bar */}
      <div className="bg-darkCharcoal px-4 py-2 flex justify-between items-center">
        <div className="text-sm">9:41</div>
        <div className="flex items-center space-x-1">
          <i className="ri-signal-wifi-line"></i>
          <i className="ri-battery-line"></i>
        </div>
      </div>
      
      {/* Onboarding Content */}
      <motion.div 
        className="flex-1 flex flex-col items-center justify-between p-6 gradient-bg"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Logo and Illustration Area */}
        <div className="w-full flex-1 flex flex-col items-center justify-center relative">
          {/* Decorative stars */}
          <motion.div 
            className="absolute top-4 left-4 text-poshGold"
            variants={itemVariants}
          >
            <i className="ri-star-line text-xl"></i>
          </motion.div>
          <motion.div 
            className="absolute bottom-20 right-10 text-poshGold"
            variants={itemVariants}
          >
            <i className="ri-star-line text-xl"></i>
          </motion.div>
          
          {/* Card Illustration */}
          <motion.div 
            className="relative mb-8"
            variants={itemVariants}
          >
            {/* A minimalist cryptocurrency card with gold accents */}
            <div className="card w-64 h-40 bg-darkCharcoal rounded-xl transform rotate-12 relative overflow-hidden">
              <div className="absolute top-4 left-4">
                <i className="ri-copper-coin-line text-poshGold text-xl"></i>
              </div>
              <div className="absolute bottom-4 right-4 text-xs text-poshGold">
                Joodas
              </div>
              <div className="absolute bottom-4 left-4 text-xs opacity-70">
                XXXX XXXX XXXX 3456
              </div>
            </div>
            
            {/* Hand decoration */}
            <div className="absolute -bottom-10 -left-12 w-full h-full opacity-90">
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-softWhite/20 to-softWhite/5 absolute -bottom-10 -left-5"></div>
            </div>
          </motion.div>
          
          {/* Main Title */}
          <motion.h1 
            className="font-cinzel text-3xl font-bold text-center mb-3"
            variants={itemVariants}
          >
            Manage Your <br/>Finance
          </motion.h1>
          <motion.p 
            className="text-softWhite/80 text-center text-sm max-w-xs mb-8"
            variants={itemVariants}
          >
            Finance is the best solution to monitor all your financial activities
          </motion.p>
          
          {/* Get Started Button */}
          <motion.div 
            variants={itemVariants}
            className="w-full max-w-xs"
          >
            <Button 
              className="bg-darkCharcoal text-softWhite py-7 px-6 rounded-full w-full font-medium"
              onClick={handleGetStarted}
            >
              Get Started
            </Button>
          </motion.div>
        </div>
        
        {/* Bottom Pill */}
        <motion.div 
          className="w-10 h-1 bg-softWhite/30 rounded-full mt-6"
          variants={itemVariants}
        ></motion.div>
      </motion.div>
      
      <ConnectWalletModal 
        open={showConnectModal} 
        onOpenChange={setShowConnectModal} 
      />
    </div>
  );
}
