import { useEffect } from 'react';
import { motion } from 'framer-motion';
import BottomNavbar from '@/components/layout/BottomNavbar';
import { SolanaWalletCard } from '@/components/wallet/SolanaWalletCard';

export default function Wallet() {
  useEffect(() => {
    // Set the page title
    document.title = 'Wallet Details | Joodas';
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm py-4 px-5 flex items-center justify-between">
        <div className="flex items-center">
          <a href="/" className="mr-3">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </a>
          <h1 className="text-xl font-semibold text-gray-800">Wallet Details</h1>
        </div>
        <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100">
          <i className="ri-more-2-fill text-gray-700"></i>
        </button>
      </div>
      
      <motion.div 
        className="flex-1 pb-4 px-4 max-w-2xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Solana Wallet Card */}
        <motion.div variants={itemVariants} className="mb-6 mt-4">
          <SolanaWalletCard />
        </motion.div>

        {/* Wallet Details - Will be populated from real wallet data */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="text-gray-800 font-medium mb-4 flex items-center">
            <i className="ri-information-line mr-2 text-poshGold"></i>
            Wallet Information
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-md">
            <div className="space-y-4">
              <div className="border-b border-gray-100 pb-4">
                <div className="text-xs text-gray-500 mb-1">Network</div>
                <div className="text-sm font-medium text-gray-700 flex items-center">
                  <div className="w-4 h-4 mr-2 text-blue-500">
                    <i className="ri-globe-line"></i>
                  </div>
                  Solana {process.env.NODE_ENV === 'production' ? 'Mainnet' : 'Devnet'}
                </div>
              </div>
              
              <div className="border-b border-gray-100 pb-4">
                <div className="text-xs text-gray-500 mb-1">Security</div>
                <div className="text-sm font-medium text-emerald-600 flex items-center">
                  <div className="w-4 h-4 mr-2 text-emerald-500">
                    <i className="ri-shield-check-line"></i>
                  </div>
                  Non-custodial with private key generation
                </div>
              </div>
              
              <div className="border-b border-gray-100 pb-4">
                <div className="text-xs text-gray-500 mb-1">Blockchain Explorer</div>
                <a 
                  href={`https://explorer.solana.com/?cluster=${process.env.NODE_ENV === 'production' ? 'mainnet-beta' : 'devnet'}`} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-medium text-blue-500 flex items-center hover:text-blue-600"
                >
                  <div className="w-4 h-4 mr-2">
                    <i className="ri-external-link-line"></i>
                  </div>
                  View on Solana Explorer
                </a>
              </div>
              
              <div>
                <div className="text-xs text-gray-500 mb-1">Integration</div>
                <div className="text-sm font-medium text-gray-700 flex items-center">
                  <div className="w-4 h-4 mr-2 text-purple-500">
                    <i className="ri-link"></i>
                  </div>
                  Connected with Jupiter
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Emotional Health */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="text-gray-800 font-medium mb-4">Emotional Health</div>
          <div className="bg-white rounded-2xl p-5 shadow-md">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full flex items-center justify-center mr-3 bg-emerald-500/10">
                  <i className="ri-emotion-normal-line text-lg text-emerald-500"></i>
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-800">Stable (78%)</div>
                  <div className="text-xs text-gray-500">Excellent emotional control</div>
                </div>
              </div>
              <button className="text-xs text-blue-500">History</button>
            </div>
            
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <div className="text-gray-500">Panic Resistance</div>
                  <div className="text-gray-700 font-medium">82%</div>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{width: "82%"}}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <div className="text-gray-500">FOMO Control</div>
                  <div className="text-gray-700 font-medium">65%</div>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400" style={{width: "65%"}}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <div className="text-gray-500">Holding Patience</div>
                  <div className="text-gray-700 font-medium">94%</div>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{width: "94%"}}></div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Quick Actions */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="text-gray-800 font-medium mb-4">Quick Actions</div>
          <div className="grid grid-cols-2 gap-4">
            <a href="/buy-sol" className="bg-gradient-to-r from-poshGold to-amber-400 text-white rounded-xl py-4 px-4 flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-300 font-medium">
              <i className="ri-add-line mr-2"></i>
              Buy SOL
            </a>
            <a href="/swap-sol" className="bg-blue-500 text-white rounded-xl py-4 px-4 flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-300 font-medium">
              <i className="ri-exchange-line mr-2"></i>
              Swap
            </a>
          </div>
        </motion.div>
      </motion.div>
      
      {/* Bottom Navigation */}
      <BottomNavbar activePage="wallet" />
    </div>
  );
}