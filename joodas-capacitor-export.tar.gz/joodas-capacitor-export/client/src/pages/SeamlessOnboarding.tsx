import React, { useEffect, useState } from 'react';
import { redirectToLogin, redirectToLogout } from '../hooks/useAuth';
import { useLocation } from 'wouter';
import joodasLogo from '../assets/images/joodas-logo.png';
import { useToast } from '../hooks/use-toast';
import { Button } from '@/components/ui/button';

export default function SeamlessOnboarding() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [userWasLoggedIn, setUserWasLoggedIn] = useState(false);
  
  // Check if user was already logged in when they landed on this page
  useEffect(() => {
    if (localStorage.getItem('hasLoggedIn')) {
      setUserWasLoggedIn(true);
    }
  }, []);
  
  // Handle auth status from query params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const authStatus = urlParams.get('auth');
    
    if (authStatus === 'success') {
      localStorage.setItem('hasLoggedIn', 'true');
      
      // Fetch user data from API
      fetch('/api/auth/user')
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to fetch user data');
          }
          return response.json();
        })
        .then(userData => {
          // Store user data in localStorage for quick access
          if (userData) {
            // Store main user details
            if (userData.firstName) localStorage.setItem('userFirstName', userData.firstName);
            if (userData.lastName) localStorage.setItem('userLastName', userData.lastName);
            if (userData.email) localStorage.setItem('userEmail', userData.email);
            if (userData.profileImageUrl) localStorage.setItem('userProfileImage', userData.profileImageUrl);
            
            // Store user ID for wallet generation
            if (userData.id) localStorage.setItem('userId', userData.id);
            
            // If there's any persistent wallet data, store it too
            if (userData.walletAddress) localStorage.setItem('userWalletAddress', userData.walletAddress);
            
            // Set a flag to trigger wallet check on the next page
            localStorage.setItem('checkWalletOnLoad', 'true');
          }
          
          // Regular welcome back toast
          toast({
            title: "Degen Onboarding Complete",
            description: userData.firstName 
              ? `Welcome back, ${userData.firstName}!` 
              : "Your crypto journey awaits!",
          });
          
          // Clear the URL parameter before navigating
          window.history.replaceState({}, document.title, window.location.pathname);
          navigate('/');
        })
        .catch(error => {
          console.error('Error fetching user data:', error);
          // Still allow login even if profile fetch fails
          localStorage.setItem('hasLoggedIn', 'true');
          
          toast({
            title: "Degen Onboarding Complete",
            description: "Your crypto journey awaits!",
          });
          
          // Clear the URL parameter before navigating
          window.history.replaceState({}, document.title, window.location.pathname);
          navigate('/');
        });
    } else if (authStatus === 'failed') {
      setError('Authentication failed. Please try again.');
      
      toast({
        title: "Onboarding Failed",
        description: "Please try again or continue as guest",
        variant: "destructive",
      });
    } else if (authStatus === 'logout') {
      // Clear all user data
      localStorage.removeItem('hasLoggedIn');
      localStorage.removeItem('userFirstName');
      localStorage.removeItem('userLastName');
      localStorage.removeItem('userEmail');
      localStorage.removeItem('userProfileImage');
      localStorage.removeItem('userWalletAddress');
      
      setError('You have been logged out.');
      
      toast({
        title: "Logged Out",
        description: "Return to Joodas when you're ready to continue your crypto journey.",
      });
    }
  }, [navigate, toast]);
  
  const handleLogin = () => {
    setIsLoggingIn(true);
    redirectToLogin();
  };
  
  const handleLogout = () => {
    setIsLoggingOut(true);
    redirectToLogout();
  };
  
  const handleContinueAsGuest = () => {
    // Store a flag that user is a guest
    localStorage.setItem('isGuestUser', 'true');
    
    // Generate a unique guest ID for the session
    const guestId = `guest_${Date.now().toString(36)}_${Math.random().toString(36).substr(2, 5)}`;
    localStorage.setItem('userId', guestId);
    
    toast({
      title: "Guest Mode Activated",
      description: "Explore Joodas with limited features. Sign up anytime!",
    });
    
    navigate('/');
  };
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-white via-gray-50 to-gray-100">
      {/* Premium gold accent decorative elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-poshGold to-transparent opacity-70"></div>
      <div className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-r from-poshGold via-transparent to-poshGold opacity-70"></div>
      
      <div className="w-full max-w-md mx-auto relative">
        {/* Subtle gold corner accent */}
        <div className="absolute -top-2 -left-2 w-16 h-16 border-t-2 border-l-2 border-poshGold rounded-tl-lg"></div>
        <div className="absolute -bottom-2 -right-2 w-16 h-16 border-b-2 border-r-2 border-poshGold rounded-br-lg"></div>
        
        <div className="text-center mb-8 relative">
          <img src={joodasLogo} alt="Joodas Logo" className="h-24 mx-auto mb-2 drop-shadow-lg" />
          <div className="relative inline-block">
            <h1 className="text-3xl font-bold text-gray-800 mb-1">Seamless Degen Onboarding</h1>
            <div className="h-1 w-24 bg-poshGold mx-auto mt-2 rounded-full"></div>
          </div>
          <p className="text-gray-600 mt-3">Your gateway to premium crypto finance</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-2xl border border-gray-100 p-8 mb-8 relative overflow-hidden">
          {/* Subtle gold corner accent inside the card */}
          <div className="absolute top-0 right-0 w-20 h-20 bg-poshGold/5 rounded-bl-full"></div>
          
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-md">
              <p className="text-red-800">{error}</p>
            </div>
          )}
          
          {userWasLoggedIn ? (
            <div className="text-center">
              <p className="text-lg font-medium text-gray-700 mb-6">You're already onboarded!</p>
              <div className="space-y-4">
                <Button 
                  onClick={() => navigate('/')} 
                  className="w-full bg-poshGold hover:bg-poshGold/90 text-white shadow-lg shadow-poshGold/20 h-12 text-base"
                >
                  Return to Dashboard
                </Button>
                <Button 
                  onClick={handleLogout} 
                  variant="outline" 
                  className="w-full border-gray-300 hover:border-poshGold hover:text-poshGold transition-all h-12 text-base"
                  disabled={isLoggingOut}
                >
                  {isLoggingOut ? 'Logging out...' : 'Log Out'}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-7">
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Continue with your Joodas journey</h2>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Enjoy a seamless crypto experience with automatic wallet creation, personalized insights, and premium financial tools.
                </p>
              </div>
              
              <div className="space-y-4">
                <Button 
                  onClick={handleLogin} 
                  className="w-full bg-poshGold hover:bg-poshGold/90 shadow-lg shadow-poshGold/20 h-12 text-base flex items-center justify-center gap-2 group transition-all"
                  disabled={isLoggingIn}
                >
                  {isLoggingIn ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Connecting...</span>
                    </>
                  ) : (
                    <>
                      <span>Complete Degen Onboarding</span>
                      <span className="group-hover:translate-x-1 transition-transform">→</span>
                    </>
                  )}
                </Button>
                
                <div className="relative flex items-center py-3">
                  <div className="flex-grow border-t border-gray-200"></div>
                  <span className="flex-shrink mx-4 text-gray-400 text-sm">or</span>
                  <div className="flex-grow border-t border-gray-200"></div>
                </div>
                
                <Button 
                  onClick={handleContinueAsGuest} 
                  variant="outline" 
                  className="w-full border-gray-300 hover:border-poshGold hover:text-poshGold transition-all h-12 text-base"
                >
                  Continue as Guest
                </Button>
              </div>
            </div>
          )}
        </div>
        
        <div className="text-center text-sm text-gray-500 px-4">
          <p>By onboarding, you agree to our Terms of Service and Privacy Policy.</p>
          <div className="flex items-center justify-center mt-3 text-poshGold/90 gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            <p>Your personal Solana wallet will be automatically created upon login.</p>
          </div>
        </div>
      </div>
    </div>
  );
}