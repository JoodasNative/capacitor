import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { useTestWallet } from '@/hooks/use-test-wallet';
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";

export default function WalletSetup() {
  const [userId, setUserId] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [creationResponse, setCreationResponse] = useState<any>(null);
  const [, navigate] = useLocation();
  
  const { 
    wallets, 
    isLoading, 
    refetch, 
    createTestWallet, 
    isCreating 
  } = useTestWallet(userId);
  
  useEffect(() => {
    // Set the page title
    document.title = 'Wallet Setup | Joodas';
    
    // Try to load the user ID from localStorage
    const storedUserId = localStorage.getItem('userId');
    if (storedUserId) {
      setUserId(storedUserId);
    }
    
    // Check for existing wallet address
    const storedWalletAddress = localStorage.getItem('userWalletAddress');
    if (storedWalletAddress) {
      setWalletAddress(storedWalletAddress);
    }
  }, []);
  
  const handleCreateWallet = async () => {
    try {
      if (!userId) {
        // Generate a temporary guest ID
        const guestId = `guest_${Date.now().toString(36)}_${Math.random().toString(36).substr(2, 5)}`;
        localStorage.setItem('userId', guestId);
        setUserId(guestId);
        
        // Call with new guest ID
        createTestWallet(guestId);
      } else {
        // Call with existing ID
        createTestWallet(userId);
      }
      
      // Wait for the API response and set it for display
      fetch('/api/wallets', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': userId || localStorage.getItem('userId') || '',
        }
      })
        .then(response => response.json())
        .then(data => {
          if (Array.isArray(data) && data.length > 0) {
            const wallet = data[0];
            setCreationResponse({
              message: "Wallet created successfully",
              wallet: wallet
            });
            
            // Also update the wallet address
            if (wallet.address) {
              setWalletAddress(wallet.address);
              localStorage.setItem('userWalletAddress', wallet.address);
            }
          }
        })
        .catch(err => {
          console.warn('Could not fetch wallet data:', err);
        });
    } catch (error) {
      console.error('Error handling wallet creation:', error);
      
      toast({
        title: "Error Creating Wallet",
        description: "There was a problem with wallet creation",
        variant: "destructive",
      });
    }
  };
  
  const goToPreview = () => {
    navigate('/wallet-preview');
  };
  
  const goToOnboarding = () => {
    navigate('/onboarding');
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-gray-50 to-gray-100 p-6 flex flex-col items-center">
      {/* Premium gold accent decorative elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-poshGold to-transparent opacity-70"></div>
      <div className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-r from-poshGold via-transparent to-poshGold opacity-70"></div>
      
      <div className="w-full max-w-2xl mx-auto mt-8 relative">
        {/* Subtle gold corner accent */}
        <div className="absolute -top-2 -left-2 w-16 h-16 border-t-2 border-l-2 border-poshGold rounded-tl-lg"></div>
        <div className="absolute -bottom-2 -right-2 w-16 h-16 border-b-2 border-r-2 border-poshGold rounded-br-lg"></div>
        
        <div className="text-center mb-8 relative">
          <div className="relative inline-block">
            <h1 className="text-3xl font-bold text-gray-800 mb-1">Joodas Wallet Setup</h1>
            <div className="h-1 w-24 bg-poshGold mx-auto mt-2 rounded-full"></div>
          </div>
          <p className="text-gray-600 mt-3">Create your personal Solana wallet and begin your crypto journey</p>
        </div>
        
        <Card className="mb-8 shadow-2xl border-gray-100 rounded-xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-poshGold/20 to-white border-b border-poshGold/10 relative">
            <div className="absolute top-0 right-0 w-20 h-20 bg-poshGold/5 rounded-bl-full"></div>
            <CardTitle className="text-xl font-semibold">Create Your Solana Wallet</CardTitle>
            <CardDescription className="text-gray-600">
              Get started with a personal Solana wallet in one click. No complicated seed phrases or backups needed - we handle the security for you.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-6 px-6">
            <div className="space-y-4">
              {walletAddress ? (
                <div className="p-6 bg-gradient-to-r from-green-50 to-green-50/50 rounded-xl border border-green-100 shadow-inner relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 rounded-bl-full bg-green-100/50"></div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                    </div>
                    <h3 className="font-medium text-green-800 text-lg">Wallet Created Successfully!</h3>
                  </div>
                  <p className="text-green-700 mb-4">Your personal Solana wallet is ready to use. This address is where you'll receive funds.</p>
                  <div className="bg-white p-4 rounded-lg border border-green-100 font-mono text-sm break-all shadow-sm relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent shimmer-effect"></div>
                    {walletAddress}
                    <button 
                      className="absolute right-2 top-2 p-2 text-gray-500 hover:text-poshGold" 
                      onClick={() => {
                        navigator.clipboard.writeText(walletAddress);
                        toast({
                          title: "Address Copied",
                          description: "Wallet address copied to clipboard",
                        });
                      }}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                      </svg>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-6 bg-gradient-to-r from-blue-50 to-blue-50/50 rounded-xl border border-blue-100 shadow-inner relative">
                  <div className="absolute top-0 right-0 w-16 h-16 rounded-bl-full bg-blue-100/50"></div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-700">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="2" y="6" width="20" height="12" rx="2"></rect>
                        <path d="M12 12h.01"></path>
                        <path d="M2 12h4"></path>
                        <path d="M18 12h4"></path>
                      </svg>
                    </div>
                    <h3 className="font-medium text-blue-800 text-lg">Ready to Begin</h3>
                  </div>
                  <p className="text-blue-700">
                    Create your Joodas wallet to start trading, storing, and earning rewards on the Solana blockchain. Your non-custodial wallet is created and managed securely without exposing your private keys.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
          
          <CardFooter className="flex flex-col sm:flex-row gap-4 border-t border-gray-100 bg-gray-50/50 p-6">
            {walletAddress ? (
              <Button 
                className="w-full sm:w-auto bg-poshGold hover:bg-poshGold/90 text-white shadow-lg shadow-poshGold/20 h-12 text-base flex items-center justify-center gap-2 group transition-all" 
                onClick={goToPreview}
              >
                <span>View Wallet Dashboard</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </Button>
            ) : (
              <Button 
                className="w-full sm:w-auto bg-poshGold hover:bg-poshGold/90 text-white shadow-lg shadow-poshGold/20 h-12 text-base flex items-center justify-center gap-2 group transition-all" 
                onClick={handleCreateWallet}
                disabled={isCreating}
              >
                {isCreating ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Creating Wallet...</span>
                  </>
                ) : (
                  <>
                    <span>Create My Wallet</span>
                    <span className="group-hover:translate-x-1 transition-transform">→</span>
                  </>
                )}
              </Button>
            )}
            
            <Button 
              variant="outline" 
              className="w-full sm:w-auto border-gray-300 hover:border-poshGold hover:text-poshGold transition-all h-12 text-base"
              onClick={goToOnboarding}
            >
              Complete Degen Onboarding
            </Button>
          </CardFooter>
        </Card>
        
        <div className="text-center text-gray-500 text-sm px-4">
          <p>For the best experience, complete Seamless Degen Onboarding to unlock all features.</p>
          <div className="flex items-center justify-center mt-3 text-poshGold/90 gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M12 8v4"></path>
              <path d="M12 16h.01"></path>
            </svg>
            <p>Your wallet on Joodas is always non-custodial and secure.</p>
          </div>
        </div>
      </div>
    </div>
  );
}