import { useEffect } from 'react';
import { motion } from 'framer-motion';
import BottomNavbar from '@/components/layout/BottomNavbar';

export default function FinancialKarma() {
  useEffect(() => {
    // Set the page title
    document.title = 'Financial Karma | Joodas';
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm py-4 px-5 flex items-center justify-between">
        <div className="flex items-center">
          <a href="/" className="mr-3">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </a>
          <h1 className="text-xl font-semibold text-gray-800">Financial Karma</h1>
        </div>
        <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100">
          <i className="ri-information-line text-gray-700"></i>
        </button>
      </div>
      
      <motion.div 
        className="flex-1 pb-4 px-4 max-w-2xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Karma Score Card */}
        <motion.div variants={itemVariants} className="mb-6 mt-4">
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/40">
            <div className="flex flex-col items-center mb-5">
              <div className="w-24 h-24 bg-gradient-to-br from-poshGold/20 to-amber-400/20 rounded-full flex items-center justify-center shadow-xl shimmer-effect relative mb-3">
                <span className="text-4xl font-bold text-poshGold">78</span>
              </div>
              <div className="text-xl font-semibold text-gray-800">Diamond Hands</div>
              <div className="text-sm text-gray-500">Level 5 Financial Health</div>
            </div>
            
            <div className="flex justify-center gap-4 mb-6">
              <div className="text-center">
                <div className="text-sm font-medium text-gray-700">14</div>
                <div className="text-xs text-gray-500">Days HODL</div>
              </div>
              <div className="h-10 w-px bg-gray-200"></div>
              <div className="text-center">
                <div className="text-sm font-medium text-gray-700">+12%</div>
                <div className="text-xs text-gray-500">Profit</div>
              </div>
              <div className="h-10 w-px bg-gray-200"></div>
              <div className="text-center">
                <div className="text-sm font-medium text-emerald-500">78%</div>
                <div className="text-xs text-gray-500">Emotional Health</div>
              </div>
            </div>
            
            <div className="flex items-center mb-2">
              <div className="text-xs text-gray-500 w-24">Next Level:</div>
              <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden ml-2">
                <div className="h-full bg-poshGold" style={{width: "65%"}}></div>
              </div>
              <div className="text-xs text-gray-600 ml-2 font-medium">35 XP left</div>
            </div>
          </div>
        </motion.div>

        {/* Trading Metrics */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="text-gray-800 font-medium mb-4">Trading Metrics</div>
          <div className="bg-white rounded-2xl p-5 shadow-md">
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-1">
                  <div className="text-gray-700">Profit/Loss Ratio</div>
                  <div className="text-emerald-500 font-medium">2.4 : 1</div>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{width: "70%"}}></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">You win more than you lose. Great job!</div>
              </div>
              
              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <div className="text-gray-700">Holding Patience</div>
                  <div className="text-emerald-500 font-medium">94%</div>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{width: "94%"}}></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">Diamond hands activated! Your patience is elite.</div>
              </div>
              
              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <div className="text-gray-700">Panic Resistance</div>
                  <div className="text-emerald-500 font-medium">82%</div>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{width: "82%"}}></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">You stay cool when the market dips. Strong mental game.</div>
              </div>
              
              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <div className="text-gray-700">FOMO Control</div>
                  <div className="text-amber-500 font-medium">65%</div>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400" style={{width: "65%"}}></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">You occasionally chase pumps. Work on your timing.</div>
              </div>
              
              <div className="border-t border-gray-100 pt-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <div className="text-gray-700">Risk Management</div>
                  <div className="text-amber-500 font-medium">58%</div>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400" style={{width: "58%"}}></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">Try diversifying positions and using stop losses.</div>
              </div>
            </div>
          </div>
        </motion.div>
        
        {/* Achievements */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="text-gray-800 font-medium mb-4">Achievements</div>
          <div className="bg-white rounded-2xl p-5 shadow-md">
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-poshGold/10 mr-4">
                  <i className="ri-award-fill text-xl text-poshGold"></i>
                </div>
                <div className="flex-1">
                  <div className="text-gray-800 font-medium mb-0.5">Diamond Hands</div>
                  <div className="text-xs text-gray-500">HODL your SOL for 14 days straight</div>
                </div>
                <div className="flex items-center justify-center rounded-full w-8 h-8 bg-emerald-100">
                  <i className="ri-check-line text-emerald-500"></i>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-100 mr-4">
                  <i className="ri-funds-line text-xl text-emerald-500"></i>
                </div>
                <div className="flex-1">
                  <div className="text-gray-800 font-medium mb-0.5">Profit Pioneer</div>
                  <div className="text-xs text-gray-500">Achieve 10% profit on a single trade</div>
                </div>
                <div className="flex items-center justify-center rounded-full w-8 h-8 bg-emerald-100">
                  <i className="ri-check-line text-emerald-500"></i>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-amber-100 mr-4">
                  <i className="ri-psychotherapy-line text-xl text-amber-500"></i>
                </div>
                <div className="flex-1">
                  <div className="text-gray-800 font-medium mb-0.5">Patience Master</div>
                  <div className="text-xs text-gray-500">HODL through a 20% market dip</div>
                </div>
                <div className="flex items-center rounded-full px-3 py-0.5 bg-amber-100 h-6">
                  <span className="text-xs text-amber-700">7 days left</span>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gray-100 mr-4">
                  <i className="ri-rocket-line text-xl text-gray-400"></i>
                </div>
                <div className="flex-1">
                  <div className="text-gray-800 font-medium mb-0.5">Whale Status</div>
                  <div className="text-xs text-gray-500">Hold 100+ SOL in your wallet</div>
                </div>
                <div className="flex items-center rounded-full px-3 py-0.5 bg-gray-100 h-6">
                  <span className="text-xs text-gray-500">Locked</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
      
      {/* Bottom Navigation */}
      <BottomNavbar activePage="stats" />
    </div>
  );
}