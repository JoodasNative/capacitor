import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import BottomNavbar from "@/components/layout/BottomNavbar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const paymentMethods = [
  {
    id: "card",
    name: "Credit/Debit Card",
    icon: "ri-bank-card-fill",
    color: "bg-white",
    textColor: "text-gray-800"
  },
  {
    id: "google-pay",
    name: "Google Pay",
    icon: "ri-google-fill",
    color: "bg-white",
    textColor: "text-gray-800"
  },
  {
    id: "apple-pay",
    name: "Apple Pay",
    icon: "ri-apple-fill",
    color: "bg-white",
    textColor: "text-gray-800"
  },
  {
    id: "bank",
    name: "Bank Transfer",
    icon: "ri-bank-fill",
    color: "bg-white",
    textColor: "text-gray-800"
  }
];

export default function BuySol() {
  const { toast } = useToast();
  const [amount, setAmount] = useState("100");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(paymentMethods[0].id);
  const [isBuying, setIsBuying] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    cardName: '',
    expiry: '',
    cvc: ''
  });

  const solPrice = 143.78; // Mock SOL price in USD
  const solAmount = parseFloat(amount) / solPrice;
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 20
      }
    }
  };

  const handleCardInput = (field: string, value: string) => {
    setCardDetails(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Format card number with spaces for better readability
  const formatCardNumber = (value: string) => {
    return value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
  };

  // Format expiry date as MM/YY
  const formatExpiry = (value: string) => {
    value = value.replace(/\D/g, '');
    if (value.length > 2) {
      return value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    return value;
  };

  const handleBuy = () => {
    setIsBuying(true);
    
    // Validate card details if credit card is selected
    if (selectedPaymentMethod === "card") {
      if (!cardDetails.cardNumber || !cardDetails.cardName || !cardDetails.expiry || !cardDetails.cvc) {
        toast({
          title: "Missing information",
          description: "Please fill in all card details",
          variant: "destructive"
        });
        setIsBuying(false);
        return;
      }
    }
    
    // Simulate API call
    setTimeout(() => {
      setIsBuying(false);
      
      // Show success message
      toast({
        title: "Purchase successful!",
        description: `You have purchased ${solAmount.toFixed(5)} SOL for $${parseFloat(amount).toFixed(2)}`,
        variant: "default"
      });
    }, 2000);
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground pb-20">
      <div className="bg-background px-4 py-3 flex justify-between items-center border-b border-gray-100">
        <button onClick={() => window.history.back()} className="text-gray-700">
          <i className="ri-arrow-left-s-line text-lg"></i>
        </button>
        <div className="text-lg font-semibold text-gray-800">Buy SOL</div>
        <div className="w-8"></div>
      </div>
      
      <motion.div 
        className="flex-1 px-5 pt-4 pb-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <motion.div variants={itemVariants} className="mb-4">
            <div className="text-gray-700 text-sm mb-2">Enter amount (USD)</div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-gray-500 text-lg">$</span>
              </div>
              <input
                type="text"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ''))}
                className="bg-white w-full pl-10 pr-4 py-4 rounded-xl shadow-md text-xl font-semibold text-gray-800 focus:outline-none focus:ring-2 focus:ring-poshGold/30"
              />
            </div>
            <div className="mt-2 text-xs text-gray-500 flex justify-between">
              <span>Min: $10.00</span>
              <span>Max: $10,000.00</span>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <div className="text-gray-700 text-sm">You'll receive</div>
              <div className="text-poshGold text-sm">Current price</div>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-md">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center mr-3">
                    <i className="ri-sun-fill text-white text-base"></i>
                  </div>
                  <div>
                    <div className="text-xl font-semibold text-gray-800">{solAmount.toFixed(5)} SOL</div>
                    <div className="text-xs text-gray-500 mt-0.5">Solana</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-gray-800 font-medium">${solPrice.toFixed(2)}</div>
                  <div className="text-xs text-emerald-500 flex items-center mt-0.5">
                    <i className="ri-arrow-up-line mr-1"></i>
                    2.4% today
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div variants={itemVariants} className="mb-5">
          <div className="text-gray-700 text-sm mb-2">Payment method</div>
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="grid grid-cols-2 gap-0">
              {paymentMethods.map((method) => (
                <div 
                  key={method.id}
                  onClick={() => setSelectedPaymentMethod(method.id)}
                  className={`flex items-center px-4 py-3 cursor-pointer transition-all duration-200 ${
                    selectedPaymentMethod === method.id 
                      ? 'bg-gray-50 border-l-2 border-poshGold' 
                      : 'border-l-2 border-transparent'
                  } ${method.id === "card" || method.id === "google-pay" ? 'border-b border-gray-100' : ''}`}
                >
                  <div className={`w-10 h-10 rounded-full ${method.color} flex items-center justify-center mr-3 shadow-sm`}>
                    <i className={`${method.icon} ${method.textColor} text-lg`}></i>
                  </div>
                  <div className="flex-1">
                    <div className="text-gray-800 font-medium">{method.name}</div>
                    <div className="text-xs text-gray-500 mt-0.5">Instant processing</div>
                  </div>
                  {selectedPaymentMethod === method.id && (
                    <div className="h-5 w-5 bg-poshGold rounded-full flex items-center justify-center">
                      <i className="ri-check-line text-white text-xs"></i>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Credit Card Form */}
          <AnimatePresence>
            {selectedPaymentMethod === "card" && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-4 overflow-hidden"
              >
                <div className="bg-white rounded-xl shadow-md p-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-gray-800 font-medium">Card Details</h3>
                    <div className="flex items-center space-x-2">
                      <i className="ri-visa-line text-blue-600 text-xl"></i>
                      <i className="ri-mastercard-line text-red-500 text-xl"></i>
                      <i className="ri-bank-card-line text-gray-400 text-xl"></i>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="card-number" className="text-xs text-gray-600 mb-1">Card Number</Label>
                      <div className="relative">
                        <Input
                          id="card-number"
                          type="text"
                          value={cardDetails.cardNumber}
                          onChange={(e) => handleCardInput('cardNumber', formatCardNumber(e.target.value))}
                          placeholder="4242 4242 4242 4242"
                          maxLength={19}
                          className="pl-11 py-5"
                        />
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                          <i className="ri-bank-card-line text-gray-400"></i>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="card-name" className="text-xs text-gray-600 mb-1">Cardholder Name</Label>
                      <Input
                        id="card-name"
                        type="text"
                        value={cardDetails.cardName}
                        onChange={(e) => handleCardInput('cardName', e.target.value)}
                        placeholder="John Doe"
                        className="py-5"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiry" className="text-xs text-gray-600 mb-1">Expiry Date</Label>
                        <div className="relative">
                          <Input
                            id="expiry"
                            type="text"
                            value={cardDetails.expiry}
                            onChange={(e) => handleCardInput('expiry', formatExpiry(e.target.value))}
                            placeholder="MM/YY"
                            maxLength={5}
                            className="pl-11 py-5"
                          />
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                            <i className="ri-calendar-line text-gray-400"></i>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="cvc" className="text-xs text-gray-600 mb-1">CVC</Label>
                        <div className="relative">
                          <Input
                            id="cvc"
                            type="text"
                            value={cardDetails.cvc}
                            onChange={(e) => handleCardInput('cvc', e.target.value.replace(/\D/g, ''))}
                            placeholder="123"
                            maxLength={3}
                            className="pl-11 py-5"
                          />
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                            <i className="ri-lock-line text-gray-400"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <motion.div variants={itemVariants} className="mb-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between items-center py-2 text-sm">
                <div className="text-gray-700">Network fee</div>
                <div className="text-gray-800 font-medium">$2.50</div>
              </div>
              <div className="flex justify-between items-center py-2 text-sm">
                <div className="text-gray-700">Processing fee</div>
                <div className="text-gray-800 font-medium">$1.25</div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center py-4 px-4 text-base bg-white rounded-xl shadow-md">
                <div className="text-gray-800 font-semibold">Total</div>
                <div className="text-gray-800 font-semibold">${(parseFloat(amount) + 3.75).toFixed(2)}</div>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <button 
            onClick={handleBuy}
            disabled={isBuying || amount === '' || parseFloat(amount) < 10}
            className="w-full py-4 bg-gradient-to-r from-poshGold to-amber-400 rounded-xl text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isBuying ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Processing...
              </div>
            ) : (
              <>Buy SOL Now</>
            )}
          </button>
          <div className="mt-3 text-center text-xs text-gray-500">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </div>
        </motion.div>
      </motion.div>
      
      <BottomNavbar activePage="trade" />
    </div>
  );
}