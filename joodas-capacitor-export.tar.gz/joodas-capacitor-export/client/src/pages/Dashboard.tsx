import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import joodasLogo from "../assets/joodas-logo.png";
import { FinancialKarmaCard } from "@/components/cards/FinancialKarmaCard";
import { DynamicNudgeCard } from "@/components/cards/DynamicNudgeCard";
import BottomNavbar from "@/components/layout/BottomNavbar";
import { useFirebaseAuth } from "@/context/FirebaseAuthContext";

export default function Dashboard() {
  const [activeTransactionTab, setActiveTransactionTab] = useState("Today");
  const [isPageLoaded, setIsPageLoaded] = useState(false);
  const { currentUser } = useFirebaseAuth();
  
  // Simulate page load effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsPageLoaded(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        when: "beforeChildren",
        delayChildren: 0.05,
        staggerChildren: 0.08
      }
    }
  };

  const itemVariants = {
    hidden: { y: 15, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 24
      }
    }
  };
  
  // Sample wallet data
  const wallets = [
    {
      id: 1,
      name: "Solana",
      iconSrc: "https://cryptologos.cc/logos/solana-sol-logo.png",
      balance: 24.82,
      value: 2507.46,
      address: "3GksJ...PQ79r",
      color: "from-blue-500 to-blue-400",
      textColor: "text-blue-500",
      change: "2.4%",
      changeType: "positive",
      hodlDays: 14,
      hodlStatus: "Diamond Hands",
      healthStatus: "Stable"
    },
    {
      id: 2,
      name: "Jupiter",
      iconSrc: "https://cryptologos.cc/logos/wrapped-bitcoin-wbtc-logo.png",
      balance: 412.8,
      value: 1840.26,
      address: "7XMp3...L1kQz",
      color: "from-poshGold to-amber-400",
      textColor: "text-poshGold",
      change: "1.2%",
      changeType: "positive",
      hodlDays: 7,
      hodlStatus: "Steady Holder",
      healthStatus: "Nervous"
    },
    {
      id: 3,
      name: "USDC",
      iconSrc: "https://cryptologos.cc/logos/usd-coin-usdc-logo.png",
      balance: 1254.32,
      value: 1254.32,
      address: "4pRN7...8nH2j",
      color: "from-blue-600 to-blue-500",
      textColor: "text-blue-600",
      change: "0.0%",
      changeType: "positive",
      hodlDays: 21,
      hodlStatus: "Safe Haven",
      healthStatus: "Stable"
    }
  ];

  // Sample transaction data
  const transactions = [
    {
      id: 1,
      title: "SOL Staking",
      time: "Sat 23 January • 1:03 PM",
      type: "buy",
      amount: "2.5 SOL",
      iconType: "ri-exchange-dollar-fill"
    },
    {
      id: 2,
      title: "SOL/USDC Swap",
      time: "Fri 22 January • 11:28 AM",
      type: "swap",
      amount: "1.2 SOL",
      iconType: "ri-repeat-line"
    },
    {
      id: 3,
      title: "SOL HODL Streak",
      time: "Thu 21 January • 9:15 AM",
      type: "hold",
      amount: "4.9 SOL",
      iconType: "ri-time-line",
      holdDays: 14
    }
  ];
  
  // Calculate total balance from all wallets
  const getTotalBalance = () => {
    return wallets.reduce((total, wallet) => total + wallet.value, 0);
  };

  // Sample contacts (matching the screenshot)
  const contacts = [
    { id: 1, name: "Add", icon: "ri-add-line", isAdd: true },
    { id: 2, name: "Lenardo", img: "https://randomuser.me/api/portraits/men/32.jpg" },
    { id: 3, name: "Alberta", img: "https://randomuser.me/api/portraits/women/44.jpg" },
    { id: 4, name: "Victoria", img: "https://randomuser.me/api/portraits/women/68.jpg" }
  ];

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground pb-24">
      {/* Status Bar */}
      <div className="px-5 py-2 flex justify-between items-center bg-background z-10">
        <div className="text-sm font-medium">9:41</div>
        <div className="flex items-center space-x-2">
          <i className="ri-signal-wifi-fill"></i>
          <i className="ri-battery-fill"></i>
        </div>
      </div>
      
      {/* Top Navigation */}
      <div className="px-5 py-4 flex justify-between items-center sticky top-0 bg-background/95 backdrop-blur-sm z-10 shadow-sm">
        <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors duration-200">
          <i className="ri-menu-line text-lg text-gray-700"></i>
        </button>
        
        <div className="flex items-center">
          <img src={joodasLogo} alt="Joodas Logo" className="h-8" />
        </div>
        
        <div className="flex items-center space-x-2">
          <a href="/buy-sol" className="bg-gradient-to-r from-poshGold to-amber-400 text-white rounded-full text-xs px-3 py-1.5 flex items-center shadow-md hover:shadow-lg transition-all duration-300">
            <i className="ri-add-line mr-1"></i>
            <span className="font-medium">Buy SOL</span>
          </a>
          <div className="w-10 h-10 rounded-full overflow-hidden shadow-md border-2 border-white">
            {currentUser?.photoURL ? (
              <img 
                src={currentUser.photoURL} 
                alt="Profile" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-poshGold to-amber-400 flex items-center justify-center text-white font-medium">
                {currentUser?.email ? currentUser.email[0].toUpperCase() : 'A'}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <motion.div 
        className="flex-1 pb-4 px-4 max-w-2xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Core Wallet and Balance Section */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100/40">
            {/* Balance Header */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-gray-500 text-sm font-medium">Total Balance</div>
                <div className="text-3xl font-bold text-gray-800 mt-1">${getTotalBalance().toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
              </div>
              <div className="text-sm font-medium px-3 py-1.5 rounded-full flex items-center bg-emerald-100/80 text-emerald-600">
                <i className="ri-arrow-up-line mr-1"></i>
                2.4%
              </div>
            </div>
            
            {/* Wallet Summary */}
            <div className="flex items-center mb-5 py-3 border-y border-gray-100">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-blue-500 to-blue-400 mr-3 shadow-md p-2.5 shimmer-effect">
                <i className="ri-wallet-3-line text-white text-2xl"></i>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-gray-800">24.82 SOL</div>
                    <div className="flex items-center mt-0.5">
                      <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 mr-1.5"></div>
                      <div className="text-xs text-gray-500">Diamond Hands • 14 days</div>
                    </div>
                  </div>
                  <a href="/wallet" className="text-xs text-blue-500 flex items-center">
                    Details
                    <i className="ri-arrow-right-s-line"></i>
                  </a>
                </div>
              </div>
            </div>
            
            {/* Quick Actions */}
            <div className="flex gap-3">
              <a href="/buy-sol" className="flex-1 bg-gradient-to-r from-poshGold to-amber-400 text-white rounded-xl py-3 px-4 flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-300 font-medium">
                <i className="ri-add-line mr-2"></i>
                Buy SOL
              </a>
              <a href="/swap-sol" className="flex-1 bg-blue-500 text-white rounded-xl py-3 px-4 flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-300 font-medium">
                <i className="ri-exchange-line mr-2"></i>
                Swap
              </a>
            </div>
          </div>
        </motion.div>
        
        {/* Condensed Financial Karma */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-gray-800 font-medium">Financial Karma</div>
            <a href="/karma" className="flex items-center space-x-1 text-poshGold text-xs cursor-pointer">
              <span>View Details</span>
              <i className="ri-arrow-right-s-line"></i>
            </a>
          </div>
          
          <div className="bg-white rounded-2xl p-5 shadow-md hover:shadow-lg transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-14 h-14 bg-gradient-to-br from-poshGold/10 to-amber-400/10 rounded-full flex items-center justify-center shadow-lg shimmer-effect relative mr-4">
                  <span className="text-2xl font-bold text-poshGold">78</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-700">Diamond Hands</div>
                  <div className="text-xs text-gray-500">14 day HODL streak</div>
                </div>
              </div>
              <div className="bg-amber-50 py-1 px-3 rounded-lg">
                <div className="text-xs text-amber-700 font-medium flex items-center">
                  <i className="ri-fire-line mr-1 text-amber-500"></i>
                  +4 points/day
                </div>
              </div>
            </div>
            
            <div className="flex items-center mb-2">
              <div className="text-xs text-gray-500 w-24">Next Achievement:</div>
              <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden ml-2">
                <div className="h-full bg-poshGold" style={{width: "65%"}}></div>
              </div>
              <div className="text-xs text-gray-600 ml-2 font-medium">7 days left</div>
            </div>
            
            <div className="text-xs text-gray-600 italic">
              "Continue your streak to unlock the Patience Master achievement!"
            </div>
          </div>
        </motion.div>
        
        {/* One Trading Insight */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-gray-800 font-medium">Trading Insight</div>
            <a href="/insights" className="flex items-center space-x-1 text-poshGold text-xs cursor-pointer">
              <span>View All</span>
              <i className="ri-arrow-right-s-line"></i>
            </a>
          </div>
          
          <div className="bg-white rounded-2xl p-5 shadow-md hover:shadow-lg transition-all duration-300">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center mr-3 bg-emerald-500/10">
                <i className="ri-line-chart-line text-emerald-500"></i>
              </div>
              <div className="text-sm font-semibold text-gray-800">Trade Opportunity</div>
            </div>
            
            <div className="text-base text-gray-700 mb-3">
              Last 5 times SOL dipped this low, it pumped 12% within 48 hours.
            </div>
            
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-emerald-100 text-emerald-700 text-xs rounded-full px-3 py-1">
                Likely Pump
              </div>
              <div className="bg-blue-100 text-blue-700 text-xs rounded-full px-3 py-1">
                Historical Pattern
              </div>
            </div>
            
            <button className="w-full bg-gradient-to-r from-poshGold to-amber-400 text-white text-sm rounded-lg py-2 font-medium shadow-sm hover:shadow-md transition-all duration-300">
              Take Action
            </button>
          </div>
        </motion.div>
        
        {/* Recent Transactions (Condensed) */}
        <motion.div variants={itemVariants} className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-gray-800 font-medium">Recent Transactions</div>
            <a href="/transactions" className="flex items-center space-x-1 text-poshGold text-xs cursor-pointer">
              <span>View All</span>
              <i className="ri-arrow-right-s-line"></i>
            </a>
          </div>
          
          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {/* Transaction Item 1 */}
            <div className="p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-100 to-emerald-50 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                    <i className="ri-exchange-dollar-fill text-lg text-emerald-600"></i>
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">SOL Staking</div>
                    <div className="text-xs text-gray-500">Sat 23 January • 1:03 PM</div>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-emerald-500 font-medium">+2.5 SOL</div>
                  <div className="text-xs text-gray-500">~$567.25</div>
                </div>
              </div>
            </div>
            
            {/* Transaction Item 2 */}
            <div className="p-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-blue-50 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                    <i className="ri-swap-line text-lg text-blue-600"></i>
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">SOL/USDC Swap</div>
                    <div className="text-xs text-gray-500">Fri 22 January • 2:15 PM</div>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-blue-500 font-medium">-1.2 SOL</div>
                  <div className="text-xs text-gray-500">~$189.75</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
      
      {/* Bottom Navigation with centered Trade button */}
      <BottomNavbar activePage="home" />
    </div>
  );
}