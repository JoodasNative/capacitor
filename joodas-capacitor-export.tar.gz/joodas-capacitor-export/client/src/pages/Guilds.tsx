import { useState } from "react";
import BottomNavbar from "@/components/layout/BottomNavbar";
import { GuildCard } from "@/components/guilds/GuildCard";
import { LeaderboardCard } from "@/components/guilds/LeaderboardCard";
import { CreateGuildModal } from "@/components/guilds/CreateGuildModal";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useGuilds } from "@/hooks/use-guilds";
import { useDegenScore } from "@/hooks/use-degen-score";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function Guilds() {
  const [showCreateGuild, setShowCreateGuild] = useState(false);
  const { guilds, userGuilds, isLoading } = useGuilds();
  const { userData } = useDegenScore();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        delayChildren: 0.1,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="relative min-h-screen flex flex-col pb-20">
      <div className="bg-background px-4 py-3 flex justify-between items-center border-b border-gray-100">
        <button onClick={() => window.history.back()} className="text-gray-700">
          <i className="ri-arrow-left-s-line text-lg"></i>
        </button>
        <div className="text-lg font-semibold text-gray-800">Guilds & Leaderboards</div>
        <div className="w-8"></div>
      </div>
      
      <motion.div 
        className="flex-1 overflow-y-auto pb-20"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Guild Header */}
        <motion.div 
          className="px-4 py-5 bg-gradient-to-b from-darkCharcoal to-transparent mb-2"
          variants={itemVariants}
        >
          <div className="flex justify-between items-center mb-3">
            <div>
              <h1 className="font-cinzel text-xl font-medium">Guilds</h1>
              <p className="text-xs text-softWhite/70">Join or create guilds for group savings and trading</p>
            </div>
            <Button 
              onClick={() => setShowCreateGuild(true)}
              className="bg-poshGold text-darkCharcoal hover:bg-poshGold/90"
            >
              <i className="ri-add-line mr-1"></i> Create
            </Button>
          </div>
        </motion.div>
        
        {/* Guild Tabs */}
        <motion.div className="px-4 mb-6" variants={itemVariants}>
          <Tabs defaultValue="my-guilds" className="w-full">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger 
                value="my-guilds" 
                className="data-[state=active]:bg-darkCharcoal data-[state=active]:text-poshGold text-softWhite/70 px-4 py-2 rounded-full text-sm"
              >
                My Guilds
              </TabsTrigger>
              <TabsTrigger 
                value="discover" 
                className="data-[state=active]:bg-darkCharcoal data-[state=active]:text-poshGold text-softWhite/70 px-4 py-2 rounded-full text-sm"
              >
                Discover
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="my-guilds" className="mt-0">
              {isLoading ? (
                Array(2).fill(0).map((_, index) => (
                  <div key={index} className="card p-4 mb-3 animate-pulse">
                    <div className="h-6 w-40 bg-mediumCharcoal rounded mb-2"></div>
                    <div className="h-4 w-24 bg-mediumCharcoal/60 rounded mb-4"></div>
                    <div className="flex justify-between">
                      <div className="h-5 w-20 bg-mediumCharcoal rounded"></div>
                      <div className="h-5 w-20 bg-mediumCharcoal rounded"></div>
                    </div>
                  </div>
                ))
              ) : userGuilds.length > 0 ? (
                userGuilds.map((guild, index) => (
                  <GuildCard key={guild.id} guild={guild} isMember={true} delay={index * 0.1} />
                ))
              ) : (
                <div className="card p-6 text-center">
                  <div className="text-poshGold text-3xl mb-2">
                    <i className="ri-team-line"></i>
                  </div>
                  <h3 className="font-cinzel text-lg mb-2">No Guilds Yet</h3>
                  <p className="text-softWhite/70 mb-4">Join a guild or create your own to start earning rewards</p>
                  <Button 
                    onClick={() => setShowCreateGuild(true)}
                    className="bg-poshGold/20 text-poshGold hover:bg-poshGold/30"
                  >
                    Create Your First Guild
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="discover" className="mt-0">
              {isLoading ? (
                Array(3).fill(0).map((_, index) => (
                  <div key={index} className="card p-4 mb-3 animate-pulse">
                    <div className="h-6 w-40 bg-mediumCharcoal rounded mb-2"></div>
                    <div className="h-4 w-24 bg-mediumCharcoal/60 rounded mb-4"></div>
                    <div className="flex justify-between">
                      <div className="h-5 w-20 bg-mediumCharcoal rounded"></div>
                      <div className="h-5 w-20 bg-mediumCharcoal rounded"></div>
                    </div>
                  </div>
                ))
              ) : guilds.length > 0 ? (
                guilds.map((guild, index) => {
                  const isMember = userGuilds.some(g => g.id === guild.id);
                  return (
                    <GuildCard 
                      key={guild.id} 
                      guild={guild} 
                      isMember={isMember}
                      delay={index * 0.1} 
                    />
                  );
                })
              ) : (
                <div className="card p-6 text-center">
                  <div className="text-poshGold text-3xl mb-2">
                    <i className="ri-search-line"></i>
                  </div>
                  <p className="text-softWhite/70">No guilds available to discover</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
        
        {/* Leaderboard Section */}
        <motion.div className="px-4 mb-10" variants={itemVariants}>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-cinzel text-lg font-medium">Leaderboards</h2>
            <Badge variant="outline" className="bg-poshGold/10 text-poshGold border-none">
              Weekly <i className="ri-arrow-down-s-line ml-1"></i>
            </Badge>
          </div>
          
          <LeaderboardCard />
        </motion.div>
      </motion.div>
      
      <CreateGuildModal 
        open={showCreateGuild} 
        onOpenChange={setShowCreateGuild} 
      />
      
      <BottomNavbar />
    </div>
  );
}
