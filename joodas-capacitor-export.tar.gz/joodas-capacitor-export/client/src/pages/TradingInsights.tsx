import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import BottomNavbar from '@/components/layout/BottomNavbar';

export default function TradingInsights() {
  const [activeTab, setActiveTab] = useState('all');
  
  useEffect(() => {
    // Set the page title
    document.title = 'Trading Insights | Joodas';
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  // Sample insights data
  const insights = [
    {
      id: 1,
      type: 'opportunity',
      title: 'Trade Opportunity',
      message: 'Last 5 times SOL dipped this low, it pumped 12% within 48 hours.',
      tags: ['Likely Pump', 'Historical Pattern'],
      icon: 'line-chart-line',
      iconColor: 'emerald',
      timestamp: 'Today at 9:15 AM'
    },
    {
      id: 2,
      type: 'roast',
      title: 'Wallet Roast',
      message: 'You paperhanded SOL at $98 just before the pump to $125. Classic degen move!',
      tags: ['Paper Hands', 'Poor Timing'],
      icon: 'fire-line',
      iconColor: 'amber',
      timestamp: 'Yesterday at 3:22 PM'
    },
    {
      id: 3,
      type: 'regret',
      title: 'Missed Gains',
      message: "If you held that 12 SOL you sold last month, you'd be up an extra $325 today.",
      tags: ['Regret', 'HODL Lesson'],
      icon: 'time-line',
      iconColor: 'indigo',
      timestamp: '2 days ago'
    },
    {
      id: 4,
      type: 'alert',
      title: 'Market Alert',
      message: 'SOL has broken out of its 30-day moving average. Bullish divergence detected.',
      tags: ['Technical Pattern', 'Breakout'],
      icon: 'alert-line',
      iconColor: 'blue',
      timestamp: '3 days ago'
    },
    {
      id: 5,
      type: 'opportunity',
      title: 'DCA Reminder',
      message: 'Setting up a weekly $50 DCA for SOL could grow your portfolio by 15% more than your current strategy.',
      tags: ['Strategy', 'Optimization'],
      icon: 'funds-line',
      iconColor: 'emerald',
      timestamp: '5 days ago'
    }
  ];
  
  // Filter insights based on active tab
  const filteredInsights = activeTab === 'all' 
    ? insights 
    : insights.filter(insight => insight.type === activeTab);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm py-4 px-5 flex items-center justify-between">
        <div className="flex items-center">
          <a href="/" className="mr-3">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </a>
          <h1 className="text-xl font-semibold text-gray-800">Trading Insights</h1>
        </div>
        <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100">
          <i className="ri-notification-line text-gray-700"></i>
        </button>
      </div>
      
      <motion.div 
        className="flex-1 pb-4 px-4 max-w-2xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Tab Navigation */}
        <motion.div variants={itemVariants} className="mb-5 mt-4">
          <div className="bg-white rounded-xl shadow-sm mb-4 inline-flex space-x-1 p-1">
            {[
              { id: 'all', label: 'All' },
              { id: 'opportunity', label: 'Opportunities' },
              { id: 'roast', label: 'Roasts' },
              { id: 'regret', label: 'Regrets' },
              { id: 'alert', label: 'Alerts' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeTab === tab.id 
                    ? "bg-gradient-to-r from-poshGold to-amber-400 text-white shadow-sm" 
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </motion.div>
        
        {/* Insights List */}
        <motion.div variants={itemVariants} className="space-y-4">
          {filteredInsights.map(insight => (
            <div 
              key={insight.id} 
              className="bg-white rounded-2xl p-5 shadow-md hover:shadow-lg transition-all duration-300"
            >
              <div className="flex items-center mb-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                  insight.iconColor === 'emerald' ? 'bg-emerald-500/10' :
                  insight.iconColor === 'amber' ? 'bg-amber-500/10' :
                  insight.iconColor === 'indigo' ? 'bg-indigo-500/10' :
                  insight.iconColor === 'blue' ? 'bg-blue-500/10' : 'bg-gray-500/10'
                }`}>
                  <i className={`ri-${insight.icon} ${
                    insight.iconColor === 'emerald' ? 'text-emerald-500' :
                    insight.iconColor === 'amber' ? 'text-amber-500' :
                    insight.iconColor === 'indigo' ? 'text-indigo-500' :
                    insight.iconColor === 'blue' ? 'text-blue-500' : 'text-gray-500'
                  }`}></i>
                </div>
                <div className="text-sm font-semibold text-gray-800">{insight.title}</div>
                <div className="ml-auto text-xs text-gray-500">{insight.timestamp}</div>
              </div>
              
              <div className="text-base text-gray-700 mb-3">
                {insight.message}
              </div>
              
              <div className="flex items-center space-x-2 mb-4">
                {insight.tags.map((tag, i) => (
                  <div 
                    key={i} 
                    className={`bg-${insight.iconColor}-100 text-${insight.iconColor}-700 text-xs rounded-full px-3 py-1`}
                  >
                    {tag}
                  </div>
                ))}
              </div>
              
              <div className="flex items-center justify-between">
                <button className="text-xs text-blue-500 flex items-center">
                  View History
                  <i className="ri-arrow-right-s-line ml-1"></i>
                </button>
                
                <button className="bg-gray-100 hover:bg-gray-200 transition-colors text-gray-700 text-xs rounded-lg px-3 py-1.5 flex items-center">
                  <i className="ri-bookmark-line mr-1.5"></i>
                  Save
                </button>
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>
      
      {/* Bottom Navigation */}
      <BottomNavbar activePage="stats" />
    </div>
  );
}