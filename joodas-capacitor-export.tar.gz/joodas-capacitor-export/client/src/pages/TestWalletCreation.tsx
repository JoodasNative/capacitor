import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { useTestWallet } from '@/hooks/use-test-wallet';

export default function TestWalletCreation() {
  const [userId, setUserId] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [creationResponse, setCreationResponse] = useState<any>(null);
  
  const { 
    wallets, 
    isLoading, 
    refetch, 
    createTestWallet, 
    isCreating 
  } = useTestWallet(userId);
  
  useEffect(() => {
    // Set the page title
    document.title = 'Test Wallet Creation | Joodas';
    
    // Try to load the user ID from localStorage
    const storedUserId = localStorage.getItem('userId');
    if (storedUserId) {
      setUserId(storedUserId);
    }
    
    // Check for existing wallet address
    const storedWalletAddress = localStorage.getItem('userWalletAddress');
    if (storedWalletAddress) {
      setWalletAddress(storedWalletAddress);
    }
  }, []);
  
  const handleCreateTestWallet = async () => {
    try {
      // Call the createTestWallet from our custom hook
      createTestWallet(userId);
      
      // Success toast will be shown by the hook itself
      
      // Wait for the API response and set it for display
      fetch('/api/wallets', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      })
        .then(response => response.json())
        .then(data => {
          if (Array.isArray(data) && data.length > 0) {
            const wallet = data[0];
            setCreationResponse({
              message: "Wallet created successfully",
              wallet: wallet
            });
            
            // Also update the wallet address
            if (wallet.address) {
              setWalletAddress(wallet.address);
              localStorage.setItem('userWalletAddress', wallet.address);
            }
          }
        })
        .catch(err => {
          console.warn('Could not fetch wallet data:', err);
        });
    } catch (error) {
      console.error('Error handling wallet creation:', error);
      
      toast({
        title: "Error Creating Wallet",
        description: "There was a problem with wallet creation",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 p-4 flex flex-col items-center">
      <div className="w-full max-w-2xl mx-auto mt-8">
        <h1 className="text-2xl font-bold text-center mb-6">Test Wallet Creation</h1>
        
        <Card className="mb-6 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-poshGold/10 to-white">
            <CardTitle>Create Test Wallet</CardTitle>
            <CardDescription>
              This is a special test page for creating and managing wallets without going through the full authentication flow.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  User ID (from localStorage)
                </label>
                <div className="flex">
                  <input
                    type="text"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-1 focus:ring-poshGold"
                    placeholder="Enter User ID"
                  />
                  <Button 
                    variant="outline"
                    className="rounded-l-none border-l-0"
                    onClick={() => {
                      const localId = localStorage.getItem('userId');
                      if (localId) {
                        setUserId(localId);
                        toast({
                          title: "User ID Loaded",
                          description: `Loaded user ID: ${localId}`,
                        });
                      } else {
                        toast({
                          title: "No User ID Found",
                          description: "No user ID stored in localStorage",
                          variant: "destructive",
                        });
                      }
                    }}
                  >
                    <i className="ri-refresh-line mr-1"></i> Load from Storage
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  This should be automatically filled if you've logged in successfully
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Current Wallet Status
                </label>
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  {isLoading ? (
                    <div className="flex items-center">
                      <div className="w-5 h-5 border-2 border-poshGold border-solid rounded-full border-t-transparent animate-spin mr-2"></div>
                      <span>Checking wallet status...</span>
                    </div>
                  ) : Array.isArray(wallets) && wallets.length > 0 ? (
                    <div className="space-y-2">
                      <div className="flex items-center text-green-600">
                        <i className="ri-checkbox-circle-fill mr-2"></i>
                        <span className="font-medium">Wallet Exists</span>
                      </div>
                      <div className="font-mono text-sm bg-gray-100 p-2 rounded break-all">
                        {wallets[0]?.address}
                      </div>
                    </div>
                  ) : walletAddress ? (
                    <div className="space-y-2">
                      <div className="flex items-center text-blue-600">
                        <i className="ri-information-fill mr-2"></i>
                        <span className="font-medium">Wallet address in localStorage, but not loaded from API</span>
                      </div>
                      <div className="font-mono text-sm bg-gray-100 p-2 rounded break-all">
                        {walletAddress}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center text-amber-600">
                      <i className="ri-wallet-3-line mr-2"></i>
                      <span>No wallet found for this user</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between border-t p-6 bg-gray-50">
            <Button
              variant="outline"
              onClick={() => refetch()}
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center">
                  <i className="ri-loader-4-line animate-spin mr-1"></i> Loading...
                </span>
              ) : (
                <span className="flex items-center">
                  <i className="ri-refresh-line mr-1"></i> Refresh Wallet Data
                </span>
              )}
            </Button>
            
            <Button
              className="bg-gradient-to-r from-poshGold to-amber-500 hover:from-poshGold/90 hover:to-amber-500/90 text-white border-none"
              onClick={handleCreateTestWallet}
              disabled={isCreating || !userId || (Array.isArray(wallets) && wallets.length > 0)}
            >
              {isCreating ? (
                <span className="flex items-center">
                  <i className="ri-loader-4-line animate-spin mr-1"></i> Creating...
                </span>
              ) : (
                <span className="flex items-center">
                  <i className="ri-wallet-add-line mr-1"></i> Create Test Wallet
                </span>
              )}
            </Button>
          </CardFooter>
        </Card>
        
        {creationResponse && (
          <Card className="mb-6 border-green-200 shadow-lg">
            <CardHeader className="bg-green-50">
              <CardTitle className="text-green-700">Wallet Creation Response</CardTitle>
              <CardDescription className="text-green-600">
                Raw API response from wallet creation endpoint
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6">
              <pre className="bg-gray-900 text-gray-100 p-4 rounded-md overflow-auto text-sm">
                {JSON.stringify(creationResponse, null, 2)}
              </pre>
            </CardContent>
            
            <CardFooter className="border-t p-6 bg-green-50/50">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  window.location.href = "/wallet";
                }}
              >
                <span className="flex items-center justify-center">
                  <i className="ri-wallet-3-line mr-1"></i> Go to Wallet Page
                </span>
              </Button>
            </CardFooter>
          </Card>
        )}
        
        <div className="flex justify-center mt-8">
          <a 
            href="/"
            className="text-sm text-gray-500 hover:text-poshGold underline"
          >
            Back to Dashboard
          </a>
        </div>
      </div>
    </div>
  );
}