import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { FirebaseError } from "firebase/app";
import { Loader2 } from "lucide-react";
import { useFirebaseAuth } from "@/context/FirebaseAuthContext";
import { motion } from "framer-motion";

const loginSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
});

const registerSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isGoogleLogin, setIsGoogleLogin] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("login");
  const [_, navigate] = useLocation();
  const { currentUser, loading, login, signUp, loginWithGoogle } = useFirebaseAuth();

  // Redirect to home if user is already logged in
  useEffect(() => {
    if (currentUser) {
      const redirectPath = localStorage.getItem("redirectAfterLogin") || "/";
      localStorage.removeItem("redirectAfterLogin");
      navigate(redirectPath);
    }
  }, [currentUser, navigate]);

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  async function onLoginSubmit(values: LoginFormValues) {
    setIsLoggingIn(true);
    try {
      await login(values.email, values.password);
      // Redirect happens in useEffect
    } catch (error: any) {
      console.error("Login error:", error);
      
      // Display appropriate error messages
      if (error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found') {
        loginForm.setError('email', {
          type: 'manual',
          message: 'Invalid email or password'
        });
      } else if (error.code === 'auth/too-many-requests') {
        loginForm.setError('email', {
          type: 'manual',
          message: 'Too many failed attempts. Try again later or reset your password.'
        });
      } else {
        loginForm.setError('email', {
          type: 'manual',
          message: 'Login failed. Please try again.'
        });
      }
    } finally {
      setIsLoggingIn(false);
    }
  }

  async function onRegisterSubmit(values: RegisterFormValues) {
    setIsRegistering(true);
    try {
      await signUp(values.email, values.password);
      // Redirect happens in useEffect
    } catch (error: any) {
      console.error("Registration error:", error);
      
      // Handle specific Firebase errors with user-friendly messages
      if (error instanceof FirebaseError) {
        if (error.code === 'auth/email-already-in-use') {
          registerForm.setError('email', {
            type: 'manual',
            message: 'This email is already in use'
          });
        } else if (error.code === 'auth/invalid-email') {
          registerForm.setError('email', {
            type: 'manual',
            message: 'Please enter a valid email address'
          });
        } else if (error.code === 'auth/weak-password') {
          registerForm.setError('password', {
            type: 'manual',
            message: 'Password should be at least 6 characters'
          });
        } else if (error.code === 'auth/unauthorized-domain') {
          registerForm.setError('email', {
            type: 'manual',
            message: 'This domain is not authorized for user registration. Please contact support.'
          });
        } else {
          registerForm.setError('email', {
            type: 'manual',
            message: 'Registration failed. Please try again.'
          });
        }
      }
    } finally {
      setIsRegistering(false);
    }
  }

  async function handleGoogleLogin() {
    setIsGoogleLogin(true);
    try {
      await loginWithGoogle();
      // Redirect happens in useEffect
    } catch (error: any) {
      console.error("Google login error:", error);
      
      // Show specific messages for different error types
      if (error.code === 'auth/unauthorized-domain') {
        loginForm.setError('email', {
          type: 'manual',
          message: 'This domain is not authorized for authentication. Please contact support.'
        });
      } else if (error.code === 'auth/operation-not-allowed') {
        loginForm.setError('email', {
          type: 'manual',
          message: 'Google sign-in is not enabled for this app. Please use email/password instead.'
        });
      } else {
        loginForm.setError('email', {
          type: 'manual',
          message: 'Google sign-in failed. Please try email/password instead.'
        });
      }
    } finally {
      setIsGoogleLogin(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-black">
        <Loader2 className="h-12 w-12 animate-spin text-poshGold" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      {/* Left side: Auth form */}
      <div className="flex w-full flex-col items-center justify-center bg-black p-8 md:w-1/2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold text-poshGold">Joodas</h1>
            <p className="mt-2 text-gray-400">Your Solana Wallet Whisperer</p>
          </div>

          <Card className="border-poshGold/20 bg-gray-900 text-white">
            <CardHeader>
              <CardTitle className="text-poshGold">Seamless Degen Onboarding</CardTitle>
              <CardDescription className="text-gray-400">
                Sign in to access your personalized crypto experience
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                  <TabsTrigger
                    value="login"
                    className="data-[state=active]:bg-poshGold data-[state=active]:text-black"
                  >
                    Login
                  </TabsTrigger>
                  <TabsTrigger
                    value="register"
                    className="data-[state=active]:bg-poshGold data-[state=active]:text-black"
                  >
                    Register
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="mt-4">
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Email</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="you@example.com"
                                className="border-gray-700 bg-gray-800 text-white"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="border-gray-700 bg-gray-800 text-white"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="submit"
                        className="w-full bg-poshGold text-black hover:bg-poshGold/90"
                        disabled={isLoggingIn}
                      >
                        {isLoggingIn && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isLoggingIn ? "Logging in..." : "Sign In"}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>

                <TabsContent value="register" className="mt-4">
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Email</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="you@example.com"
                                className="border-gray-700 bg-gray-800 text-white"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="border-gray-700 bg-gray-800 text-white"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Confirm Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="border-gray-700 bg-gray-800 text-white"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="submit"
                        className="w-full bg-poshGold text-black hover:bg-poshGold/90"
                        disabled={isRegistering}
                      >
                        {isRegistering && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isRegistering ? "Creating Account..." : "Create Account"}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>

              <div className="mt-6">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-700" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-gray-900 px-2 text-gray-400">Or continue with</span>
                  </div>
                </div>

                <div className="mt-6">
                  <Button
                    onClick={handleGoogleLogin}
                    className="w-full border border-gray-700 bg-gray-800 text-white hover:bg-gray-700"
                    variant="outline"
                    disabled={isGoogleLogin}
                  >
                    {isGoogleLogin && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <span className="flex items-center justify-center">
                      <svg
                        className="mr-2 h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 48 48"
                        width="24px"
                        height="24px"
                      >
                        <path
                          fill="#FFC107"
                          d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"
                        />
                        <path
                          fill="#FF3D00"
                          d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"
                        />
                        <path
                          fill="#4CAF50"
                          d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"
                        />
                        <path
                          fill="#1976D2"
                          d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"
                        />
                      </svg>
                      {isGoogleLogin ? "Connecting..." : "Sign in with Google"}
                    </span>
                  </Button>
                  <p className="text-xs text-amber-500 mt-2 text-center">
                    Note: You need to enable Google sign-in in Firebase console first
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <div className="text-center text-sm text-gray-500">
                By continuing, you agree to Joodas's Terms of Service and Privacy Policy.
              </div>
            </CardFooter>
          </Card>
        </motion.div>
      </div>

      {/* Right side: Hero/Welcome section */}
      <div className="hidden bg-gradient-to-br from-gray-900 to-black md:flex md:w-1/2">
        <div className="flex flex-col items-center justify-center p-12 text-white">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="max-w-md"
          >
            <h2 className="mb-6 text-3xl font-bold text-poshGold">Wallet Whisperer</h2>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-poshGold/10 text-poshGold">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z"
                      stroke="#DCB454"
                      strokeWidth="2"
                    />
                    <path d="M12 8V12L15 15" stroke="#DCB454" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-poshGold">Instant Wallet Setup</h3>
                  <p className="text-gray-400">Create your non-custodial Solana wallet in seconds with seamless setup</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-poshGold/10 text-poshGold">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M12 16V8M9 13L12 16L15 13M3 8L12 4L21 8L12 12L3 8Z"
                      stroke="#DCB454"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M21 12V8M3 12V8"
                      stroke="#DCB454"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-poshGold">AI-Powered Insights</h3>
                  <p className="text-gray-400">Receive personalized trade nudges and portfolio recommendations</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-poshGold/10 text-poshGold">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M8 13V17M16 11V17M12 7V17M7.8 21H16.2C17.8802 21 18.7202 21 19.362 20.673C19.9265 20.3854 20.3854 19.9265 20.673 19.362C21 18.7202 21 17.8802 21 16.2V7.8C21 6.11984 21 5.27976 20.673 4.63803C20.3854 4.07354 19.9265 3.6146 19.362 3.32698C18.7202 3 17.8802 3 16.2 3H7.8C6.11984 3 5.27976 3 4.63803 3.32698C4.07354 3.6146 3.6146 4.07354 3.32698 4.63803C3 5.27976 3 6.11984 3 7.8V16.2C3 17.8802 3 18.7202 3.32698 19.362C3.6146 19.9265 4.07354 20.3854 4.63803 20.673C5.27976 21 6.11984 21 7.8 21Z"
                      stroke="#DCB454"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-poshGold">Performance Tracking</h3>
                  <p className="text-gray-400">Monitor your crypto journey with detailed analytics and insights</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}