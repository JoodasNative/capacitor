import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import BottomNavbar from '@/components/layout/BottomNavbar';

export default function Transactions() {
  const [activeTab, setActiveTab] = useState('Today');
  const [filterType, setFilterType] = useState('all');
  
  useEffect(() => {
    // Set the page title
    document.title = 'Transaction History | Joodas';
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };
  
  // Sample transactions data
  const transactions = [
    {
      id: 1,
      type: 'staking',
      title: 'SOL Staking',
      amount: '+2.5 SOL',
      value: '+$567.25',
      date: 'Sat 23 January',
      time: '1:03 PM',
      status: 'complete',
      category: 'earn',
      icon: 'exchange-dollar-fill',
      iconBg: 'from-emerald-100 to-emerald-50',
      textColor: 'text-emerald-500'
    },
    {
      id: 2,
      type: 'swap',
      title: 'SOL/USDC Swap',
      amount: '-1.2 SOL',
      value: '-$189.75',
      date: 'Fri 22 January',
      time: '2:15 PM',
      status: 'complete',
      category: 'swap',
      icon: 'swap-line',
      iconBg: 'from-blue-100 to-blue-50',
      textColor: 'text-blue-500'
    },
    {
      id: 3,
      type: 'hodl',
      title: 'SOL HODL Streak',
      amount: '4.9 SOL',
      value: '+14 day streak',
      date: 'Thu 21 January',
      time: '9:15 AM',
      status: 'active',
      category: 'hodl',
      icon: 'time-line',
      iconBg: 'from-amber-100 to-amber-50',
      textColor: 'text-amber-500'
    },
    {
      id: 4,
      type: 'buy',
      title: 'Buy SOL',
      amount: '+10 SOL',
      value: '-$1,220.50',
      date: 'Wed 20 January',
      time: '11:32 AM',
      status: 'complete',
      category: 'buy',
      icon: 'shopping-cart-line',
      iconBg: 'from-purple-100 to-purple-50',
      textColor: 'text-purple-500'
    },
    {
      id: 5,
      type: 'receive',
      title: 'Received SOL',
      amount: '+2.5 SOL',
      value: '+$305.25',
      date: 'Mon 18 January',
      time: '4:45 PM',
      status: 'complete',
      category: 'receive',
      icon: 'download-line',
      iconBg: 'from-emerald-100 to-emerald-50',
      textColor: 'text-emerald-500'
    },
    {
      id: 6,
      type: 'send',
      title: 'Sent SOL',
      amount: '-1.5 SOL',
      value: '-$183.15',
      date: 'Mon 18 January',
      time: '10:22 AM',
      status: 'complete',
      category: 'send',
      icon: 'upload-line',
      iconBg: 'from-red-100 to-red-50',
      textColor: 'text-red-500'
    }
  ];
  
  // Filter transactions based on active tab and filter
  const filteredTransactions = transactions.filter(tx => {
    // Filter by time period
    const dayMatches = activeTab === 'Today' ? 
      tx.date.includes('23 January') : // Assuming today is Jan 23
      activeTab === 'This Week' ? 
        !tx.date.includes('18 January') :  // Exclude transactions from more than a week ago
        true; // Show all for "This Month"
    
    // Filter by type
    const typeMatches = filterType === 'all' ? true : tx.category === filterType;
    
    return dayMatches && typeMatches;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm py-4 px-5 flex items-center justify-between">
        <div className="flex items-center">
          <a href="/" className="mr-3">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </a>
          <h1 className="text-xl font-semibold text-gray-800">Transaction History</h1>
        </div>
        <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100">
          <i className="ri-search-line text-gray-700"></i>
        </button>
      </div>
      
      <motion.div 
        className="flex-1 pb-4 px-4 max-w-2xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Time Filters */}
        <motion.div variants={itemVariants} className="mt-4 mb-4">
          <div className="bg-white rounded-xl shadow-sm inline-flex space-x-1 p-1">
            {["Today", "This Week", "This Month"].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeTab === tab 
                    ? "bg-gradient-to-r from-poshGold to-amber-400 text-white shadow-sm" 
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </motion.div>
        
        {/* Category Filters */}
        <motion.div variants={itemVariants} className="mb-5 overflow-x-auto -mx-4 px-4">
          <div className="flex space-x-2 whitespace-nowrap">
            {[
              { id: 'all', label: 'All', icon: 'ri-wallet-3-line' },
              { id: 'buy', label: 'Buy', icon: 'ri-shopping-cart-line' },
              { id: 'swap', label: 'Swap', icon: 'ri-swap-line' },
              { id: 'send', label: 'Send', icon: 'ri-upload-line' },
              { id: 'receive', label: 'Receive', icon: 'ri-download-line' },
              { id: 'earn', label: 'Earn', icon: 'ri-coin-line' },
              { id: 'hodl', label: 'HODL', icon: 'ri-time-line' }
            ].map(filter => (
              <button
                key={filter.id}
                onClick={() => setFilterType(filter.id)}
                className={`px-4 py-2 rounded-full text-xs font-medium flex items-center transition-all duration-300 ${
                  filterType === filter.id 
                    ? "bg-poshGold text-white shadow-sm" 
                    : "bg-white text-gray-700 border border-gray-200 hover:border-poshGold/50"
                }`}
              >
                <i className={`${filter.icon} mr-1.5`}></i>
                {filter.label}
              </button>
            ))}
          </div>
        </motion.div>
        
        {/* Transactions List */}
        <motion.div variants={itemVariants} className="mb-5">
          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((tx, index) => (
                <div 
                  key={tx.id} 
                  className={`p-4 hover:bg-gray-50 transition-colors duration-200 ${
                    index !== filteredTransactions.length - 1 ? 'border-b border-gray-100' : ''
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <div className={`w-10 h-10 bg-gradient-to-br ${tx.iconBg} rounded-xl flex items-center justify-center mr-3 shadow-sm`}>
                        <i className={`ri-${tx.icon} text-lg ${tx.textColor}`}></i>
                      </div>
                      <div>
                        <div className="font-medium text-gray-800">{tx.title}</div>
                        <div className="text-xs text-gray-500">{tx.date} • {tx.time}</div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className={`font-medium ${tx.textColor}`}>{tx.amount}</div>
                      <div className="text-xs text-gray-500">{tx.value}</div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                  <i className="ri-inbox-line text-2xl text-gray-400"></i>
                </div>
                <div className="text-gray-500 text-sm">No transactions found</div>
                <div className="text-xs text-gray-400 mt-1">Try a different filter</div>
              </div>
            )}
          </div>
        </motion.div>
        
        {/* Analytics Summary */}
        <motion.div variants={itemVariants} className="mb-5">
          <div className="text-gray-800 font-medium mb-3">Transaction Summary</div>
          <div className="bg-white rounded-2xl p-5 shadow-md">
            <div className="grid grid-cols-3 gap-4 mb-5">
              <div className="text-center">
                <div className="text-xs text-gray-500 mb-1">Total In</div>
                <div className="text-emerald-500 font-medium">+15 SOL</div>
                <div className="text-xs text-gray-500">+$1,830.50</div>
              </div>
              <div className="text-center border-x border-gray-100">
                <div className="text-xs text-gray-500 mb-1">Total Out</div>
                <div className="text-red-500 font-medium">-4.2 SOL</div>
                <div className="text-xs text-gray-500">-$512.40</div>
              </div>
              <div className="text-center">
                <div className="text-xs text-gray-500 mb-1">Net</div>
                <div className="text-poshGold font-medium">+10.8 SOL</div>
                <div className="text-xs text-gray-500">+$1,318.10</div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="text-gray-500">Transaction Fee Efficiency</div>
                <div className="text-gray-700 font-medium">98.2%</div>
              </div>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-400" style={{width: "98.2%"}}></div>
              </div>
              <div className="text-xs text-gray-500 mt-1">Great job! Low fees compared to transaction volume.</div>
            </div>
          </div>
        </motion.div>
        
        {/* Export Button */}
        <motion.div variants={itemVariants} className="mb-5">
          <button className="w-full bg-white text-gray-700 border border-gray-200 rounded-xl py-3 flex items-center justify-center font-medium shadow-sm hover:shadow-md transition-all duration-300">
            <i className="ri-download-2-line mr-2"></i>
            Export Transaction History
          </button>
        </motion.div>
      </motion.div>
      
      {/* Bottom Navigation */}
      <BottomNavbar activePage="home" />
    </div>
  );
}