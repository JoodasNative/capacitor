import React from 'react';
import { redirectToLogin } from '../hooks/useAuth';

export default function Login() {
  const handleLogin = () => {
    redirectToLogin();
  };
  
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white p-4">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-xl">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900">
            Welcome to <span className="text-poshGold">Joodas</span>
          </h1>
          <p className="mt-3 text-gray-600">
            Your premium crypto personal finance assistant
          </p>
        </div>
        
        <div className="mt-10">
          <button
            onClick={handleLogin}
            className="w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-white bg-poshGold hover:bg-poshGold/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-poshGold"
          >
            Sign in with Replit
          </button>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
        
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h3 className="text-md font-medium text-gray-900">Premium Features</h3>
          <ul className="mt-2 space-y-2">
            <li className="flex items-center text-sm text-gray-600">
              <span className="mr-2">✓</span> Advanced Solana trading with Jupiter
            </li>
            <li className="flex items-center text-sm text-gray-600">
              <span className="mr-2">✓</span> Exclusive Financial Karma scores
            </li>
            <li className="flex items-center text-sm text-gray-600">
              <span className="mr-2">✓</span> AI-powered trade recommendations
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}