import React, { useEffect, useState } from 'react';
import { redirectToLogin, redirectToLogout } from '../hooks/useAuth';
import { useLocation } from 'wouter';
import joodasLogo from '../assets/images/joodas-logo.png';
import { useToast } from '../hooks/use-toast';

export default function ReplitLogin() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [userWasLoggedIn, setUserWasLoggedIn] = useState(false);
  
  // Check if user was already logged in when they landed on this page
  useEffect(() => {
    if (localStorage.getItem('hasLoggedIn')) {
      setUserWasLoggedIn(true);
    }
  }, []);
  
  // Handle auth status from query params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const authStatus = urlParams.get('auth');
    
    if (authStatus === 'success') {
      localStorage.setItem('hasLoggedIn', 'true');
      
      // Fetch user data from API
      fetch('/api/auth/user')
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to fetch user data');
          }
          return response.json();
        })
        .then(userData => {
          // Store user data in localStorage for quick access
          if (userData) {
            // Store main user details
            if (userData.firstName) localStorage.setItem('userFirstName', userData.firstName);
            if (userData.lastName) localStorage.setItem('userLastName', userData.lastName);
            if (userData.email) localStorage.setItem('userEmail', userData.email);
            if (userData.profileImageUrl) localStorage.setItem('userProfileImage', userData.profileImageUrl);
            
            // Store user ID for wallet generation
            if (userData.id) localStorage.setItem('userId', userData.id);
            
            // If there's any persistent wallet data, store it too
            if (userData.walletAddress) localStorage.setItem('userWalletAddress', userData.walletAddress);
            
            // Set a flag to trigger wallet check on the next page
            localStorage.setItem('checkWalletOnLoad', 'true');
          }
          
          // Regular welcome back toast
          toast({
            title: "Login Successful",
            description: userData.firstName 
              ? `Welcome back, ${userData.firstName}!` 
              : "Welcome to Joodas!",
          });
          
          // Clear the URL parameter before navigating
          window.history.replaceState({}, document.title, window.location.pathname);
          navigate('/');
        })
        .catch(error => {
          console.error('Error fetching user data:', error);
          // Still allow login even if profile fetch fails
          localStorage.setItem('hasLoggedIn', 'true');
          
          toast({
            title: "Login Successful",
            description: "Welcome to Joodas!",
          });
          
          // Clear the URL parameter before navigating
          window.history.replaceState({}, document.title, window.location.pathname);
          navigate('/');
        });
    } else if (authStatus === 'failed') {
      setError('Authentication failed. Please try again.');
      
      toast({
        title: "Authentication Failed",
        description: "Please try again or continue as guest",
        variant: "destructive",
      });
    } else if (authStatus === 'logout') {
      // Clear all user data
      localStorage.removeItem('hasLoggedIn');
      localStorage.removeItem('userFirstName');
      localStorage.removeItem('userLastName');
      localStorage.removeItem('userEmail');
      localStorage.removeItem('userProfileImage');
      localStorage.removeItem('userWalletAddress');
      
      setError('You have been logged out.');
      
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully",
      });
    }
  }, [navigate, toast]);
  
  const handleLogin = () => {
    setIsLoggingIn(true);
    // Clear any previous errors
    setError(null);
    
    try {
      // Start the Replit Auth flow
      redirectToLogin();
    } catch (error) {
      console.error('Login error:', error);
      setIsLoggingIn(false);
      setError('Failed to initiate login. Please try again.');
    }
  };
  
  const handleLogout = () => {
    setIsLoggingOut(true);
    try {
      // Clear local auth state first
      localStorage.removeItem('hasLoggedIn');
      // Navigate through the logout flow
      redirectToLogout();
    } catch (error) {
      console.error('Logout error:', error);
      setIsLoggingOut(false);
      setError('Failed to log out. Please try again.');
    }
  };
  
  const goToHome = () => {
    // For guest access - still mark as logged in to prevent further redirects
    localStorage.setItem('hasLoggedIn', 'true');
    
    toast({
      title: "Continuing as Guest",
      description: "You can sign in anytime from the settings page",
    });
    
    navigate('/');
  };
  
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Glass card effect for premium look */}
      <div className="w-full max-w-md p-8 space-y-8 bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl border border-gray-100">
        <div className="text-center">
          {/* Logo with shimmer effect */}
          <div className="flex justify-center mb-6 relative shimmer-effect overflow-hidden rounded-xl">
            <img src={joodasLogo} alt="Joodas" className="h-20" />
          </div>
          
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900">
            Welcome to <span className="text-poshGold">Joodas</span>
          </h1>
          <p className="mt-3 text-gray-600">
            Your premium crypto personal finance companion
          </p>
          
          {/* Error message */}
          {error && (
            <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              {error}
            </div>
          )}
        </div>
        
        <div className="mt-8 space-y-4">
          {userWasLoggedIn ? (
            <>
              {/* Already logged in - show different options */}
              <div className="p-4 bg-green-50 text-green-700 rounded-lg text-sm mb-4 flex items-center">
                <div className="mr-3 text-green-500 text-xl">
                  <i className="ri-check-double-line"></i>
                </div>
                <div>
                  You're already signed in to Joodas.
                </div>
              </div>
              
              {/* Test page buttons */}
              <div className="space-y-3">
                <a
                  href="/test-wallet"
                  className="relative w-full py-4 px-6 border border-transparent rounded-xl 
                            text-white bg-poshGold hover:bg-poshGold/90 
                            focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-poshGold
                            shadow-lg overflow-hidden transition-all duration-300 transform hover:scale-[1.02]
                            flex items-center justify-center"
                >
                  <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent 
                                  shine-effect"></span>
                  <span className="relative flex items-center justify-center">
                    <i className="ri-wallet-3-line mr-2"></i>
                    Go to Wallet Page
                  </span>
                </a>
                
                <a
                  href="/test-wallet-creation"
                  className="w-full py-3 px-6 border border-gray-200 rounded-xl 
                            text-gray-700 bg-white hover:bg-gray-50
                            flex items-center justify-center"
                >
                  <i className="ri-tools-fill mr-2"></i>
                  Test Wallet Creation
                </a>
              </div>
              
              {/* Logout button */}
              <button
                onClick={handleLogout}
                disabled={isLoggingOut}
                className="w-full py-4 px-6 border border-gray-300 rounded-xl 
                          text-gray-700 bg-white hover:bg-gray-50 
                          focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-poshGold
                          shadow-md transition-all duration-300 transform hover:scale-[1.02]"
              >
                <span className="flex items-center justify-center">
                  {isLoggingOut ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Logging out...
                    </>
                  ) : (
                    <>
                      <i className="ri-logout-box-line mr-2"></i>
                      Sign Out
                    </>
                  )}
                </span>
              </button>
            </>
          ) : (
            <>
              {/* Not logged in - show login options */}
              {/* Replit Auth button with shine effect */}
              <button
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="relative w-full py-4 px-6 border border-transparent rounded-xl 
                          text-white bg-poshGold hover:bg-poshGold/90 
                          focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-poshGold
                          shadow-lg overflow-hidden transition-all duration-300 transform hover:scale-[1.02]"
              >
                <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent 
                                shine-effect"></span>
                <span className="relative flex items-center justify-center">
                  {isLoggingIn ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    <>
                      <i className="ri-fingerprint-line mr-2"></i>
                      Seamless Degen Onboarding
                    </>
                  )}
                </span>
              </button>
              
              {/* Guest access button */}
              <button
                onClick={goToHome}
                className="w-full py-4 px-6 border border-gray-300 rounded-xl 
                          text-gray-700 bg-white hover:bg-gray-50 
                          focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-poshGold
                          shadow-md transition-all duration-300 transform hover:scale-[1.02]"
              >
                <i className="ri-user-line mr-2"></i>
                Continue as Guest
              </button>
              
              {/* Terms of service */}
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-500">
                  By signing in, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            </>
          )}
        </div>
        
        {/* Premium features card with subtle gradient */}
        <div className="mt-8 p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-100 shadow-inner">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <span className="mr-2 text-poshGold">✦</span> Premium Features
          </h3>
          <ul className="mt-4 space-y-3">
            <li className="flex items-center text-sm text-gray-700">
              <span className="mr-3 text-poshGold">✓</span> Advanced Solana trading with Jupiter
            </li>
            <li className="flex items-center text-sm text-gray-700">
              <span className="mr-3 text-poshGold">✓</span> Exclusive Financial Karma scores
            </li>
            <li className="flex items-center text-sm text-gray-700">
              <span className="mr-3 text-poshGold">✓</span> AI-powered trade recommendations
            </li>
            <li className="flex items-center text-sm text-gray-700">
              <span className="mr-3 text-poshGold">✓</span> Personal HODL streak tracking
            </li>
          </ul>
        </div>
      </div>
      
      {/* Version tag */}
      <div className="mt-8 text-sm text-gray-400">
        Joodas 2.0 Wallet Whisperer
      </div>
    </div>
  );
}