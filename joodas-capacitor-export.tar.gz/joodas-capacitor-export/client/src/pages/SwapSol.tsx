import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import BottomNavbar from "@/components/layout/BottomNavbar";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";

// Token definitions
const TOKENS = [
  {
    id: "solana",
    name: "Solana",
    symbol: "SOL",
    mintAddress: "So11111111111111111111111111111111111111112",
    icon: "ri-sun-fill",
    color: "from-purple-400 to-purple-600",
    decimals: 9
  },
  {
    id: "usdc",
    name: "USD Coin",
    symbol: "USDC",
    mintAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    icon: "ri-money-dollar-circle-fill",
    color: "from-blue-400 to-blue-600",
    decimals: 6
  },
  {
    id: "msol",
    name: "Marinade SOL",
    symbol: "mSOL",
    mintAddress: "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
    icon: "ri-bubble-chart-fill",
    color: "from-orange-400 to-orange-600",
    decimals: 9
  }
];

export default function SwapSol() {
  const { toast } = useToast();
  const [amount, setAmount] = useState("0.1");
  const [fromToken, setFromToken] = useState(TOKENS[0]);
  const [toToken, setToToken] = useState(TOKENS[1]);
  const [slippage, setSlippage] = useState(1); // 1%
  const [quote, setQuote] = useState<any>(null);
  const [quoteLoading, setQuoteLoading] = useState(false);
  const [swapLoading, setSwapLoading] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 20
      }
    }
  };

  // Get a quote when inputs change
  useEffect(() => {
    if (!fromToken || !toToken || amount === "" || parseFloat(amount) <= 0) {
      setQuote(null);
      return;
    }
    
    // Don't quote if from and to tokens are the same
    if (fromToken.mintAddress === toToken.mintAddress) {
      return;
    }
    
    getQuote();
  }, [fromToken, toToken, amount, slippage]);

  const getQuote = async () => {
    try {
      setQuoteLoading(true);
      setWarnings([]);
      
      // Convert amount to the smallest unit based on decimals
      const amountInSmallestUnit = (parseFloat(amount) * Math.pow(10, fromToken.decimals)).toString();
      
      const response = await axios.post("/api/jupiter/quote", {
        inputMint: fromToken.mintAddress,
        outputMint: toToken.mintAddress,
        amount: amountInSmallestUnit,
        slippageBps: slippage * 100 // Convert percentage to basis points
      });
      
      setQuote(response.data);
      
      // Set warnings if any
      if (response.data.warnings && response.data.warnings.length > 0) {
        setWarnings(response.data.warnings);
      }
    } catch (error: any) {
      console.error("Error getting quote:", error);
      toast({
        title: "Error",
        description: error?.response?.data?.error || "Failed to get quote",
        variant: "destructive"
      });
    } finally {
      setQuoteLoading(false);
    }
  };

  const handleSwap = async () => {
    if (!quote) return;
    
    try {
      setSwapLoading(true);
      
      // In a real implementation, this would interact with wallet for signing
      // For now, we'll just show a success message
      toast({
        title: "Swap Initiated",
        description: "This is a demo of the swap interface. In a real implementation, this would connect to your wallet for transaction signing.",
      });
      
      setTimeout(() => {
        toast({
          title: "Swap Successful",
          description: `Successfully swapped ${amount} ${fromToken.symbol} to ${displayOutAmount()} ${toToken.symbol}`,
          variant: "default"
        });
        setSwapLoading(false);
      }, 2000);
    } catch (error: any) {
      console.error("Error executing swap:", error);
      toast({
        title: "Swap Failed",
        description: error?.response?.data?.error || "Failed to execute swap",
        variant: "destructive"
      });
      setSwapLoading(false);
    }
  };

  const switchTokens = () => {
    const temp = fromToken;
    setFromToken(toToken);
    setToToken(temp);
  };

  const displayOutAmount = () => {
    if (!quote) return "0";
    
    const rawAmount = parseInt(quote.outAmount) / Math.pow(10, toToken.decimals);
    return rawAmount.toFixed(toToken.symbol === "USDC" ? 2 : 6);
  };

  const getRate = () => {
    if (!quote) return "0";
    
    const inAmount = parseFloat(amount);
    const outAmount = parseInt(quote.outAmount) / Math.pow(10, toToken.decimals);
    
    return (outAmount / inAmount).toFixed(6);
  };

  const getPriceImpact = () => {
    if (!quote || !quote.priceImpactPct) return "0.00";
    
    const impact = parseFloat(String(quote.priceImpactPct));
    return impact.toFixed(2);
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground pb-20">
      <div className="bg-background px-4 py-3 flex justify-between items-center border-b border-gray-100">
        <button onClick={() => window.history.back()} className="text-gray-700">
          <i className="ri-arrow-left-s-line text-lg"></i>
        </button>
        <div className="text-lg font-semibold text-gray-800">Swap SOL</div>
        <div className="w-8"></div>
      </div>
      
      <motion.div 
        className="flex-1 px-5 pt-4 pb-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="mb-6">
          <div className="bg-white rounded-xl p-5 shadow-md">
            <div className="text-gray-700 text-sm mb-2">You Pay</div>
            <div className="flex items-center mb-3">
              <button 
                className="h-10 bg-gray-100 rounded-xl px-3 flex items-center mr-3"
                onClick={() => {
                  // Token selector would go here
                  toast({
                    title: "Token Selection",
                    description: "A token selector modal would open here"
                  });
                }}
              >
                <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${fromToken.color} flex items-center justify-center mr-2`}>
                  <i className={`${fromToken.icon} text-white text-xs`}></i>
                </div>
                <span className="font-medium">{fromToken.symbol}</span>
                <i className="ri-arrow-down-s-line ml-1"></i>
              </button>
              
              <input
                type="text"
                value={amount}
                onChange={(e) => {
                  // Only allow numbers and decimals
                  const value = e.target.value.replace(/[^0-9.]/g, '');
                  setAmount(value);
                }}
                className="flex-1 text-xl font-semibold bg-transparent focus:outline-none"
                placeholder="0.0"
              />
            </div>
            
            <div className="flex justify-between text-sm text-gray-500">
              <div>Balance: 1.5 {fromToken.symbol}</div>
              <div>~$143.70</div>
            </div>
          </div>
          
          <div className="flex justify-center -my-4 relative z-10">
            <button 
              onClick={switchTokens}
              className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center border border-gray-100 hover:shadow-lg transition-all duration-200"
            >
              <i className="ri-arrow-up-down-line text-gray-600"></i>
            </button>
          </div>
          
          <div className="bg-white rounded-xl p-5 shadow-md">
            <div className="text-gray-700 text-sm mb-2">You Receive</div>
            <div className="flex items-center mb-3">
              <button 
                className="h-10 bg-gray-100 rounded-xl px-3 flex items-center mr-3"
                onClick={() => {
                  // Token selector would go here
                  toast({
                    title: "Token Selection",
                    description: "A token selector modal would open here"
                  });
                }}
              >
                <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${toToken.color} flex items-center justify-center mr-2`}>
                  <i className={`${toToken.icon} text-white text-xs`}></i>
                </div>
                <span className="font-medium">{toToken.symbol}</span>
                <i className="ri-arrow-down-s-line ml-1"></i>
              </button>
              
              <div className="flex-1 text-xl font-semibold">
                {quoteLoading ? (
                  <div className="flex items-center">
                    <div className="h-5 w-5 border-2 border-gray-300 border-t-poshGold rounded-full animate-spin mr-2"></div>
                    <span className="text-gray-400">Loading...</span>
                  </div>
                ) : (
                  displayOutAmount()
                )}
              </div>
            </div>
            
            <div className="flex justify-between text-sm text-gray-500">
              <div>Balance: 0.0 {toToken.symbol}</div>
              <div>~$137.92</div>
            </div>
          </div>
        </motion.div>

        {quote && (
          <motion.div variants={itemVariants} className="mb-6">
            <div className="bg-white rounded-xl p-4 shadow-md">
              <div className="flex justify-between items-center py-2 text-sm border-b border-gray-100">
                <div className="text-gray-600">Rate</div>
                <div className="font-medium">1 {fromToken.symbol} ≈ {getRate()} {toToken.symbol}</div>
              </div>
              
              <div className="flex justify-between items-center py-2 text-sm border-b border-gray-100">
                <div className="text-gray-600">Price Impact</div>
                <div className={`font-medium ${parseFloat(getPriceImpact()) > 1 ? 'text-amber-500' : ''}`}>
                  {getPriceImpact()}%
                </div>
              </div>
              
              <div className="flex justify-between items-center py-2 text-sm border-b border-gray-100">
                <div className="text-gray-600">Slippage Tolerance</div>
                <div className="font-medium">{slippage}%</div>
              </div>
              
              <div className="flex justify-between items-center py-2 text-sm">
                <div className="text-gray-600">Minimum Received</div>
                <div className="font-medium">
                  {(parseInt(quote.otherAmountThreshold) / Math.pow(10, toToken.decimals)).toFixed(6)} {toToken.symbol}
                </div>
              </div>
            </div>
          </motion.div>
        )}
        
        {warnings.length > 0 && (
          <motion.div variants={itemVariants} className="mb-6">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-start">
                <i className="ri-alert-line text-amber-500 mr-2 mt-0.5"></i>
                <div>
                  <div className="text-amber-800 font-medium text-sm mb-1">Swap Warnings</div>
                  <ul className="text-amber-700 text-xs space-y-1">
                    {warnings.map((warning, index) => (
                      <li key={index}>{warning}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        <motion.div variants={itemVariants}>
          <button
            onClick={handleSwap}
            disabled={!quote || quoteLoading || swapLoading}
            className="w-full py-4 bg-gradient-to-r from-poshGold to-amber-400 rounded-xl text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {swapLoading ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                <span>Swapping...</span>
              </div>
            ) : quoteLoading ? (
              "Getting Best Price..."
            ) : !quote ? (
              "Enter an Amount"
            ) : (
              `Swap ${fromToken.symbol} to ${toToken.symbol}`
            )}
          </button>
        </motion.div>
      </motion.div>
      
      <BottomNavbar activePage="trade" />
    </div>
  );
}