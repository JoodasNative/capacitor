import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.joodas.app',
  appName: 'Joodas',
  webDir: 'dist',
  plugins: {
    // Configure app plugin 
    App: {
      backgroundMode: true,
      appStartOnBoot: false,
      exitOnSuspend: false
    },
    // Configure haptics plugin
    Haptics: {
      enableVibration: true,
      enableImpactFeedback: true
    },
    // Configure device information plugin
    Device: {
      // Device specific settings
    },
    // Configure SplashScreen
    SplashScreen: {
      launchShowDuration: 3000,
      launchAutoHide: true,
      backgroundColor: "#FFFFFF",
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
      showSpinner: false,
      androidSpinnerStyle: "large",
      iosSpinnerStyle: "small",
      spinnerColor: "#DCB454",
      splashFullScreen: true,
      splashImmersive: true
    }
  },
  // Development server settings (for live reload)
  server: {
    url: 'http://localhost:5000',
    cleartext: true
  },
  android: {
    buildOptions: {
      releaseType: "AAB",
      signingType: "apksigner"
    }
  },
  ios: {
    contentInset: "always",
    preferredContentMode: "mobile",
    scheme: "joodas",
    limitsNavigationsToAppBoundDomains: true,
    handleApplicationNotifications: true
  }
};

export default config;